/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : JainTcapStackImpl.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */



package com.aepona.jain.protocol.ss7.tcap;

// java import
import java.util.Vector;

// jain import
import jain.protocol.ss7.tcap.*;
import jain.protocol.ss7.tcap.dialogue.DialogueConstants;


/**
  * Used to control the creation/deletion of proprietary JainTcapProviders [RI this is PeerProvider]
  * and the attaching/detaching of those JainTcapProviders to this JainTcapStack implementation.
  *
  * @version     1.0
  * @author      AePONA
  */
public class JainTcapStackImpl implements JainTcapStack {


    public JainTcapStackImpl(){
        System.out.println("JainTcapStackImpl : constructor");
        this.setStackName("TCK-1999-AePONA");
    }

   /**
    * Returns the Signaling Point Code of this JainTcapStack.
    * The Signaling Point Code will uniquely identify the JainTcapStack.
    * @return the  signalingPointCode of this JainTcapStack.
    */
   public byte[] getSignalingPointCode(){
          System.out.println("JainTcapStackImpl : getSignallingPointCode : accessing SPC");
          return(this.spc);
   }


   /**
    * Sets the Signalling Point Code of this JainTcapStack. The Signaling Point Code
    * will uniquely identify the JainTcapStack.
    * @param <var>signalingPointCode</var> the  Signaling Point Code of this JainTcapStack.
    */
   public void setSignalingPointCode(byte[] signalingPointCode){
          System.out.println("JainTcapStackImpl : setSignallingPointCode : setting SPC");
          this.spc = signalingPointCode;
   }


   /**
    * Creates a new Peer (Vendor specific) <CODE>JainTcapProvider</CODE>
    * that is <B>attached</B> to this JainTcapStack and returns a reference to it.
    * <i>Note to developers:</i> The implementation of this method should add
    * the newly created <CODE>JainTcapProvider</CODE> to the
    * <a href="#providerList">providerList</a> once the <CODE>JainTcapProvider</CODE>
    * has been successfully created.
    * @return the newly created Peer Provider <i>attached to this JainTcapStack.</i>
    */
   public  JainTcapProvider createAttachedProvider(){
           System.out.println("JainTcapStackImpl : createAttachProvider : Creating attached Provider");
           PeerProvider newPeer = new PeerProvider();
           attach(newPeer);
           providerList.addElement(newPeer);
           System.out.println("JainTcapStackImpl : createAttachedProvider : Peer provider created and Attached to Stack");
           return(newPeer);
   }


   /**
    * Creates a new Peer (Vendor specific) Provider that is <B>detached</B> from this
    * JainTcapStack and returns a reference to it.
    * <i>Note to developers:</i> The implementation of this method should add
    * the newly created <CODE>JainTcapProvider</CODE> to the
    * <a href="#providerList">providerList</a> once the <CODE>JainTcapProvider</CODE>
    * has been successfully created.
    * @return the newly created <i>detached</i> Peer Provider.
    */
   public  JainTcapProvider createDetachedProvider(){
           System.out.println("JainTcapStackImpl : createDetachedProvider : creating unattached Provider");
           PeerProvider newPeer = new PeerProvider();
           providerList.addElement(newPeer);
           return(newPeer);
   }

   /**
    * Deletes the specifed <CODE>JainTcapProvider</CODE>.
    * <i>Note to developers:</i> The implementation of this method should remove
    * the specified<CODE>JainTcapProvider</CODE> from
    * <a href="#providerList">providerList</a>. <P>
    * @param <var>providerToBeDeleted</var> the <CODE>JainTcapProvidert</CODE> to be deleted.
    * @exception <var>UnableToDeleteProviderException</var> thrown if the specified
    * <CODE>JainTcapProvider</CODE> cannot be deleted. This may be because the
    * JainTcapProvider has already been deleted, or because the
    * <CODE>JainTcapProvider</CODE> is in use.
    */
    public void deleteProvider(JainTcapProvider providerToBeDeleted) throws UnableToDeleteProviderException {
      System.out.println("JainTcapStackImpl : deleteProvider : deleting provider");
      try {
        // check if the provider has been created by this stack
        if (!providerList.contains(providerToBeDeleted)) {
          throw new UnableToDeleteProviderException("JainTcapStackImpl : deleteProvider : The provider is not listed with this TcapStack");
        } else {
          providerList.removeElement(providerToBeDeleted);
        }
      } catch (UnableToDeleteProviderException e) {
      System.out.println("JainTcapStackImpl : deleteProvider : " +e.getMessage());
    }
   }



  /**
   * Attaches the specified Vendor specific Provider (Peer Provider) to this protocol stack.
   * @param <var>provider</var> the JainTcapProvider to attach to this JainTcapStack
   */
  public void attach(JainTcapProvider provider){
           System.out.println("JainTcapStackImpl : attach : attaching provider");
           ((PeerProvider)provider).attached = true;
           ((PeerProvider)provider).attachedStack = this;
  }


  /**
   * Detaches the specified Vendor specific Provider (Peer Provider) from this protocol stack.
   * @param <var>tcapStack</var> the JainTcapStack to attach to.
   * @exception ProviderNotAttachedException thrown if this method is invoked and the
   * specified Peer Provider is not attached to this Stack.
   */
  public void detach(JainTcapProvider provider) throws ProviderNotAttachedException{
           System.out.println("JainTcapStackImpl : detach : detaching provider");
           ((PeerProvider)provider).attached = false;
           ((PeerProvider)provider).attachedStack = null;
  }



   /**
    * Returns the list of <CODE>JainTcapProviders</CODE> that have been created by this
    * <CODE>JainTcapStack</CODE>. All of these <CODE>JainTcapProviders</CODE>
    * will be proprietary objects, but will all will be specific to the same Stack
    * Vendor as this <CODE>JainTcapStack</CODE>. Note that the <CODE>JainTcapProviders</CODE>
    * on this list may be either <em>attached</em> or <em>detached</em>.
    * @return a Vector containing the all the Peer Providers created.
    */
    public  Vector getProviderList(){
            System.out.println("JainTcapStackImpl : getProviderList : getting provider list");
            // NB: return a clone of the providers, so that the internal list cannot be changed
            return (Vector)this.providerList.clone();
    }



  /**
   * Gets the Protocol Version parameter of the TCAPStack.
   * The Protocol version can be used to determine the protocol variant implementation of the TcapStack.
   * <UL>
   * <LI><B>PROTOCOL_VERSION_UNRECOGNISED</B>
   * <LI><B>PROTOCOL_VERSION_UNSUPPORTED</B>
   * <LI><B>PROTOCOL_VERSION_ANSI_92</B>
   * <LI><B>PROTOCOL_VERSION_ANSI_96</B>
   * <LI><B>PROTOCOL_VERSION_ITU_93</B>
   * <LI><B>PROTOCOL_VERSION_ITU_97</B>
   * </UL>
   * @return    the Protocol Version of the TCAP Stack object
   * @exception ParameterNotSetException this exception is thrown if this
   * parameter has not yet been set
   */
  public int getProtocolVersion() {
         System.out.println("JainTcapStackImpl : getProtocolVersion : getting Protocol version");
         return (protocolVersion);
  }


  /**
   * Sets the Protocol Version parameter of the TCAPStack.
   * The Protocol version can be used to determine the protocol variant implementation of the TcapStack.
   * @param <var>protocolVersion</var> the protocol version of this JainTcapStack
   * <UL>
   * <LI><B>PROTOCOL_VERSION_UNRECOGNISED</B>
   * <LI><B>PROTOCOL_VERSION_UNSUPPORTED</B>
   * <LI><B>PROTOCOL_VERSION_ANSI_92</B>
   * <LI><B>PROTOCOL_VERSION_ANSI_96</B>
   * <LI><B>PROTOCOL_VERSION_ITU_93</B>
   * <LI><B>PROTOCOL_VERSION_ITU_97</B>
   * </UL>
   */
  public void setProtocolVersion(int protocolVersion) throws TcapException {
      System.out.println("JainTcapStackImpl : setProtocolVersion : setting protocolVersion");
      this.protocolVersion = protocolVersion;
      protocolVersionSet = true;
  }

  /**
   * Sets the Name of this Stack. This parameter accepts a string of which
   * the recommended format is "SPECIFICATION-YEAR-VENDOR-POINTCODE". Where the pointcode is in the
   * format Signalling_Point_Id(member)-Area_Id(cluster)-Zone_Id(network).
   * For example a Sun Micosystem's implementation could
   * return "ANSI-96-SUN-255-255-255". This string can be used to identify the implementation.
   * @param <var>stackProtocol</var> the stack name.
   */
  public void setStackName(String stackName){
     this.StackName = stackName;
     System.out.println("JainTcapStackImpl : setStackName : setting StackName");
  }

  /**
   * Gets the Stack Name. This parameter string should be returned with the
   * format of "SPECIFICATION-YEAR-VENDOR-POINTCODE". Where the pointcode is in the
   * format Signalling_Point_Id(member)-Area_Id(cluster)-Zone_Id(network).
   * For example a Sun Micosystem's implementation could
   * return "ANSI-96-SUN-255-255-255". This string can be used to identify the implementation.
   * @return  a string describing the Stack
   */
  public String getStackName(){
     System.out.println("JainTcapStackImpl : getStackName : returning StackName");
     return StackName;
  }

  /**
   * The list of <CODE>JainTcapProviders</CODE> that have been created by this
   * <CODE>JainTcapStack</CODE>. All of these <CODE>JainTcapProviders</CODE>
   * will be proprietary objects, but will all will be specific to the same Stack
   * Vendor as this <CODE>JainTcapStack</CODE>. Note that the <CODE>JainTcapProviders</CODE>
   * on this list may be either <em>attached</em> or <em>detached</em>.
   */

  private Vector providerList = new Vector();

  private String StackName = null;
  private int protocolVersion = 0;
  private boolean protocolVersionSet = false;
  private byte[] spc = new byte[100];
}


