/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : Debug.java
 *  Author        : Aidan Mc Gowan  [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */


package com.aepona.jain.protocol.ss7.tcap;



import	java.io.*;
import	java.util.Properties;

/**
 *
 * This class allows to print or log traces depending on a selected level.
 * All the code provided with the product is instrumented using the
 * <CODE>Debug</CODE> class.<p>
 *
 * In order to select the trace level, you need to specify some predefined
 * system properties, and then call the
 * <a href="#parseDebugProperties">parseDebugProperties</a> method of the class.
 *
 * The following system properties can be used for specifying a trace level:
 * <UL>
 * <LI><b>DEBUG</b> for printing all the traces;
 * <LI><b>DEFAULT</b> for printing only messages which are not associated to any trace level;
 * <LI><b>DEBUG_TCAP</b> for printing messages emitted by the Peer Tcap Objects;
 * <LI><b>DEBUG_APP</b> for printing messages emitted by the Tcap Application;
 * <LI><b>DEBUG_PRIMS</b> for printing messages emitted by the TCAP Primitives;
 * <LI><b>DEBUG_OUTPUT=<VAR>filename</VAR></b> for redirecting the debug output to a file;
 * </UL>
 *
 * In addition, when using the class it is possible to select printing of messages
 * which are not associated to any pre-defined tracel level. This is referred to as
 * the default mode. If mode is "false", no message will be printed.
 * If mode is "true", messages will be printed according to the trace level
 * selected. Messages not associated with any trace level will be printed as well.
 *
 * @version     1.0
 * @author      AePONA
 */

public class Debug {

  /**
   * No trace
   */
  public static final int	NO_DEBUG    = 0;
  public static final int   DEBUG_TCAP  = 1;
  public static final int   DEBUG_APP   = 2;
  public static final int   DEBUG_PRIMS = 3;

  public static final int	DEBUG_EXCPT = 64;
  public static final int	TRACE_DEBUG = 128;


  // PRINTING METHODS
  //------------------

  private static void printFormatted(Object arg) {
    if (log_debug != null) {
      log_debug.println(arg);
    } else {
      System.err.println(arg);
    }
  }

  public static void flush() {
    if (log_debug != null) {
      log_debug.flush();
    } else {
      System.err.flush();
    }
  }

  public static void print(Object arg) {
    if (default_debug) {
      printFormatted(arg);
    }
  }

  public static void print(int atLevel, Object arg) {
    if ((level & atLevel) != 0) {
      printFormatted(arg);
    }
  }

  public static void print(boolean condition, Object arg) {
    if (default_debug && condition) {
      printFormatted(arg);
    }
  }

  public static void println(Object arg) {
    if (default_debug) {
      printFormatted(arg + "\n");
    }
  }

  public static void println(int atLevel, Object arg) {
    if ((level & atLevel) != 0) {
      printFormatted(arg + "\n");
    }
  }

  public static void println(boolean condition, Object arg) {
    if (default_debug && condition) {
      printFormatted(arg + "\n");
    }
  }

  public static void printException(Exception e) {
    if ((level & DEBUG_EXCPT) != 0) {
      e.printStackTrace();
    }
  }

  /**
   * Look in the system properties for some trace levels.
   */
  public static void parseDebugProperties() {
    Properties	p = System.getProperties();

    setOffAll();

    if (p.getProperty("DEBUG_OUTPUT") != null) {
      try {
	log_debug = new PrintWriter(new BufferedWriter(new FileWriter(p.getProperty("DEBUG_OUTPUT"))), true);
      } catch (IOException e) {
	System.err.println("Unable to create file for logging debug messages, standard error stream will be used instead: " + e);
      }
    }

    if ((p.getProperty("DEBUG_ALL") != null) ||
	(p.getProperty("DEBUG") != null)) {
      setOnAll();
      return;
    }

	if (p.getProperty("DEBUG_TCAP") != null) {
	  setOn(DEBUG_TCAP);
	}

	if (p.getProperty("DEBUG_APP") != null) {
	  setOn(DEBUG_APP);
	}

 
	if (p.getProperty("DEBUG_PRIMS") != null) {
	  setOn(DEBUG_PRIMS);
	}



	if (p.getProperty("DEBUG_EXCPT") != null) {
	  setOn(DEBUG_EXCPT);
	}

	if (p.getProperty("TRACE_DEBUG") != null) {
	  setOn(TRACE_DEBUG);
	}


	if (p.getProperty("DEFAULT") != null) {
      setDefault(true);
    }

  }

  // GETTERS
  //--------


  /**
   * Get current trace levels selected.
   * The trace level is expressed as a bit map (by ORing the different
   * trace levels defined by the class).
   *
   * @return  the current trace level
   */
   public static int getLevel() {
    return level;
  }

  /**
   * Get current log used for logging debug traces.
   *
   * @return the current PrintWriter stream used for logging debug messages
   *
   */
  public static PrintWriter getLog() {
    return log_debug;
  }

  // SETTERS
  //--------

  /**
   * All the trace levels are on. So, all the traces will be printed.
   */
  public static void setOnAll() {
    level = ~0;
    setDefault(true);
  }

  /**
   * Turn on a specific trace level.
   *
   * @param forLevel the level to turn on
   *
   */
  public static void setOn(int forLevel) {
    level |= forLevel;
  }

  /**
   * Do not print anything. All the levels are off.
   */
  public static void setOffAll() {
    level = 0;
    setDefault(false);
  }

  /**
   * Turn off a specific trace level
   */
  public static void setOff(int forLevel) {
    level &= ~forLevel;
  }

  /**
   * Set the trace level
   *
   * @param i new trace level to use
   */
  public static void setLevel(int l) {
    level = l;
  }

  /**
   * Select default mode. If mode is "false", no message will be printed.
   * If mode is "true", messages will be printed according to the trace level
   * selected. Messages not associated with any trace level will be printed as well.
   *
   * @param l selected default mode
   *
   */
  public static void setDefault(boolean l) {
    default_debug = l;
  }

  /**
   * Set log for debug traces. By default debug traces are printed to the standard error
   * stream. If the reference passed to this method is a null reference then the standard
   * error stream is also used.
   *
   * @param l PrintWriter stream used for logging debug messages
   *
   */
  public static void setLog(PrintWriter l) {
    log_debug = l;
  }

  // PRIVATE VARIABLES
  //------------------


  /**
   * Selected levels
   */
  private static int            level         = 0;

  /**
   * Default mode
   */
  private static boolean        default_debug = false;

  /**
   * Output stream for logging debug messages
   */
  private static PrintWriter    log_debug     = null;
}
