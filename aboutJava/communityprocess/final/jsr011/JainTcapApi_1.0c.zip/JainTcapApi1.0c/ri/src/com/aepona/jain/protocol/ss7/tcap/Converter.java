/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : Converter.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */



package com.aepona.jain.protocol.ss7.tcap;

// jain import
import jain.protocol.ss7.tcap.*;
import jain.protocol.ss7.tcap.component.*;
import jain.protocol.ss7.tcap.dialogue.*;


 /**
   *  Converts received ComponentRequest and DialogueRequest Events to Component and Dialogue
   *  Indication Events.  Sets all Mandatory parameters of Indication Events to equalivalant values
   *  of received Request Event.
   *
   * @version     1.0
   * @author      AePONA
   */

public class Converter{




  /**
    * Converts Component Request Events to Component Indication Events
    *
    * @param <var>requestComponent</var> the request component to be converted
    * @param <var>eventSource</var> the object to act as the event source for the
    * converted component
    * @param <var>lastComponent</var> indicates whether this is the last component being sent
    */
  protected static ComponentIndEvent reqToInd( ComponentReqEvent requestComponent,
                                            Object eventSource,
                                            boolean lastComponent){

    System.out.println("Converter : reqToInd(Component) : In Component convertor");

    // Generic ComponentIndication Event to be returned from this method.
    ComponentIndEvent componentIndication = null;


      // Checks the received component's primitive type.  Depending on primitive
      // type the appropriate parameters are set for each Component.

      switch(requestComponent.getPrimitiveType()) {

            // handles INVOKE components
            case TcapConstants.PRIMITIVE_INVOKE: {

                componentIndication = invokeReqToInd( (InvokeReqEvent)requestComponent,
                                                      eventSource,
                                                      lastComponent);
                break;
            }


            // handles ERROR components
            case TcapConstants.PRIMITIVE_ERROR: {

                componentIndication = errorReqToInd( (ErrorReqEvent)requestComponent,
                                                     eventSource,
                                                     lastComponent);
                break;
            }


            // handles REJECT components
            case TcapConstants.PRIMITIVE_REJECT: {

                componentIndication = rejectReqToInd(   (RejectReqEvent)requestComponent,
                                                        eventSource,
                                                        lastComponent);
                break;
            }


            // handles RESULT components
            case TcapConstants.PRIMITIVE_RESULT: {

                componentIndication = resultReqToInd( (ResultReqEvent)requestComponent,
                                                      eventSource,
                                                      lastComponent);
                break;
            }
      }

      // return the new componentIndication to the object that invoked this method
      return (componentIndication);

  }





  /**
    * Converts Dialogue Request Events to Dialogue Indication Events
    *
    * @param <var>dialogueReq</var> the dialogue request to be converted
    * @param <var>eventSource</var> the object to act as the event source for the
    * converted dialogue
    * @param <var>componentsPresent</var> indicates whether there are any components
    * accompanying this Dialogue primitive
    */
  protected static DialogueIndEvent reqToInd( DialogueReqEvent dialogueReq,
                                           Object eventSource,
                                           boolean componentsPresent) {

    System.out.println("Converter : reqToInd(Dialogue) : In dialogue convertor");

    // Generic DialogueIndication Event to be returned from this method.
    DialogueIndEvent dialogueIndication = null;

    /**
      * Checks the received dialogues's primitive type.  Depending on primitive
      * type the appropriate parameters are set for each Dialogue.
      */
    switch(dialogueReq.getPrimitiveType()) {

      // Dialogue PRIMITIVE of type UNI
      case TcapConstants.PRIMITIVE_UNIDIRECTIONAL :{

            dialogueIndication = uniReqToInd( (UnidirectionalReqEvent)dialogueReq,
                                              eventSource,
                                              componentsPresent);
            break;
      }


      // Dialogue PRIMITIVE of type BEGIN
      case TcapConstants.PRIMITIVE_BEGIN : {

            dialogueIndication = beginReqToInd( (BeginReqEvent)dialogueReq,
                                                eventSource,
                                                componentsPresent);
            break;
      }


      // Dilaogue PRIMITIVE of type CONTINUE
      case TcapConstants.PRIMITIVE_CONTINUE : {

            dialogueIndication = continueReqToInd(  (ContinueReqEvent)dialogueReq,
                                                    eventSource,
                                                    componentsPresent);
            break;
      }


      // Dialogue PRIMITIVE of type END
      case TcapConstants.PRIMITIVE_END : {

            dialogueIndication = endReqToInd( (EndReqEvent)dialogueReq,
                                              eventSource,
                                              componentsPresent);
            break;
      }


      // Dilaogue PRIMITIVE of type USER ABORT
      case TcapConstants.PRIMITIVE_USER_ABORT : {

            dialogueIndication = userAbortReqToInd( (UserAbortReqEvent)dialogueReq,
                                                    eventSource,
                                                    componentsPresent);
            break;
      }
    }
    return(dialogueIndication);
  }



  /**
   * Converts an InvokeReqEvent to an InvokeIndEvent component with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Component indication
   * @param <var>lastComponent</var> indicates whether this is the last component being sent
   */
  private static InvokeIndEvent invokeReqToInd( InvokeReqEvent invokeRequest,
                                                Object eventSource,
                                                boolean lastComponent) {

        InvokeIndEvent invokeIndication = null;
        Operation operation = null;

        try {
            operation = invokeRequest.getOperation();
        } catch (ParameterNotSetException ex) {}

        invokeIndication = new InvokeIndEvent(eventSource, operation, lastComponent);

        invokeIndication.setLastInvokeEvent(invokeRequest.isLastInvokeEvent());

        try {
            invokeIndication.setDialogueId(invokeRequest.getDialogueId());
        } catch (ParameterNotSetException ex) {}


        try {
            invokeIndication.setInvokeId(invokeRequest.getInvokeId());
        } catch (ParameterNotSetException ex) {}


        try {
            invokeIndication.setLinkId(invokeRequest.getLinkId());
        } catch (ParameterNotSetException ex) {}


        try {
            invokeIndication.setParameters(invokeRequest.getParameters());
        } catch (ParameterNotSetException ex) {}


        return (invokeIndication);
  }



  /**
   * Converts an ErrorReqEvent to an ErrorIndEvent component with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Component indication
   * @param <var>lastComponent</var> indicates whether this is the last component being sent
   */
  private static ErrorIndEvent errorReqToInd(   ErrorReqEvent errorRequest,
                                                Object eventSource,
                                                boolean lastComponent){

        ErrorIndEvent errorIndication = null;
        int did = 0;
        int errorType = 0;
        byte[] errorCode = null;

        try {
            did = errorRequest.getDialogueId();
        } catch (ParameterNotSetException ex) {}


        try {
            errorType = errorRequest.getErrorType();
        } catch (ParameterNotSetException ex) {}


        try {
            errorCode = errorRequest.getErrorCode();
        } catch (ParameterNotSetException ex) {}


        errorIndication = new ErrorIndEvent(eventSource,
                                            did,
                                            errorType,
                                            errorCode,
                                            lastComponent);

        try {
            errorIndication.setInvokeId(errorRequest.getInvokeId());
        } catch (ParameterNotSetException ex) {}


        try {
            errorIndication.setParameters(errorRequest.getParameters());
        } catch (ParameterNotSetException ex) {}


        try {
            errorIndication.setLinkId(errorRequest.getLinkId());
        } catch (ParameterNotSetException ex) {}

        return (errorIndication);
  }



  /**
   * Converts an RejectReqEvent to an RejectIndEvent component with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Component indication
   * @param <var>lastComponent</var> indicates whether this is the last component being sent
   */
  private static RejectIndEvent rejectReqToInd( RejectReqEvent rejectReq,
                                                Object eventSource,
                                                boolean lastComponent) {

        RejectIndEvent rejectInd = null;
        int did = 0;
        int problemType = 0;
        int problem = 0;


        try {
            did = rejectReq.getDialogueId();
        } catch (ParameterNotSetException ex) {}


        try {
            problemType = rejectReq.getProblemType();
        } catch (ParameterNotSetException ex) {}


        try {
            problem = rejectReq.getProblem();
        } catch (ParameterNotSetException ex) {}


        rejectInd = new RejectIndEvent( eventSource,
                                        did,
                                        problemType,
                                        problem,
                                        lastComponent);


        try {
            rejectInd.setInvokeId(rejectReq.getInvokeId());
        } catch (ParameterNotSetException ex) {}


        try {
            rejectInd.setParameters(rejectReq.getParameters());
        } catch (ParameterNotSetException ex) {}


        try {
            rejectInd.setLinkId(rejectReq.getLinkId());
        } catch (ParameterNotSetException ex) {}


        return (rejectInd);
  }



  /**
   * Converts a ResultReqEvent to a ResultIndEvent component with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Component indication
   * @param <var>lastComponent</var> indicates whether this is the last component being sent
   */
  private static ResultIndEvent resultReqToInd( ResultReqEvent resultRequest,
                                                Object eventSource,
                                                boolean lastComponent) {

        ResultIndEvent resultIndication = null;
        int did = 0;

        try {
            did = resultRequest.getDialogueId();
        } catch (ParameterNotSetException ex) {}


        resultIndication = new ResultIndEvent(eventSource,
                                              did,
                                              lastComponent,
                                              resultRequest.isLastResultEvent());

        try {
            resultIndication.setInvokeId(resultRequest.getInvokeId());
        } catch (ParameterNotSetException ex) {}


        try {
            resultIndication.setLinkId(resultRequest.getLinkId());
        } catch (ParameterNotSetException ex) {}


        try {
            resultIndication.setParameters(resultRequest.getParameters());
        } catch (ParameterNotSetException ex) {}


        try {
            resultIndication.setOperation(resultRequest.getOperation());
        } catch (ParameterNotSetException ex) {}

        return (resultIndication);
  }



  /**
   * Converts a UnidirectionalReqEvent to a UnidirectionalIndEvent dialogue with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Dialogue indication
   * @param <var>componentsPresent</var> indicates whether there are any components
   * accompanying this Dialogue primitive
   */
  private static UnidirectionalIndEvent uniReqToInd(UnidirectionalReqEvent uniRequest,
                                                    Object eventSource,
                                                    boolean componentsPresent) {

        UnidirectionalIndEvent uniIndication = null;
        TcapUserAddress origAddress = null;
        TcapUserAddress destAddress = null;

        try {
            origAddress = uniRequest.getOriginatingAddress();
        } catch (ParameterNotSetException ex) {}


        try {
            destAddress = uniRequest.getDestinationAddress();
        } catch (ParameterNotSetException ex) {}



        uniIndication = new UnidirectionalIndEvent( eventSource,
                                                    origAddress,
                                                    destAddress,
                                                    componentsPresent);


        try {
            uniIndication.setDialogueId(uniRequest.getDialogueId());
        } catch (ParameterNotSetException e) {}


        try {
            uniIndication.setQualityOfService(uniRequest.getQualityOfService());
        } catch (ParameterNotSetException ex) {}


        try {
            uniIndication.setDialoguePortion(uniRequest.getDialoguePortion());
        } catch (ParameterNotSetException ex) {}



        return (uniIndication);
  }




  /**
   * Converts a BeginReqEvent to a BeginIndEvent dialogue with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Dialogue indication
   * @param <var>componentsPresent</var> indicates whether there are any components
   * accompanying this Dialogue primitive
   */
  private static BeginIndEvent beginReqToInd(   BeginReqEvent beginReq,
                                                Object eventSource,
                                                boolean componentsPresent) {

        BeginIndEvent beginInd = null;
        TcapUserAddress origAddress = null;
        TcapUserAddress destAddress = null;
        int did = 0;

        try {
            origAddress = beginReq.getOriginatingAddress();
        } catch (ParameterNotSetException ex) {}


        try {
            destAddress = beginReq.getDestinationAddress();
        } catch (ParameterNotSetException ex) {}


        try {
            did = beginReq.getDialogueId();
        } catch (ParameterNotSetException e) {}


        beginInd = new BeginIndEvent(eventSource,
                                     did,
                                     origAddress,
                                     destAddress,
                                     componentsPresent);


        try {
            beginInd.setDialoguePortion(beginReq.getDialoguePortion());
        } catch (ParameterNotSetException ex) {}


        try {
            beginInd.setQualityOfService(beginReq.getQualityOfService());
        } catch (ParameterNotSetException ex) {}

        return (beginInd);
  }



  /**
   * Converts a ContinueReqEvent to a ContinueIndEvent dialogue with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Dialogue indication
   * @param <var>componentsPresent</var> indicates whether there are any components
   * accompanying this Dialogue primitive
   */
  private static ContinueIndEvent continueReqToInd( ContinueReqEvent continueRequest,
                                                    Object eventSource,
                                                    boolean componentsPresent) {

        ContinueIndEvent continueIndication = null;
        int did = 0;

        try {
            did = continueRequest.getDialogueId();
        } catch (ParameterNotSetException e) {}

        continueIndication = new ContinueIndEvent(eventSource,
                                                  did,
                                                  componentsPresent);


        try {
        continueIndication.setDialoguePortion(continueRequest.getDialoguePortion());
        } catch (ParameterNotSetException ex) {}


        try {
            continueIndication.setQualityOfService(continueRequest.getQualityOfService());
        } catch (ParameterNotSetException ex) {}

        return (continueIndication);
  }



  /**
   * Converts a EndReqEvent to a EndIndEvent dialogue with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Dialogue indication
   * @param <var>componentsPresent</var> indicates whether there are any components
   * accompanying this Dialogue primitive
   */
  private static EndIndEvent endReqToInd(   EndReqEvent endReq,
                                            Object eventSource,
                                            boolean componentsPresent) {

        EndIndEvent endInd = null;
        int did = 0;

        try {
            did = endReq.getDialogueId();
        } catch (ParameterNotSetException e) {}

        endInd = new EndIndEvent(eventSource,
                                 did,
                                 componentsPresent);


        try {
            endInd.setDialoguePortion(endReq.getDialoguePortion());
        } catch (ParameterNotSetException ex) {}


        try {
            endInd.setQualityOfService(endReq.getQualityOfService());
        } catch (ParameterNotSetException ex) {}


        return (endInd);
  }



  /**
   * Converts a UserAbortReqEvent to a UserAbortIndEvent dialogue with the specified Object
   * acting as the new Event source
   * @param <var>eventSource</var> the EventSource of the new Dialogue indication
   * @param <var>componentsPresent</var> indicates whether there are any components
   * accompanying this Dialogue primitive (never used)
   */
  private static UserAbortIndEvent userAbortReqToInd(   UserAbortReqEvent userAbortReq,
                                                        Object eventSource,
                                                        boolean componentsPresent) {

    UserAbortIndEvent userAbortInd = null;
    int did = 0;

    try {
        did = userAbortReq.getDialogueId();
    } catch (ParameterNotSetException e) {}

    userAbortInd = new UserAbortIndEvent(eventSource, did);


    try {
        userAbortInd.setDialoguePortion(userAbortReq.getDialoguePortion());
    } catch (ParameterNotSetException ex) {}


    try {
        userAbortInd.setQualityOfService(userAbortReq.getQualityOfService());
    } catch (ParameterNotSetException ex) {}

    try {
        userAbortInd.setUserAbortInformation(userAbortReq.getUserAbortInformation());
    } catch (ParameterNotSetException ex) {}


    try {
        userAbortInd.setAbortReason(userAbortReq.getAbortReason());
    } catch (ParameterNotSetException ex) {}
    
    return (userAbortInd);
  }

}
