/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : PeerProvider.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

package com.aepona.jain.protocol.ss7.tcap;

// java import
import java.util.Vector;
import java.util.Hashtable;
import java.util.TooManyListenersException;
import java.util.*;

// jain import
import jain.protocol.ss7.tcap.*;
import jain.protocol.ss7.tcap.component.*;
import jain.protocol.ss7.tcap.dialogue.*;
import jain.protocol.ss7.*;


/**
 * Implements the JainTcapProvider interface.  The provider allows Listeners which
 * implement the JainTcapListener interface to register with it as an event listener.
 * Version 1.0 of the JainTcap RI is resticted to one Listener registration.
 * A Listener can pass TCAP events in the form of ComponentReqEvents and DialogueReqEvents
 * to the Provider.  The Provider stores components in a hashtable indexed by its Dialogue Id.
 * When a DialogueReqEvent is received it triggers the sending of stored components (if any) to
 * registered Listener.  The components associated with the dialogue are converted from Requests
 * to Indications and stored in a simialr table as before.  The Dialogue is then converted in a
 * similar fashion and passed to the registered Listener.  The conversion is via Converter.class.
 * The Component indiaction are then passed to the Listener.
 *
 * @version     1.0
 * @author      AePONA
 */

public class PeerProvider implements JainTcapProvider {

  public PeerProvider(){

    System.out.println("PeerProvider : constructor");
    Hashtable componentTable = new Hashtable();
    Hashtable receivedComponentTable = new Hashtable();

  }

  /**
   * Returns a unique dialogue id to initiate a dialogue with another TCAP user.
   * @return the Dialogue Id returned by the underlying TCAP layer.
   * @exception <var>IdNotAvailableException</var> if there are no more available Dialogue Ids
   */


  public int getNewDialogueId( )  throws IdNotAvailableException {
    System.out.println("PeerProvider : getNewDialogueId : getting a new DialogueId ");

    // Search the dialogueId table for the first available Dialogue Id
    // or until there are no more available Dialogue Ids
    // DialogueID start at one.
    currentDialogueId = MIN_DIALOGUE_ID;

    while(currentDialogueId < MAX_DIALOGUE_IDS) {

        if (dialogueIdTable.isEmpty()) {
          System.out.println("PeerProvider : getNewDialogueId : Dialogue ID Table is empty.");
        }

        if (!dialogueIdTable.containsKey(new Integer(currentDialogueId))){
            // this Dialogue Id is not in use so create a new
            // entry in the Dialogue Id table and return the
            // newly allocated  Diaogue Id

            dialogueIdTable.put(new Integer(currentDialogueId), new Vector());
            System.out.println("PeerProvider : getNewDialogueId : Returning Current Did from Provider : " +currentDialogueId);
            return(currentDialogueId);
        }
        currentDialogueId++;
    }
    // there is no avaliable dialogue ID so throw an Exception
    throw new IdNotAvailableException("PeerProvider : getNewDialogueId : There are no free Dialogue Ids");
  }


  /**
   * Release the dialogue Id back to the system.<br>
   * <b>Note:</b> In some SS7 stacks the TCAP Dialogue Id is automatically
   * released following the end of a TCAP transaction. In such instances the
   * implementation of this method may be left null.
   * @param <var>dialogueId</var> the Dialogue Id to be released
   */
  public void releaseDialogueId(int dialogueId){
        System.out.println("PeerProvider : releaseDialogueId  : releasing DialogueId " +dialogueId );
        dialogueIdTable.remove(new Integer(dialogueId));
  }

  /**
   * Returns a unique Invoke Id for identifying invoke requests within
   * the dialogue identified by the supplied Dialogue Id.
   * Each dialogue between two <CODE>JainTcapListeners</CODE> is identified by
   * a unique Dialogue Id. Note that the returned Invoke Id will be unique
   * for a particular Dialogue Id.
   * @param <var>dialogueId</var> the Dialogue Id for which an Invoke Id will be
   * returned.
   * @return a unique Invoke Id
   * @exception <var>IdNotAvailableException</var> if there are no more available Invoke Ids
   */
  public int getNewInvokeId(int dialogueId)  throws IdNotAvailableException {
        System.out.println("PeerProvider : getNewInvokeId : getting New Invoke ID : " +dialogueId);
        Integer dIdInteger = new Integer(dialogueId);

        if (dialogueIdTable.isEmpty()) {
          System.out.println("PeerProvider : getNewInvokeId : dialogueIdTable is empty");
        }
        else {
          System.out.println("PeerProvider : getNewInvokeId : dialogueIdTable has entries");
        }

        if (!dialogueIdTable.containsKey(dIdInteger)){
            throw new IdNotAvailableException("PeerProvider : getNewInvokeId : " +dialogueId +" is not in use");
        } else {

            // found the Dialogue Id, now check for the first free Invoke Id
            // by checking each invoke Id in turn

            Vector invokeIds = (Vector)dialogueIdTable.get(dIdInteger);
            //  InvokeID of zero not suuported by many SS7 Stacks
            int currentInvokeId = MIN_INVOKE_ID;

            while(currentInvokeId < MAX_INVOKE_IDS_PER_DIALOGUE){
                System.out.println("PeerProvider : getNewInvoke : Checking if Invoke Id " +currentInvokeId +" is free");
                if (!invokeIds.contains(new Integer(currentInvokeId))){

                    // found the first free available Invoke Id
                    // now add it to the list of Invoke Ids used by
                    // this Dialogue and return its value

                    invokeIds.addElement(new Integer(currentInvokeId));
                    System.out.println("PeerProvider : getNewInvokeId : returning currentInvoke Id");
                    return(currentInvokeId);
                }
                currentInvokeId++;
            }
            // there is no avaliable invoke ID so throw an Exception
            throw new IdNotAvailableException("PeerProvider : getNewInvokeId : There are no free Invoke Ids for DialogueId (" +dialogueId +") ");
        }
  }


  /**
   * Releases the unique Invoke Id, allowing it to be reused within
   * the dialogue identified by the supplied Dialogue Id.
   * @param <var>invokeId</var> the Invoke Id to be released back into the system.
   * @param <var>dialogueId</var> the Dialogue Id identifying the dialogue in
   * which the invoke Id is used.
   */
  public void releaseInvokeId(int invokeId, int dialogueId){
        System.out.println("PeerProvider : releaseInvokeId : Attempting to release Invoke Id" +invokeId +" for Dialogue Id" +dialogueId);
        Integer dIdIntObj = new Integer(dialogueId);
        Integer invIdIntObj = new Integer(invokeId);

        if(!dialogueIdTable.containsKey(dIdIntObj)){
            System.out.println("PeerProvider : releaseInvokeId : The dialogue Id table does not contain Dialogue Id " + dialogueId);
        } else {
            Vector invIds = (Vector)dialogueIdTable.get(dIdIntObj);

            if (invIds.contains(invIdIntObj)) {
                invIds.removeElement(invIdIntObj);
                System.out.println("PeerProvider : releaseInvokeId : The Invoke Id has been removed.");
            } else {
                System.out.println("PeerProvider : releaseInvokeId : The Invoke Id is not in use.");
            }
        }
  }

  /**
   * Sends a Component Request primitive.
   * @param <var>event</var> the Component Request event.
   * @exception MandatoryParamsNotSetException thrown if all of the mandatory parameters
   * required by this JainTcapProvider to send the Component Request are not set. <BR>
   * Note that different implementations of this JainTcapProvider will mandate that
   * different parameters must be set for each <CODE>ComponentReqEvent</CODE>.
   * It is reccommended that the detail message returned in the
   * <CODE>MandatoryParamsNotSetException</CODE> should be a <CODE>String</CODE> of the form:
   * <P>
   * <CENTER><B>"Parameter:<parameterName> not set"</B></CENTER>
   *
   */
  public void sendComponentReqEvent(ComponentReqEvent event) throws MandatoryParameterNotSetException {


        // The Reference Implementation checks for the Mandatory dialogue Id only
        // An implementation should check for the all of the mandatory parameters that
        // are required by that implementation
        try {
            int did = event.getDialogueId();

        } catch (MandatoryParameterNotSetException e) {
            String errMsg = "PeerProvider : sendComponentReqEvent : Missing the Mandatory Dialogue Id";
            System.out.println(errMsg);
            throw new MandatoryParameterNotSetException(errMsg);
        }

        System.out.println(" The Event Type is " +event.getPrimitiveType());
        String primName = CommonTools.getPrimitiveName(event.getPrimitiveType()); 
        System.out.println("PeerProvider : sendComponentReqEvent : Received component of type" + CommonTools.getPrimitiveName(event.getPrimitiveType()));
        HandleComponentReq handleComponentReq = new HandleComponentReq(event);
        handleComponentReq.start();
  }

  /**
   * Sends a Dialogue Request primitive. This will trigger the transmission to the
   * destionation node of the Dialogue request primitive along with any asociated
   * Component request primitives that have previously been passed to this Provider.
   * Since the same Provider will be used to handle a particular
   * transaction, Dialogue Request Events with the same Originating Transaction Id
   * must be sent to the same Provider.
   * @param <var>event</var> the Dialogue Request event to be sent into the stack.
   * @exception MandatoryParamsNotSetException thrown if all of the mandatory parameters
   * required by this JainTcapProvider to send the Dialogue Request are not set. <BR>
   * Note that different implementations of this JainTcapProvider will mandate that
   * different parameters must be set for each <CODE>DialogueReqEvent</CODE>.
   * It is reccommended that the detail message returned in the
   * <CODE>MandatoryParamsNotSetException</CODE> should be a <CODE>String</CODE> of the form:
   * <P>
   * <CENTER><B>"Parameter:<parameterName> not set"</B></CENTER>
   *
   */
  public void sendDialogueReqEvent(DialogueReqEvent event) throws MandatoryParameterNotSetException{
    System.out.println("PeerProvider : sendDialogueReqEvent : Received dialogue of type : " + CommonTools.getPrimitiveName(event.getPrimitiveType()));




    // The Reference Implementation checks for the Mandatory dialogue Id only
    // An implementation should check for the all of the mandatory parameters that
    // are required by that implementation
    try {
        int did = event.getDialogueId();
    } catch (MandatoryParameterNotSetException e) {
        String errMsg = "PeerProvider : sendDialogueReqEvent : Missing mandatory Dialogue Id ";

        System.out.println(errMsg);
        throw new MandatoryParameterNotSetException(errMsg);
    }



    HandleDialogueReq handleDialogueReq = new HandleDialogueReq(event);
    handleDialogueReq.start();
  }

  /**
   * Adds a <a href="JainTcapListener.html">JainTcapListener</a>
   * to the list of registered event listeners of this Provider.
   * @param <var>listener</var> the JAIN TCAP Listener to be added.
   * @param <var>userAddressList</var> the list of user address used supported by the
   * JainTcapListener
   * @exception TooManyListenersException thrown if a limit is placed on the allowable
   * number of registered listeners, and this limit is exceeded.
   * @exception  SS7ListenerAlreadyRegisteredException thrown if a JainTcapListener attempts
   * to register as an Event Listener, but is already registered with this Provider.
   */

  public void addJainTcapListener(JainTcapListener listener, TcapUserAddress userAddress)
                               throws   TooManyListenersException, SS7ListenerAlreadyRegisteredException {

        System.out.println("PeerProvider : addJainTcapListener : at start ");

        // first check if another listener is allowed
        // TC_users limited to 255
        if (numListeners >= MAX_LISTENERS) {
            throw new TooManyListenersException("PeerProvider : addJainTcapListener : There are already " +MAX_LISTENERS +" registered.");

        } else {
            // check if the listener is already registered for that UserAddress

            if (listeners.contains(listener) && listener.getUserAddressList().contains(userAddress)) {
                  String errMsg = "PeerProvider : addJainTcapListener : Listener already registered";
                  System.out.println(errMsg);
                  throw new SS7ListenerAlreadyRegisteredException(errMsg);
            } else {
            // none of the Exception categories apply => register the Listener
                listeners.addElement(listener);
                System.out.println("PeerProvider : addJainTcapListener : The supplied Listener has been registered with this Provider");
                }
            }
        }

  /**
   * Removes a <a href="JainTcapListener.html">JainTcapListener</a>
   * from the list of registered listeners of an object implementing this interface.
   * @param <var>listener</var> the TCAP listener to be removed.
   * @exception ListenerNotRegisteredException thrown if the JainTcapListener to be
   * removed is not registered as an Event Listener of this JainTcapProvider.
   */
  public void removeJainTcapListener(JainTcapListener listener)
                                throws SS7ListenerNotRegisteredException {
        System.out.println("PeerProvider : removeJainTcapListener : removing Listener");
        if (!listeners.contains(listener)){
            throw new SS7ListenerNotRegisteredException();
        } else {
       	    listeners.removeElement(listener);
        }
  }


  /**
   * Returns the JainTcapStack that this JainTcapProvider is attached to.
   * @return the attached JainTcapStack.
   * @exception ProviderNotAttachedException thrown if this method is invoked and this JainTcapProvider
   * is not attached to the Stack.
   */
  public JainTcapStack getAttachedStack() throws ProviderNotAttachedException{
      System.out.println("PeerProvider : getAttachedStack : getting Attached Stack");

      if (this.attached = false) {
        String errMsg = "PeerProvider : getAttachedStack : the provider is not currently attached";
        System.out.println(errMsg);
        throw new ProviderNotAttachedException(errMsg);
      }

      return(this.attachedStack);
  }


  /**
   * Indicates if this JainTcapProvider is attached to a JainTcapStack.
   * @return <UL>
   *             <LI><B>true</B> - this JainTcapProvider <B>is</B> attached to a JainTcapStack
   *             <LI><B>false</B> - this JainTcapProvider is <B>not</B> attached to any JainTcapStack
   * </UL>
   */
  public boolean isAttached(){
       System.out.println("PeerProvider : isAttached : checking if stack is attcahed");
       return(this.attached);
  }


  /*
   * The following methods are not defined in the JainTcapProvider interface
   */

  /**
    * Collects all components and stores at appropriate key of the receivedComponentTable(Hash table)
    */
  protected static void fireComponentIndEvent(ComponentIndEvent component){
       System.out.println("PeerProvider : fireComponentIndEvent : at start");

       // integer value used for received component ID value
       int cId = 0;
       try {
          cId = component.getDialogueId();
       } catch (ParameterNotSetException e) {
          System.out.println("PeerProvider : fireComponentReqEvent : could not get Dialogue Id");
       }
       Integer cIdObj = new Integer(cId);

       // Adds received component to the receivedComponentTable, which is a Hashtable.
       // The keys of the hashtable are the DialogueIDs of the received components.
       // If no key corresponding to the received component's DialogueID exists a vector is created
       // to store the component and any other components with the same DialogueID and added to the hashtable.
       if ((!receivedComponentTable.isEmpty())  && (receivedComponentTable.containsKey(cIdObj))) {

          Vector compTemp = (Vector)receivedComponentTable.get(cIdObj);
          System.out.println("PeerProvider : fireComponentReqEvent : Adding received Component to receivedComponentTable");
          compTemp.addElement(component);
          receivedComponentTable.put(cIdObj,compTemp);
       }

       else {
          Vector compTemp = new Vector();
          compTemp.addElement(component);
          receivedComponentTable.put(cIdObj,compTemp);
       }
  }


    /**
     * Gets the address of the registered Listener.  Sends to Listener Dialogues Indication Events
     * and any associated Component Indicatiopn Events.
     */
    protected static void fireDialogueIndEvent(DialogueIndEvent dialogue) {
        System.out.println("PeerProvider : fireDialogueIndEvent : at start");

        // find the registered listener.  Check the destination address against the list of registered listeners.
        // TCK v 1.0c has a listener:provider 1:1 therefore the address of destination
        // is that of the first element and only listener registered.

        JainTcapListener registeredListener = (JainTcapListener)listeners.elementAt(0);

        Vector userAddressList = new Vector();
        userAddressList = registeredListener.getUserAddressList();

        // Send the Dialogue Ind to the registered Listener.
        registeredListener.processDialogueIndEvent(dialogue);
        try {
            dIdObj = new Integer(dialogue.getDialogueId());
        } catch(ParameterNotSetException notSet) {
            System.out.println("PeerProvider : fireDialogueIndEvent : Exception :  " +notSet);
        }

        // Checking component table for elements with same Dialogue Id
        if (receivedComponentTable.containsKey(dIdObj)) {
             System.out.println("PeerProvider : fireDialogueIndEvent : receivedComponentTable.containsKey(dIdObj) ");
             Vector compTempy = (Vector)receivedComponentTable.get(dIdObj);

             for(int i = 0 ; i < compTempy.size();i++) {
                tempCompInd = (ComponentIndEvent)compTempy.elementAt(i);

                // invoking the processComp method of registered Listener
                System.out.println("PeerProvider : fireDialogueIndEvent : invoking the processComp method of registered Listener");

                if (tempCompInd != null){
                    registeredListener.processComponentIndEvent(tempCompInd);
                }
             }

             // Clear the components after they have ALL been sent to registered Listener
             receivedComponentTable.remove(dIdObj);

         } else {
             System.out.println("PeerProvider : fireDialogueIndEvent : No components for this dialogue");
         }

         
  }


  /**
   * Method for adding received components to the ComponentTable
   */
  protected synchronized static void addComponentTable(Integer dIdObj, Vector newList) {
      System.out.println("PeerProvider : addComponentTable : Adding components to table");
      componentTable.put(dIdObj,newList);

  }

  /**
   * checks if a passed index value exists in ComponentTable
   */
  protected synchronized static boolean checkComponentTable(Integer dIdObj) {
      System.out.println("PeerProvider : checkComponentTable : Checking components to table");
      return (componentTable.containsKey(dIdObj));

  }

  /**
   * returns Objects from ComponentTable at Index.
   */
  protected synchronized static Object getItemsComponentTable(Integer dIdObj) {
      System.out.println("PeerProvider : getItemsComponentTable : returning components");
      return (componentTable.get(dIdObj));

  }

  /**
   * removes Objects from ComponentTable at Index.
   */
  protected synchronized static void removeComponentTableItems(Integer dIdObj) {
     System.out.println("PeerProvider : removeComponentTableItems : removing components");
     componentTable.remove(dIdObj);
  }

  private int currentDialogueId = 0;
  private int numListeners = 0;

  /**
   * Vectored List of registered Listeneres
   */
  private static Vector listeners = new Vector();

  /**
   * This hashtable contains Dialogue Ids stored in Integer objects as keys
   * to a Vector containing the Invoke Ids used in this dialogue
   */
  private Hashtable dialogueIdTable = new Hashtable();

  /**
   * This hashtable stores uses a DialogueId as a key to a Vector containing
   * all the request components received for that dialogueId
   */
  private static Hashtable componentTable = new Hashtable();

  /**
   * This hashtable stores all received Components. The DialogueId
   * of the Components is used as a key to a Vector containing
   * all the request components received for that dialogueId from the Support object.
   */
  public static Hashtable receivedComponentTable = new Hashtable();

  // PeerProvider constants
  private static int MAX_DIALOGUE_IDS = 1000000;
  private static int MIN_DIALOGUE_ID = 1;
  private static int MIN_INVOKE_ID = 1;
  private static int MAX_INVOKE_IDS_PER_DIALOGUE = 255;
  private static int MAX_LISTENERS = 255;

  protected boolean attached = false;
  protected JainTcapStack attachedStack = null;
  private static ComponentIndEvent tempCompInd = null;
  private TcapUserAddress destinationAddress = null;
  private static Integer dIdObj = null;

}







