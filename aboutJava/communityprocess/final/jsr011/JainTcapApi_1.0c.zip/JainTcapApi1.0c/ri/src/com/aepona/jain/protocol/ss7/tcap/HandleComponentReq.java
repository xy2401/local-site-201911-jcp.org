/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : HandleComponentReq.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */


package com.aepona.jain.protocol.ss7.tcap;

// java import
import java.util.Vector;
import java.util.Hashtable;
import java.util.TooManyListenersException;
import java.util.*;

// jain import
import jain.protocol.ss7.tcap.*;
import jain.protocol.ss7.tcap.component.*;
import jain.protocol.ss7.tcap.dialogue.*;
import jain.protocol.ss7.*;


/**
  * Components send from a Listener to the PeerProvider class by invocation of the
  * sendComponentReqEvent().  This method invokes the run() method of this class.
  * The Dialogue Id of the received Component is examined and checked against the
  * componentTable.  If an entry of the the DId exists then the component is added to
  * the table at the index, otherwise a new entry in the table is created and the
  * component is added at the point.
  *
  * @version     1.0
  * @author      AePONA
  */

public class HandleComponentReq extends Thread {

  public HandleComponentReq(ComponentReqEvent event) {
      // the Component passed to the Provider from the Listener
      this.event = event;
  }

  public synchronized void run() {

        // get the Dialogue Id of the received Event
        int dId = 0;
        try {
            dId =  event.getDialogueId();
        } catch (ParameterNotSetException e) {
            System.out.println("HandleComponentReq : sendComponentReqEvent : could not get Dialogue Id");
        }

        Integer dIdObj = new Integer(dId);

        // A USER_CANCEL primitive will result in the cancelation of any associated
        // components.  A PRIMITIVE_TIMER_RESET is ignored and not added to the
        // ComponentTable.  All other components are stored in the componentTable.

        // PRIMITIVE_USER_CANCEL
        if(event.getPrimitiveType() == TcapConstants.PRIMITIVE_USER_CANCEL) {
            // The component is a User Cancel => cancel any associated components
            System.out.println("HandleComponentReq : sendComponentReqEvent : Removing Components as result of a User Cancel");
            PeerProvider.removeComponentTableItems(dIdObj);

        // PRIMITIVE_TIMER_RESET
        } else {
            if (event.getPrimitiveType() == TcapConstants.PRIMITIVE_TIMER_RESET) {
                // reset the timers - does nothing
                System.out.println("HandleComponentReq : sendComponentReqEvent : Resetting the Timers");
                System.out.println("HandleComponentReq : Received a TimerResetIndEvent");

            } else {
                if (PeerProvider.checkComponentTable(dIdObj)){
                    System.out.println("HandleComponentReq : sendComponentReqEvent : There are other components stored for this Dialogue Id");
                    System.out.println("HandleComponentReq : sendComponentReqEvent : Adding component to entry for dialogue Id: " +dId);

                    // components are already stored for this DialogueId so add this component to the list
                    Vector comps = (Vector)PeerProvider.getItemsComponentTable(dIdObj);

                    synchronized (comps) {
                       comps.addElement(event);
                    }

                } else {
                    System.out.println("HandleComponentReq : sendComponentReqEvent : There are no components stored for this Dialogue Id");
                    System.out.println("HandleComponentReq : sendComponentReqEvent : Creating entry for dialogue Id: " +dId);

                    // create a new list and add it to the component table
                    Vector newList = new Vector();
                    newList.addElement(event);

                    PeerProvider.addComponentTable(dIdObj,newList);
                }
            }
        }
  }

  // Component to be handled by seperate Thread in run() method
  private ComponentReqEvent event = null;

}
