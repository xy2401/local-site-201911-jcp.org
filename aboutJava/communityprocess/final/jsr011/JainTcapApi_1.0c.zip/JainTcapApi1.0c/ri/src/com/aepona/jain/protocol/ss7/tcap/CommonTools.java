/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : CommonTools.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */




package com.aepona.jain.protocol.ss7.tcap;



import jain.protocol.ss7.tcap.TcapConstants;

   /**
     * This class provides a several convenient utility methods used internally within
     * the Java TCAP implementation.<BR>
     *
     * @version     1.0
     * @author      AePONA
     */


public class CommonTools {


    // type comparison functions


    public static void compare(String variable, byte first,byte second){
      if (first != second) {
        System.out.println("Incorrect: " + variable + " values are NOT the same");
      }
      else {
        System.out.println("Correct: " + variable + " values are the same");
      }
    }


    public static void compare(String variable, short first,short second){
      if (first != second) {
        System.out.println("Incorrect: " + variable + " values are NOT the same");
      }
      else {
        System.out.println("Correct: " + variable + " values are the same");
      }
    }
    public static void compare(String variable, int first,int second){
      if (first != second) {
        System.out.println("Incorrect: " + variable + " values are NOT the same");
      }
      else {
        System.out.println("Correct: " + variable + " values are the same");
      }
    }

    public static boolean compare(String variable, byte[] first,byte[] second){
      if (first.length != second.length){
        System.out.println("Incorrect: " + variable + " values are NOT the same");
        return true;
      }
      for (int i=0;i<first.length;i++){
        if (first[i] != second[i]) {
          System.out.println("Incorrect: " + variable + " values are NOT the same");
          return false;
        }
      } // for
      System.out.println("Correct: " + variable + " values are the same");
      return true;
    }


    public static void printByteArray(byte[] inArray, String arrayName) {
      if (inArray == null) {
        System.out.println("Array: " + arrayName + " is set to null!");
        return;
      }
      for(int i = 0; i < inArray.length; i++) {
        System.out.println("Array: " + arrayName + " Element " + i + " = " + inArray[i]);
      }
    }


    
  public static void main(String args[]){
    byte[] a = null;
    CommonTools test = new CommonTools();
    test.printByteArray(a,"test");

  }


  /**
   * Returns the name of the primitive identified by the primitive type
   */
  public static String getPrimitiveName(int primitiveType) {

    String primitiveName = null;

    switch (primitiveType) {

        case TcapConstants.PRIMITIVE_BEGIN : {
            primitiveName = "BEGIN";
            break;
        }

        case TcapConstants.PRIMITIVE_CONTINUE : {
            primitiveName = "CONTINUE";
            break;
        }

        case TcapConstants.PRIMITIVE_END : {
            primitiveName = "END";
            break;
        }

        case TcapConstants.PRIMITIVE_ERROR : {
            primitiveName = "ERROR";
            break;
        }

        case TcapConstants.PRIMITIVE_INVOKE : {
            primitiveName = "INVOKE";
            break;
        }

        case TcapConstants.PRIMITIVE_LOCAL_CANCEL : {
            primitiveName = "LOCAL_CANCEL";
            break;
        }


        case TcapConstants.PRIMITIVE_NOTICE : {
            primitiveName = "NOTICE";
            break;
        }

        case TcapConstants.PRIMITIVE_PROVIDER_ABORT : {
            primitiveName = "PROVIDER_ABORT";
            break;
        }

        case TcapConstants.PRIMITIVE_REJECT : {
            primitiveName = "REJECT";
            break;
        }


        case TcapConstants.PRIMITIVE_RESULT : {
            primitiveName = "RESULT";
            break;
        }

        case TcapConstants.PRIMITIVE_TIMER_RESET : {
            primitiveName = "TIMER_RESET";
            break;
        }

        case TcapConstants.PRIMITIVE_UNIDIRECTIONAL : {
            primitiveName = "UNI";
            break;
        }

        case TcapConstants.PRIMITIVE_USER_ABORT : {
            primitiveName = "USER_ABORT";
            break;
        }

        case TcapConstants.PRIMITIVE_USER_CANCEL : {
            primitiveName = "USER_CANCEL";
            break;
        }

        default : {
            primitiveName = "Primitive not recognised";

        }
    }

    return primitiveName;
  }

public static byte ZERO   = 0;
public static byte ONE    = 1;
}
