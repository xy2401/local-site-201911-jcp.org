/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Copyrights:
 *
 *  Copyright - 1999 Sun Microsystems, Inc. All rights reserved.
 *  901 San Antonio Road, Palo Alto, California 94043, U.S.A.
 *
 *  This product and related documentation are protected by copyright and
 *  distributed under licenses restricting its use, copying, distribution, and
 *  decompilation. No part of this product or related documentation may be
 *  reproduced in any form by any means without prior written authorization of
 *  Sun and its licensors, if any.
 *
 *  RESTRICTED RIGHTS LEGEND: Use, duplication, or disclosure by the United
 *  States Government is subject to the restrictions set forth in DFARS
 *  252.227-7013 (c)(1)(ii) and FAR 52.227-19.
 *
 *  The product described in this manual may be protected by one or more U.S.
 *  patents, foreign patents, or pending applications.
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  Author:
 *
 *  AePONA Limited, Interpoint Building
 *  20-24 York Street, Belfast BT15 1AQ
 *  N. Ireland.
 *
 *
 *  Module Name   : JAIN TCAP RI
 *  File Name     : HandleDialogueReq.java
 *  Author        : Aidan Mc Gowan + Colm Hayden [Aepona]
 *  Approver      : Aepona JAIN Team
 *  Version       : 1.0
 *  Notes         :
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */


package com.aepona.jain.protocol.ss7.tcap;

// java import
import java.util.Vector;
import java.util.Hashtable;
import java.util.TooManyListenersException;
import java.util.*;

// jain import
import jain.protocol.ss7.tcap.*;
import jain.protocol.ss7.tcap.component.*;
import jain.protocol.ss7.tcap.dialogue.*;
import jain.protocol.ss7.*;


/**
  * Handles any received Dialogue requests from a listener.
  *
  * @version     1.0
  * @author      AePONA
  */

public class HandleDialogueReq extends Thread {

  public HandleDialogueReq(DialogueReqEvent event) {
     System.out.println("HandleDialogueReq : constructor ");
     this.event = event;
  }

  public synchronized void run() {
    System.out.println("HandleDialogueReq : run() : starting ");
    // get the Dialogue Id of the received Event

    int dialogueId = 0;
    try {
        dialogueId =  event.getDialogueId();
        System.out.println("HandleDialogueReq : DialogueID is : " +dialogueId);
    } catch (ParameterNotSetException e) {
        System.out.println("HandleDialogueReq : run() : could not get Dialogue Id");
    }

    boolean componentsPresent = false;
    Integer dialogueIdObj = new Integer(dialogueId);

    if (event.getPrimitiveType() == TcapConstants.PRIMITIVE_UNIDIRECTIONAL   ||
        event.getPrimitiveType() == TcapConstants.PRIMITIVE_BEGIN            ||
        event.getPrimitiveType() == TcapConstants.PRIMITIVE_CONTINUE         ||
        event.getPrimitiveType() == TcapConstants.PRIMITIVE_END) {

        // this Dialogue component will trigger the sending of components
        // So check if this dialogue has any associated components to send

        if (PeerProvider.checkComponentTable(dialogueIdObj)) {

            componentsPresent = true;

            System.out.println("HandleDialogueReq : run() : Component REQ table from PeerProvider has DialogueId Key of received Dialogue ");
            Vector allAsocComps = (Vector)PeerProvider.getItemsComponentTable(dialogueIdObj);

            // for each associated component request convert it to an indication
            // and call the destination node's fireComponentIndEvent() method
            // NB: This is a hack because there is no underlying TCAP implementation
            // and SS7 network to route the components to the destination node based
            // on the User Address
            // NB2: The Destination node will be set as the event source for the
            // indication component

            int numComponents = allAsocComps.size();

            for (int c = 0; c < numComponents ; c++) {

               // check if this is the last component
               boolean lastComponent = (c == (numComponents -1));

               ComponentReqEvent compReq = (ComponentReqEvent)allAsocComps.elementAt(c);
               ComponentIndEvent compInd = Converter.reqToInd(compReq, this, lastComponent);
               System.out.println("HandleDialogueReq : run() :Invoking PeerProvider.fireComponentIndEvent(compInd)");
               PeerProvider.fireComponentIndEvent(compInd);
            }
            System.out.println("HandleDialogueReq : run() : clearing component table");

            // When all Component Requests with the specified DId have been passed to the Converter
            // the table at index is cleared.  This enables other components to be added to the table
            // at this index if they arrive with another message.

            PeerProvider.removeComponentTableItems(dialogueIdObj);

       }

    } else if (event.getPrimitiveType() == TcapConstants.PRIMITIVE_USER_ABORT) {

        // The Dialogue is terminated and no components with the same dialogue ID will be sent.
        System.out.println("HandleDialogueReq : run() : Received User Abort Request - terminating Dialogue ");

        // remove all associated components that may have been sent
        Vector allAsocComp = (Vector)PeerProvider.getItemsComponentTable(dialogueIdObj);
        allAsocComp.clear();

    } else {

        // request received is not recognised - error output to screen.
        System.out.println("HandleDialogueReq : run() : Request received not recognised by JAIN TCAP RI" +event.toString());
    }

    // now convert the Dialogue Request into a dialogue Indication and
    // send it to the destination node in a similar fashion

    DialogueIndEvent dialogueInd = Converter.reqToInd(event, this, componentsPresent);
    PeerProvider.fireDialogueIndEvent(dialogueInd);
    System.out.println("HandleDialogueReq : run() : sendDialogueReqEvent : Sucessfully sent a " +dialogueInd.toString());

  }

   private DialogueReqEvent event = null;
}
