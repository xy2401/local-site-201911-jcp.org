/*
 * @(#)CtorNameTests.java	1.5  02/02/15 21:11:06 Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * public StockSymbol(String symbol) and public String getName() tests
 */

package com.sun.tdk.sampletck.tests.api.StockSymbol;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;


public class CtorNameTests extends MultiTest {

    /* standalone interface */
    public static void main(String argv[]) {
        CtorNameTests test = new CtorNameTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public String getName(),
     * Returns the name of the stock.
     * <br><b>Expected results</b>: StockSymbol(symbol).getName() return 'symbol'
     */
    public Status StockSymbol2001() {
        boolean passed = true;
        String[] symbols = { "ANS", "KAI", "AYC", "", "A" };
    
        for (int i = 0; i != symbols.length; ++i) {
    
            // Step: create new StockSymbol using it's class SSymbol
            // and obtain this StockSymbol name
            String returned = new SSymbol(symbols[i]).getName();
    
            // Step: compare obtained name with expected
            if (returned.compareTo(symbols[i]) != 0) {
                ref.println("getName() returned: " + returned + ", \nexpected: "
                        + symbols[i]);
                passed = false;
            }
        }
        return passed ? Status.passed("OKAY") : Status.failed("Failed");
    }

    /**
     * Assertion testing
     * for public StockSymbol(String symbol),
     * NullPointerException - if the specified symbol is null..
     * <br><b>Expected results</b>: NullPointerException
     */
    public Status StockSymbol2002() {
        try {
            // Step: attempt to create StockSymbol with null name
            new SSymbol(null);
    
            // Step: return Status.failed if no exception is thrown
            return Status.failed("StockSymbol(null): NullPointerException expected");
        } catch (NullPointerException e) {
        }
        return Status.passed("OKAY");
    }
}
