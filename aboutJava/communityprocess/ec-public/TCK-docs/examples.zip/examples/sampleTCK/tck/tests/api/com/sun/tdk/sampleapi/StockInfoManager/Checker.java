/*
 * @(#)Checker.java	1.4  01/15/02 21:11:33 Alexei Semidetnov, Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.tdk.sampletck.tests.api.StockInfoManager;
import com.sun.tdk.sampleapi.*;
import java.io.PrintWriter;


/**
 * Checker meant for checking of StockInfoManager
 * container-specific methods correctness.
 *
 */
class Checker {

    /**
     *   internal container of <code>QuoteAgent</code> objects.
     */
    java.util.Vector state = new java.util.Vector();
    PrintWriter log = null;
    StockInfoManager mgr = null;

    /**
     * Create Checker object
     *
     * @param mgr the <code>StockInfoManager</code> to check elements order within.
     * @param log <code>PrintWriter</code> for errors logging
     */
    public Checker(StockInfoManager mgr, PrintWriter log) {
        this.mgr = mgr;
        this.log = log;
    }

    /**
     * Add element into the linked StockInfoManager
     *
     * @param agent the <code>QuoteAgent</code> object to be added into StockInfoManager.
     */
    public void add(QuoteAgent agent) {
        addAgain(agent);
        state.add(agent);
    }

    /**
     * Add element into the linked StockInfoManager again.
     * This method invocation is applicable if and only if <code>agent</code>
     * was already added via method <code>add(QuoteAgent)</code>.
     *
     * @param agent the <code>QuoteAgent</code> object to be added into StockInfoManager.
     */
    public void addAgain(QuoteAgent agent) {
        mgr.addQuoteAgent(agent);
    }

    /**
     * Remove an element from the linked StockInfoManager lookup table.
     *
     * @param agent the <code>QuoteAgent</code> object to be removed from StockInfoManager.
     */
    public void remove(QuoteAgent agent) {
        mgr.removeQuoteAgent(agent);
        state.remove(agent);
    }

    /**
     * Compare two ordered containers: StockInfoManager lookup table and internal
     * Checker container.
     *
     * @return true if and only if StockInfoManager lookup table and
     *         internal Checker container of <code>QuoteAgent</code> objects
     *         are equal as Enumerations.
     */
    public boolean checkState() {
        if (mgr == null) {
            return false;
        }

        if (!equal(mgr.getQuoteAgents(), state.elements())) {
            return false;
        }
        return true;
    }

    private boolean equal(java.util.Enumeration e1, java.util.Enumeration e2) {
        int idx = 0;

        while (e1.hasMoreElements() && e2.hasMoreElements()) {
            Object o1 = e1.nextElement();
            Object o2 = e2.nextElement();
            log.println(idx + "th element in StockInfoManager lookup table: "
                    + o1);
            log.println("Expected " + idx + "th element: " + o2);

            if (o1 != o2) {
                return false;
            }
            idx++;
        }

        if (e1.hasMoreElements() != e2.hasMoreElements()) {
            log.println("StockInfoManager lookup table length is not equal to expected.");
            return false;
        }
        return true;
    }
}
