/*
 *
 * @(#)SampleStockSource.java	1.5 02/05/15 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampletck.lib;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.Hashtable;

import com.sun.javatest.Test;
import com.sun.javatest.Status;

/**
 * An utility class used to simulate real source of stock information.
 * <P>
 * It can be run in the JavaTest's agent or as a standalone application.
 * When starts it expects -serverPort argument with
 * port number where to start StockServer. 
 * If such parameter is missed or is invalid, server don't start.
 */
public class SampleStockSource implements Test {

    /**
     * Default constructor
     *
     */
    public SampleStockSource() {}

    /**
     * The main entry point for the test. 
     * The args are decoded via decodeAllArgs,
     * then go() method is called to perform the body of the work.
     */
    public Status run(String[] args, PrintWriter log, PrintWriter ref) {
        this.log = log;
        this.ref = ref;

        try {
            decodeAllArgs(args);

            if (port == 0) {
                throw new Fault("No serverPort specified");
            }
            return go();
        } catch (IOException ioe) {
            ioe.printStackTrace(log);
            return Status.error(ioe.getMessage());
        } catch (SampleStockSource.Fault e) {
            e.printStackTrace(log);
            return Status.error(e.getMessage());
        } catch (InterruptedException ie) {
            ie.printStackTrace(log);
            return Status.error(ie.getMessage());
        } finally {
            log.flush();
            serverDown();
        }
    }

    /**
     * Parses the arguments passed to the test.
     *
     * This method embodies the main for loop for all of the
     * execute arguments. It calls <CODE>decodeArg</CODE>
     * "" * for successive arguments in the args array.
     *
     * @param args execute arguments from the test harness or from the
     *             command line.
     *
     * @exception Fault raised when an invalid parameter is passed,
     * or another error occurred.
     *
     * @see #decodeArg
     */
    protected final void decodeAllArgs(String args[]) throws Fault {

        /*
         * Please note, we do not increment i
         * that happens when decodeArg returns the
         * number of array elements consumed
         */
        for (int i = 0; i < args.length;) {
            int elementsConsumed = decodeArg(args, i);

            if (elementsConsumed == 0) {

                // The argument was not recognized.
                throw new Fault("Could not recognize argument: " + args[i]);
            }
            i += elementsConsumed;
        }
    }

    /**
     * Decode the next argument in the argument array.
     * May be overridden to parse additional execute arguments.
     *
     * @param args execute arguments from the test harness or from the
     *             command line
     * @param index current index into args.
     *
     * @exception Fault raised when an invalid argument is passed,
     * or another error occurred.
     *
     * @see #decodeAllArgs
     */
    protected int decodeArg(String argv[], int index) throws Fault {
        if (argv[index].equals("-serverPort")) {
            if (++index < argv.length && !argv[index].startsWith("-")) {
                try {
                    port = Integer.valueOf(argv[index]).intValue();
                } catch (NumberFormatException nfe) {
                    throw new Fault(
                            "Not integer value specified as a serverPort");
                }
                return 2;
            } else {
                throw new Fault("No serverPort specified");
            }
        } else {
            return 0;
        }
    }

    /**
     * Creates a new instance of StockServer on the port specified.
     * and call to <code>serverUp()</code>
     *
     * @return always returns Status.passed
     *
     * @exception IOException if an exception occured during network connection
     * @exception InterruptedException if server has been interrupted
     */
    protected Status go() throws IOException, InterruptedException {
        server = new StockServer(port, log);
        serverUp();
        return Status.passed("OKAY");
    }

    /**
     * Runs the server.
     *
     * @exception IOException if an exception occured during network connection
     * @exception InterruptedException if server has been interrupted
     */
    protected synchronized void serverUp()
            throws IOException, InterruptedException {
        server.start();
        state = RUNNING;

        while (state == RUNNING && !server.isInterrupted()) {
            wait(1000);
        }
    }
    /**
     * Stops the server.
     *
     */
    protected synchronized void serverDown() {
        if (server != null) {
            server.interrupt();
            server = null;
        }
        state = STOPPED;
        notifyAll();
    }

    /**     
     * Standalone interface
     */
    public static void main(String args[]) {
        SampleStockSource sss = new SampleStockSource();
        sss.run(args, new PrintWriter(System.err), new PrintWriter(System.out));
    }
    
    /**
     * Holds port number 
     */
    protected int port = 0;

    /**
     * Holds currently running StockServer object 
     */
    protected StockServer server = null;

    /** 
     * Holds PrintWriter used to print logging information 
     */
    protected PrintWriter log = null;

    /** 
     * Holds PrintWriter used to print logging information 
     */
    protected PrintWriter ref = null;

    /* Reflects server status as running */
    private static final int RUNNING = 1;
    /* Reflects server status as stoped */
    private static final int STOPPED = 0;
    /* Holds current server status */
    private int state = STOPPED;


    /**
     * Exception used to report internal errors.
     */
    public static class Fault extends Exception {

        /**
         * Construct a new Fault object that signals failure
         * with a corresponding message.
         *
         * @param s the string containing a comment
         */
        public Fault(String s) {
            super(s);
        }
    }
}

/* --------------------------------------------------------- */
/* Server implementation part */
/* --------------------------------------------------------- */
class StockServer extends Thread {
    protected ServerSocket serSoc = null;
    protected Socket soc = null;
    protected InputStream in = null;
    protected OutputStream out = null;
    protected PrintWriter log = null;
    protected boolean interrupted = false;
    protected boolean started = false;
    protected Hashtable definedStocks;
    protected int port;

    public StockServer(int port, PrintWriter log) throws IOException {
        this.port = port;
        this.log = log;
        serSoc = new ServerSocket(port);
        definedStocks = new Hashtable();

        for (int i = 0; i < predefinedStocks.length; i++) {
            definedStocks.put(predefinedStocks[i][0], predefinedStocks[i][1]);
        }
        SecurityManager sm = System.getSecurityManager();

        if (sm != null) {
            sm.checkAccept(serSoc.getInetAddress().getHostAddress(),
                    serSoc.getLocalPort());
        }
    }

    public synchronized int getLocalPort() throws IOException {
        if (!interrupted) {
            return serSoc.getLocalPort();
        } else {
            return -1;
        }
    }

    public synchronized void close() {
        try {
            if (serSoc != null) {
                serSoc.close();
            }

            if (soc != null) {
                soc.close();
            }
            soc = null;

            if (in != null) {
                in.close();
            }

            if (out != null) {
                out.close();
            }
        } catch (IOException e) {}
    }

    public void run() {
        log.println("StockServer: started");
        log.flush();
        while (true) {
            accept(10000);
            response();

            if (isInterrupted()) {
                break;
            }
        }
        close();
    }

    private void accept(int soTimeout) {
        if (isStarted() || isInterrupted()) {
            return;
        }

        try {
            serSoc.setSoTimeout(soTimeout);
            Socket soc1 = serSoc.accept();
            setSocket(soc1);
            started();
        } catch (IOException e) {
            log.println("StockServer: throws " + e);
            log.flush();
        }
    }

    private synchronized void setSocket(Socket soc) {
        this.soc = soc;
        notifyAll();
    }

    private synchronized void response() {
        String request = null;

        if (!started || interrupted) {
            return;
        }

        try {
            in = soc.getInputStream();
            request = readFromStream(in);
        } catch (IOException e) {
            log.println("StockServer: throws " + e);
            interrupt();
            return;
        }
        log.println("StockServer: request:  " + request);

        // Append carriage return as end-of-stream sign
        String response = getResponse(request) + "\n";
        log.println("StockServer: response: " + response);

        if (isInterrupted()) {
            return;
        }

        try {
            out = soc.getOutputStream();
            writeToStream(out, response);
        } catch (IOException e) {
            log.println("StockServer: throws " + e);
            interrupt();
            return;
        }
        started = false;
        log.flush();
        notifyAll();
    }

    private synchronized boolean isStarted() {
        return started;
    }

    private synchronized void started() {
        started = true;
    }

    public synchronized boolean isInterrupted() {
        return interrupted;
    }

    public synchronized void interrupt() {
        interrupted = true;
        log.flush();
        close();
        notifyAll();
    }

    /*
     * Request should be in one string only.
     * Returns read line without carriage return.
     */
    protected String readFromStream(InputStream in) throws IOException {
        BufferedReader rdr = new BufferedReader(new InputStreamReader(in,
                encoding));
        return rdr.readLine();
    }

    protected void writeToStream(OutputStream out, String response)
            throws IOException {
        out.write(response.getBytes());
    }

    protected String getResponse(String request) {
        int delimIndex;
        String command = "";
        String params = "";
        String name = "";
        String data = "";
        delimIndex = request.indexOf(':');

        if (delimIndex == -1) {
            log.println("StockServer: Incorrect request: " + request);
            return "FAIL";
        }

        try {
            command = request.substring(0, delimIndex);
            delimIndex++;
            params = request.substring(delimIndex);
        } catch (IndexOutOfBoundsException iobe) {
            log.println("StockServer: " + iobe + " thrown");
            return "FAIL";
        }

        if (command.equals("getStock")) {
            return (String) definedStocks.get(params);
        } else if (command.equals("setStock")) {
            delimIndex = params.indexOf('|');

            if (delimIndex == -1) {
                name = params;
                data = "";
            } else {
                try {
                    name = params.substring(0, delimIndex);
                    delimIndex++;
                    data = params.substring(delimIndex);
                } catch (IndexOutOfBoundsException iobe) {}
            }
            definedStocks.put(name, data);
            return "OKAY";
        } else if (command.equals("serverDown")) {
            interrupt();
            return "OKAY";
        }
        log.println("StockServer: Unknown command " + command);
        return "FAIL";
    }

    // Predefined stocks in format:

    // name|time|price|change|high|low|open|prev

    // All values should be in fixed order. Some may be empty.
    static String[][] predefinedStocks = {
                                           {"ANS", "ANS|17:02|27.5|-3.75|32.14|14.5|24.75|26.3"} , 
                                           {"AYC", "AYC|03:21|7.1|3.4|12.1|3.2|7.4|7"} , 
                                           {"FDA", "FDA|11:59|40.8|3.2|69.13|27|40.3|40.02"} , 
                                           {"KAI", "KAI|00:00|121.3|-32.5|231|120|132|143"}
                                         };
    static String encoding = "US-ASCII";
}
