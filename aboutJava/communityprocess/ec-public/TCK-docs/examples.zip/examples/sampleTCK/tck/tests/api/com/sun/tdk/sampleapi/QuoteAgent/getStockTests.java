/*
 * @(#)getStockTests.java	1.3  02/02/15 21:19:24 Maxim N. Kurzenev
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * QuoteAgent.getStock() method tests
 * Testing QuoteAgent implementation given by default StockInfoManager
 */

package com.sun.tdk.sampletck.tests.api.QuoteAgent;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;
import java.util.Enumeration;

public class getStockTests extends MultiTest {

    /* standalone interface */
    public static void main(String argv[]) {
        getStockTests test = new getStockTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public com.sun.tdk.sampleapi.StockSymbol getStock(java.lang.String symbol),
     * Gets a StockSymbol object for the specified symbol..
     */
    public Status QuoteAgent2001() {
        // Initial step: create an enumeration of available QuoteAgents
        Enumeration agents = StockInfoManager.getDefault().getQuoteAgents();
        StockSymbol ss = null;
        String symbol = "SUNW"; // valid value for symbol
    
        // loop through all available agents
        for(int i = 0;agents.hasMoreElements();i++) {
            QuoteAgent agent = (QuoteAgent)(agents.nextElement());
        
            // Step: try to retrieve the StockSymbol 
            try {
                ss = agent.getStock(symbol);
            } catch (GetQuoteException e) {
                // no exceptions expected
                ref.println(e);
                return Status.failed("Could not retrieve StockSymbol for " 
                        + symbol);
            }
        
            if (!( ss != null               // should not be null
                    /* check if the proper symbol had been retrieved */
                    && ss.getName().equals(symbol) )) { 
                ref.println("Failed on " + i + "th agent : " + agent);
                ref.println("Returned StockSymbol is null? : " + (ss==null));
                ref.println("Returned StockSymbol has unexpected name " 
                    + (ss==null?"N/A":ss.getName().equals(symbol)?"false":"true"));
                return Status.failed("StockSymbol retrieved is incorrect");
            }
        }
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public com.sun.tdk.sampleapi.StockSymbol getStock(java.lang.String symbol),
     * Returns null if the symbol is unknown to this agent..
     */
    public Status QuoteAgent2002() {
        // Initial step: create the default QuoteAgent
        QuoteAgent agent = (QuoteAgent)(StockInfoManager.getDefault().getQuoteAgents().nextElement());
        StockSymbol ss = null;
        String symbol = "UNKNOWN SYMBOL";
    
        // Step: try to retrieve the StockSymbol 
        try {
            ss = agent.getStock(symbol);
        } catch (GetQuoteException e) {
            // no exceptions expected
            ref.println(e);
            return Status.failed("Exception has been thrown instead of returning "
                    + "null for " + symbol);
        }
        if (ss != null) {
            // null expected
            return Status.failed("StockSymbol retrieved is incorrect");
        }
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public com.sun.tdk.sampleapi.StockSymbol getStock(java.lang.String symbol),
     * Throws java.lang.NullPointerException - if the specified symbol is null. .
     */
    public Status QuoteAgent2003() {
        // Initial step: create the default QuoteAgent
        QuoteAgent agent = (QuoteAgent)(StockInfoManager.getDefault().getQuoteAgents().nextElement());
        StockSymbol ss = null;
        String symbol = null;
    
        // Step: try to retrieve the StockSymbol 
        try {
            ss = agent.getStock(symbol);
        } catch(GetQuoteException gqe) {
            gqe.printStackTrace( log);
            return Status.failed("Unexpected exception " + gqe);
        } catch (NullPointerException e) {
            // NPE is thrown as expected
            return Status.passed("OKAY");
        }
        // unexpected behavior
        return Status.failed("NPE has not been thrown.");
    }
}
