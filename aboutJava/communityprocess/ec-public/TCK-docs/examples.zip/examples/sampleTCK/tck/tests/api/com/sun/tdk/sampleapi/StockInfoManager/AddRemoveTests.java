/*
 * @(#)AddRemoveTests.java	1.9  02/02/15 21:19:12 Alexei Semidetnov, Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * StockInfoManager addQuoteAgent() and removeQuoteAgent() methods tests
 */

package com.sun.tdk.sampletck.tests.api.StockInfoManager;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.tdk.sampletck.lib.StockTest;
import com.sun.tdk.sampleapi.*;
import com.sun.tdk.sampletck.lib.SampleQuoteAgent;

public class AddRemoveTests extends StockTest {

    /* standalone interface */
    public static void main(String argv[]) {
        AddRemoveTests test = new AddRemoveTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public void removeQuoteAgent(QuoteAgent agent),
     * If the StockInfoManager lookup table does not contain QuoteAgent passed, calling this method has no effect..
     */
    public Status StockInfoManager2002() {
        boolean passed = true;
        // Step: create StockInfoManager and QuoteAgent objects
        Checker checker = new Checker(new StockInfoManager(), log);
        SampleQuoteAgent agent = new SampleQuoteAgent(host, port, log);
        SampleQuoteAgent agent1 = new SampleQuoteAgent(host, port, log);
        SampleQuoteAgent agent2 = new SampleQuoteAgent(host, port, log);
    
        // Step: invoke container-specific methods 
        // and perform integrity check.
    
        checker.add(agent);
        passed = passed && checker.checkState();
        checker.add(agent1);
        passed = passed && checker.checkState();
        checker.add(agent2);
        passed = passed && checker.checkState();
        checker.addAgain(agent);
        passed = passed && checker.checkState();
        checker.remove(agent);
        passed = passed && checker.checkState();
        checker.add(agent);
        passed = passed && checker.checkState();
        checker.remove(agent);
        passed = passed && checker.checkState();
        checker.remove(agent);
        passed = passed && checker.checkState();
        checker.remove(agent);
        passed = passed && checker.checkState();
        checker.remove(agent1);
        passed = passed && checker.checkState();
        checker.remove(agent2);
        passed = passed && checker.checkState();
        return passed ? Status.passed("OKAY") : Status.failed("Failed");
    }

    /**
     * Assertion testing
     * for public void addQuoteAgent(QuoteAgent agent),
     * NullPointerException - if specified agent is null.
     */
    public Status StockInfoManager2003() {
        try {
            new StockInfoManager().addQuoteAgent(null);
            return Status.failed("Expected NullPointerException");
        } catch (NullPointerException e) {}
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public void removeQuoteAgent(QuoteAgent agent),
     * NullPointerException - if agent is null.
     */
    public Status StockInfoManager2004() {
        try {
            new StockInfoManager().removeQuoteAgent(null);
            return Status.failed("Expected NullPointerException");
        } catch(NullPointerException e) {
        }
    
        return Status.passed("OKAY");
    }
}
