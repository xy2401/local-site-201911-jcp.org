/*
 *
 * @(#)StockTest.java	1.5 02/02/13
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampletck.lib;


import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.StockInfoManager;


/**
 * Base class for Sample TCK's tests which connect to the remote StockServer
 * using it's host and port.
 *
 * This class extends the com.sun.javatest.lib.MultiTest class.
 *
 * The tests derived from this class require two additional execute arguments:
 * <CODE>-serverHost</CODE> and <CODE>-serverPort</CODE>.
 * The typical execute arguments for such tests are:
 * <CODE>-TestCaseID ALL -network.serverHost $host -network.serverPort $port</CODE>.
 *
 * <P>The StockTest class defines two fields:
 * <<CODE>host</CODE>
 * <<CODE>port</CODE>
 * which is initialized by the <CODE>decodeArg()</CODE> method to
 * the specified values.
 *
 * @see com.sun.javatest.lib.MultiTest
 *
 * @version 1.5  02/13/02
 * @author Alexei Semidetnov
 */
public class StockTest extends MultiTest {

    /**
     * Default constructor
     *
     */
    protected StockTest() {}

    /**
     *
     * It checks whether the StockTest specific arguments are supplied.
     *
     * @exception SetupException raised when not all
     *              required arguments are specified.
     *
     */
    protected void init() throws SetupException {
        if (host == null) {
            throw new SetupException("No serverHost specified");
        }

        if (port == 0) {
            throw new SetupException("No serverPort specified");
        }
    }

    /**
     * Decoding hostname and port where StockServer is running
     *
     * This method tries to decode StockTest specific arguments:
     * StockServer's host supplied after '-serverHost';
     * StockServer's port supplied after '-serverPort';
     * from argv starting with current index.
     *
     * @param argv execute arguments from the test harness or from the
     *             command line.
     * @param index current index into argv.
     *
     * @return number of arguments decoded if StockTest specific argument
     *         is recognized, or
     *         <CODE>super.decodeArg( argv, index )</CODE> otherwise.
     *
     * @exception SetupException raised when an invalid argument is passed,
     * or another error occurred.
     *
     */
    protected int decodeArg(String argv[], int index) throws SetupException {
        if (argv[index].equals("-serverHost")) {
            if (++index < argv.length && !argv[index].startsWith("-")) {
                host = argv[index];
                return 2;
            } else {
                throw new SetupException("No serverHost specified");
            }
        } else if (argv[index].equals("-serverPort")) {

            if (++index < argv.length && !argv[index].startsWith("-")) {
                try {
                    port = Integer.valueOf(argv[index]).intValue();
                } catch (NumberFormatException nfe) {
                    throw new SetupException(
                            "Not integer value specified as a serverPort");
                }
                return 2;
            } else {
                throw new SetupException("No serverPort specified");
            }
        } else {
            return super.decodeArg(argv, index);
        }
    }

    /**
     * Store default StockInfoManager,
     * invoke super.invokeTestCase(),
     * and restore default StockInfoManager
     *
     * @param m The test case to be invoked
     *
     * @return Exit status of the test case
     */
    protected Status invokeTestCase(Method m)
            throws IllegalAccessException, InvocationTargetException {
        StockInfoManager defaultMgr = StockInfoManager.getDefault();
        Status status = Status.failed("InvokeTestCase is not called yet");

        try {
            status = super.invokeTestCase(m);
        } finally {
            StockInfoManager.setDefault(defaultMgr);
        }
        return status;
    }
    
    /**
     * Holds host name where the remote server is running.
     */
    protected String host = null;

    /**
     * Holds port number on which the remote server is running.
     */
    protected int port = 0;
}
