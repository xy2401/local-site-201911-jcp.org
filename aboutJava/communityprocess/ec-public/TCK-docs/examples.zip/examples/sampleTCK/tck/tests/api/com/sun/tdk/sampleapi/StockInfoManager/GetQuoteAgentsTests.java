/*
 * @(#)GetQuoteAgentsTests.java	1.9  02/02/15 21:19:12 Alexei Semidetnov, Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * public java.util.Enumeration getQuoteAgents() method tests
 */

package com.sun.tdk.sampletck.tests.api.StockInfoManager;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.tdk.sampletck.lib.StockTest;
import com.sun.tdk.sampleapi.*;
import com.sun.tdk.sampletck.lib.SampleQuoteAgent;

public class GetQuoteAgentsTests extends StockTest {

    /* standalone interface */
    public static void main(String argv[]) {
        GetQuoteAgentsTests test = new GetQuoteAgentsTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public java.util.Enumeration getQuoteAgents(),
     * addQuoteAgent(agent) doesn't change the order in  lookup table..
     */
    public Status StockInfoManager2007() {
        boolean passed = true;
        Checker checker = new Checker(new StockInfoManager(), log);
    
        // The case: SIM LT is empty
        passed = passed && checker.checkState();
    
        SampleQuoteAgent agent = new SampleQuoteAgent(host, port, log);
        SampleQuoteAgent agent1 = new SampleQuoteAgent(host, port, log);
        SampleQuoteAgent agent2 = new SampleQuoteAgent(host, port, log);
    
    
        // Case: SIM LT contains 1 elem
        checker.add(agent);
        passed = passed && checker.checkState();
    
        // Case: SIM LT contains more than 1 element
        checker.add(agent1);
        checker.add(agent2);
    
        passed = passed && checker.checkState();
    
        // Assertion: remove(QA)
        checker.remove(agent1);
        passed = passed && checker.checkState();
    
        return passed ? Status.passed("OKAY"):Status.failed("Failed");
    }
}
