/*
 * @(#)ConstructorTests.java	1.1  01/12/24 14:56:14 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * GetQuoteException ConstructorTest tests
 * Testing serialization process for a class GetQuoteException
 */

package com.sun.tdk.sampletck.tests.api.GetQuoteException.serial;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;
import serial.spec.com.sun.tdk.sampleapi.GetQuoteException;

import javasoft.sqe.serial.StreamObject;
import javasoft.sqe.serial.StreamObjectClass;
import javasoft.sqe.serial.IllegalSerialFormException;
import javasoft.sqe.serial.util.Convert;

import java.io.PrintWriter;

public class ConstructorTests extends MultiTest {

public boolean com(java.lang.Exception e1, java.lang.Exception e2) {
    if (e1 == null) {
        return (e2 == null);
    }
    boolean f = (e1 instanceof java.lang.Exception) &&  
            (e2 instanceof java.lang.Exception);
    if (e1.getMessage() == null) {
        return f && (e2.getMessage() == null);
    } else {
        try {
            return f && (e1.getMessage().compareTo(e2.getMessage()) == 0);
        } catch (java.lang.NullPointerException e) {
            return false;
        }
    }
}

    /* standalone interface */
    public static void main(String argv[]) {
        ConstructorTests test = new ConstructorTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2001() {
        String testCaseID = "serial2001";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException(null, null);
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2001

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2002() {
        String testCaseID = "serial2002";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("", null);
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2002

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2003() {
        String testCaseID = "serial2003";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("string", null);
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2003

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2004() {
        String testCaseID = "serial2004";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException(null, new java.lang.Exception());
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2004

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2005() {
        String testCaseID = "serial2005";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("", new java.lang.Exception());
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2005

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2006() {
        String testCaseID = "serial2006";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("string", new java.lang.Exception());
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2006

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2007() {
        String testCaseID = "serial2007";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException(null, new java.lang.Exception(""));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2007

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2008() {
        String testCaseID = "serial2008";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("", new java.lang.Exception(""));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2008

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2009() {
        String testCaseID = "serial2009";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("string", new java.lang.Exception(""));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2009

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2010() {
        String testCaseID = "serial2010";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException(null, new java.lang.Exception("string"));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2010

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2011() {
        String testCaseID = "serial2011";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("", new java.lang.Exception("string"));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2011

    /**
     * Assertion testing
     * for ConstructorTests,
     * construct GetQuoteException with all valid parameters.
     * <br><b>Expected results</b>: serialization stream has correct fields values
     */
    public Status serial2012() {
        String testCaseID = "serial2012";
        /* Variable for representing the status of the test. */
        boolean failed = false;
    
        /* Set of version */
        double[] versionArray = new double[] {1};
            
        StreamObject so = null;
    
        
    
        /* create GetQuoteException */
        com.sun.tdk.sampleapi.GetQuoteException obj = new com.sun.tdk.sampleapi.GetQuoteException("string", new java.lang.Exception("string"));
    
        try {
    
            /* create StreamObject of com.sun.tdk.sampleapi.GetQuoteException */
            ref.println("Creating StreamObject from Object");
                
            so = Convert.objectToStreamObject(obj);
    
        } catch (java.io.IOException e) {
            failed = true;
            ref.println("Got exception when serializing:");
            e.printStackTrace(ref);
        }
    
        /* Set correct descriptor for OptionalDataBlock */
    
        StreamObjectClass soc = so.getStreamClass();    java.lang.Exception cause = null;
            
        /* Verify all version of serial forms of GetQuoteException
                 according to spec */
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            ref.println("Creating spec class."); 
                GetQuoteException spec = (GetQuoteException)StreamObjectClass.lookup(
                    "serial.spec", "com.sun.tdk.sampleapi.GetQuoteException", v); 
            soc = spec;
    
            try {
                
                /* Read object for version 1.0 */
                if (v >= 1.0) {
    
                    cause = (java.lang.Exception)
                        Convert.streamObjectToObject(
                        so.getObjectField(soc.getField("cause")));
    
                } // end reading object for version 1.0
    
            } catch (java.io.IOException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            } catch (ClassNotFoundException ex) {
                failed = true;
                ref.println("Read incorrect field type. Got exception.");
                ex.printStackTrace(ref);
            }
    
            ref.println("Verifying the constraints on the serial fields");
    
            try {
    
                spec.verify(so);
    
            } catch (IllegalSerialFormException ex) {
                failed = true;
                ref.println("Incorrect serial form. Got exception.");
                ex.printStackTrace(ref);
            }
    
            /* Checking values after serialization */
    
            /* Checking for version 1.0 */
            if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("Field cause not correctly serialized.");
                    }
    
            }
    
        }
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2012
}
