/*
 * @(#)GetXXXTests.java	1.5  02/02/15 21:11:06 Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * public java.awt.Component getVisualComponent() and public abstract Quote getQuote() tests
 */

package com.sun.tdk.sampletck.tests.api.StockSymbol;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;
import java.awt.Component;

public class GetXXXTests extends MultiTest {

    /* standalone interface */
    public static void main(String argv[]) {
        GetXXXTests test = new GetXXXTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public java.awt.Component getVisualComponent(),
     * The quote info is obtained using getQuote method..
     * <br><b>Expected results</b>: SSymbol.getQuoteCalled will set to true
     */
    public Status StockSymbol2003() {
        String[] symbols = { "ANS", "KAI", "AYC" };
    
        for (int i = 0; i < symbols.length; i++) {
    
            // Step: create new StockSymbol child
            SSymbol ss = new SSymbol(symbols[i]);
    
            // Step: reset SSymbol.getQuoteCalled to false 
            ss.reset();
    
            // Step: invoke the method under test
            Component c = ss.getVisualComponent();
    
            // Step: check if StockSymbol.getStock() was called
            // as specified.
            if (!ss.getQuoteCalled) {
                return Status.failed("getQuote() is not called "
                        + "within getVisualComponent()");
            }
        }
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.awt.Component getVisualComponent(),
     * Component returned by a getVisualComponent() method initially invisible and is not added to any container.
     * <br><b>Expected results</b>: returned component has parent set to null and is invisible
     */
    public Status StockSymbol2004() {
        boolean passed = true;
        String[] symbols = { "ANS", "KAI", "AYC" };
    
        for (int i = 0; i != symbols.length; ++i) {
    
            // Step: create StockSymbol child
            SSymbol ss = new SSymbol(symbols[i]);
    
            // Step: reset StockSymbol child flags
            ss.reset();
            Component c = ss.getVisualComponent();
    
            // Step: check if returned Component has no parent.
            if (c.getParent() != null) {
                ref.println("Obtained Component has a valid parent Container: "
                        + c.getParent());
                passed = false;
            }
    
            // Step: check if returned Component is initially invisible
            if (c.isVisible()) {
                ref.println("Obtained Component is initially visible");
                passed = false;
            }
        }
        return passed ? Status.passed("OKAY") : Status.failed("Failed");
    }

    /**
     * Assertion testing
     * for public abstract Quote getQuote(),
     * <br><b>Throws</b>: GetQuoteException - if an i/o exception occurs during stock retrieval.
     */
    public Status StockSymbol2005() {
        boolean passed = true;
        String[] symbols = { "ANS", "KAI", "AYC" };
    
        for (int i = 0; i != symbols.length; ++i) {
    
            // Step: create StockSymbol child
            SSymbol ss = new SSymbol(symbols[i]);
    
            // Step: reset SSymbol.getQuoteCalled to false
            // StockSymbol.getQuote() will not throw GetQuoteException
            ss.reset();
    
            // Step: Obtain Component
            Component c = ss.getVisualComponent();
    
            // Step: following invocations of
            // StockSymbol will lead to GetQuoteException
            ss.reset(true);
    
            // Step: obtain Component and check if
            // no GetQuoteException is thrown
            Component c1 = ss.getVisualComponent();
    
            // Step: check that sequential getVisualComponent calls
            // return  the same reference
            if (c != c1) {
                ref.println("getVisualComponent() sequentially "
                        + "returns different Components: ");
                ref.println("First: " + c);
                ref.println("Second: " + c1);
                passed = false;
            }
        }
        return passed ? Status.passed("OKAY") : Status.failed("Failed");
    }
}
