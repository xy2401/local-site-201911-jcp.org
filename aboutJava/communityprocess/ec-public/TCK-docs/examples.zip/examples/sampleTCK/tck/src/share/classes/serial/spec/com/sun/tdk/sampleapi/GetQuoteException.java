/*
 * @(#)GetQuoteException.java	1.2  02/15/02 21:01:13 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * GetQuoteException specification of serialized form
 * Holds serial form specification for com.sun.tdk.sampleapi.GetQuoteException.
 */

package serial.spec.com.sun.tdk.sampleapi;

import javasoft.sqe.serial.IllegalSerialFormException;
import javasoft.sqe.serial.SerialForm;
import javasoft.sqe.serial.StreamObject;
import javasoft.sqe.serial.StreamObjectClass;
import javasoft.sqe.serial.util.Convert;


public class GetQuoteException extends StreamObjectClass implements SerialForm {
    private double ver;

    public GetQuoteException(double version) {
        super("com.sun.tdk.sampleapi.GetQuoteException", 6922695991225729821L);
        ver = version;

        if (ver >= 1.0) {
            this.setSuperClass(lookup("serial.spec", "java.io.IOException",
                    ver));
        }
    }

    /*
     * This method defines all the serializable fields
     */
    public void define() {
        if (ver >= 1.0) {
            defineField("cause", lookup("serial.spec", "java.lang.Exception",
                    ver));
        }
    }

    /*
     * This method checks for constraints under which the
     * serialized fields are valid
     */
    public void verify(StreamObject streamobj)
            throws IllegalSerialFormException {
        StreamObjectClass soc = streamobj.getStreamClass();

        while (soc.getName().compareTo("com.sun.tdk.sampleapi.GetQuoteException")
                != 0) {
            soc = soc.getSuperClass();
        }

        // Verify default serial form - retrive the fields from a stream
        if (ver >= 1.0) {
            StreamObject cause =
                    streamobj.getObjectField(soc.getField("cause"));
        }
    }
}
