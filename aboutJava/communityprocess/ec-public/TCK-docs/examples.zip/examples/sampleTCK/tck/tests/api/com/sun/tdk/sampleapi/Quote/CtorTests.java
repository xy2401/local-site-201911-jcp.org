/*
 * @(#)CtorTests.java	1.3  02/02/15 21:10:40 Maxim Kurzenev
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Quote constructor tests
 * Tests also field getters
 */

package com.sun.tdk.sampletck.tests.api.Quote;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;


public class CtorTests extends MultiTest {

    // equivalence classes and boundary values for int
    int vals[] = {Integer.MIN_VALUE, Integer.MIN_VALUE+1,
                  -5, -1, 0, 1, 5,
                  Integer.MAX_VALUE-1, Integer.MAX_VALUE};

    /* standalone interface */
    public static void main(String argv[]) {
        CtorTests test = new CtorTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * Creates a new Quote object..
     */
    public Status Quote2001() {
        // Step: setup typical valid values for variables
        String name = "SUNW";                                  
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        // Step: create an instance of Quote
        Quote q = new Quote(name, time, price, change, high, low, open, prev);
        
        // Step: check for creation correctness
        if (!( q != null                         // should not be null   
                && q instanceof Quote            // should be an instance of Quote
                && q.getName().equals(name)      // all the getters should return 
                && q.getTime().getTime() == msec // correct values
                && q.getPrice() == price     
                && q.getChange() == change    
                && q.getHigh() == high      
                && q.getLow() == low        
                && q.getOpen() == open      
                && q.getPrevious() == prev )) {
            // something is wrong if we get here 
            return Status.failed("Failed to create a Quote object");
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>name</b>: empty string, string of length 1.
     * <br><b>Expected results</b>: Creates a new Quote object.
     */
    public Status Quote1001() {
        // Step: setup variables
        String names[] = {"q", "Q", ""};        // short test strings
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        for (int i=0; i < names.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(names[i], time, price, change, high, low, open, prev);
            
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getName().equals(names[i]) )) {
                // something is wrong if we get here
                return Status.failed("Failed to create a Quote object for name=\"" + names[i] + "\"");
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Equivalence class partitioning
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>name</b>: null
     * <br><b>time</b>: valid Date object
     * <br><b>price</b>: valid
     * <br><b>change</b>: valid
     * <br><b>high</b>: valid
     * <br><b>low</b>: valid
     * <br><b>open</b>: valid
     * <br><b>prev</b>: valid.
     * <br><b>Expected results</b>: Will throw NullPointerException
     */
    public Status Quote0001() {
        // Step: setup variables
        String name = null;             
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        try {
            // Step: try to create an instance of Quote
            Quote q = new Quote(name, time, price, change, high, low, open, prev);
        } catch (NullPointerException npe) {
            return Status.passed("OKAY");  // NPE caught as expected
        }
        // getting here indicates incorrect behavior
        return Status.failed("NullPointerException has not been thrown");
    }

    /**
     * Equivalence class partitioning
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>name</b>: valid string
     * <br><b>time</b>: null
     * <br><b>price</b>: valid
     * <br><b>change</b>: valid
     * <br><b>high</b>: valid
     * <br><b>low</b>: valid
     * <br><b>open</b>: valid
     * <br><b>prev</b>: valid.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote0002() {
        // Step: setup variables
        String name = "SUNW";
        java.util.Date time = null;
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        // Step: create an instance of Quote
        Quote q = new Quote(name, time, price, change, high, low, open, prev);
    
        // Step: check for creation correctness
        if (!( q != null                        // should not be null  
                && q instanceof Quote           // should be an instance of Quote
                && q.getTime() == null )) {     // should be null
            // getting here indicates incorrect behavior
            return Status.failed("Failed to create a Quote object for time=" + time);
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>price</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1002() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, vals[i], change, high, low, open, prev);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getPrice() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for price=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>change</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1003() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 10000;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, price, vals[i], high, low, open, prev);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getChange() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for change=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>high</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1004() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 10000;
        int change = 2500;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, price, change, vals[i], low, open, prev);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getHigh() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for high=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>low</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1005() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 10000;
        int change = 2500;
        int high = 105000;
        int open = 97500;
        int prev = 98000;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, price, change, high, vals[i], open, prev);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getLow() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for low=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>open</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1006() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 10000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int prev = 98000;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, price, change, high, low, vals[i], prev);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                    && q instanceof Quote       // should be an instance of Quote
                    && q.getOpen() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for open=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public Quote(java.lang.String name, java.util.Date time, int price, int change, int high, int low, int open, int prev),
     * <br><b>prev</b>: Integer.MIN_VALUE, Integer.MIN_VALUE+1, -1, 0, 1, Integer.MAX_VALUE-1, Integer.MAX_VALUE.
     * <br><b>Expected results</b>: Will create an instance of Quote
     */
    public Status Quote1007() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 10000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        
        for(int i=0; i < vals.length; i++) {
            // Step: create an instance of Quote
            Quote q =  new Quote(name, time, price, change, high, low, open, vals[i]);
    
            // Step: check for creation correctness
            if (!( q != null                    // should not be null  
                   && q instanceof Quote        // should be an instance of Quote
                   && q.getPrevious() == vals[i] )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create a Quote object for prev=" + vals[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }
}
