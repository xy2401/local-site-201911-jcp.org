/* 
 * @(#)StockSymbolTests.java	1.2 03/01/06 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampletck.tests.api.interactive;

import com.sun.tdk.sampleapi.Quote;
import com.sun.tdk.sampleapi.StockSymbol;
import com.sun.tdk.sampleapi.GetQuoteException;

import com.sun.tdk.sampletck.lib.InteractiveTest;
import com.sun.javatest.Status;

import java.awt.Panel;
import java.awt.FlowLayout;
import java.awt.Component;

public class StockSymbolTests extends InteractiveTest {

    /* Quote with positive change */
    private static Quote positiveQ = new Quote("ANS", 
            new java.util.Date( System.currentTimeMillis()),
            234509, 7392, 0, 0, 0, 227117);

    /* Quote with negative change */
    private static Quote negativeQ = new Quote("ANS", 
            new java.util.Date( System.currentTimeMillis()),
            234509, -4123, 0, 0, 0, 238632);

    public Status StockSymbolTest0001() {
        String[] instr  = {
	        "Verify that the StockSymbol is created and placed", 
            "in the grey area below. It should display symbol, time, price,",
            "change and % change. The change should be",
            "rendered in green color."
            };

        String passCondition = "The StockSymbol should be displayed as described";
	    String qn = "Does it appear as described above?";
        String passMsg = "OKAY";
        String failMsg = "StockSymbol is not rendered as expected";
    
        // Add user information
        for(int i = 0; i < instr.length; i++) {
            addInfo(instr[i]);
        }
        addInfo("");
        addInfo(passCondition);
        addInfo("");

        Panel testPanel = new Panel();     //step Construct test panel 
        testPanel.setLayout(new FlowLayout());

        MyStockSymbol mySS= new MyStockSymbol("Test");
        mySS.setQuote( positiveQ);
      
        Component stock = mySS.getVisualComponent();    //step Get Component
        stock.setVisible( true);            //step make Component visible
        testPanel.add( stock);
        addTestPanel(testPanel);		    //step Add test panel to frame

        // Set question that is presented to user
        setQuestion(qn);
    
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);

        // Set title of test frame
        setFrameTitle("StockSymbol Test - StockSymbolTest0001");

        // Set size of test frame
        setFrameSize(600, 400);

	    return Status.passed(""); // will be ignored
    }

    public Status StockSymbolTest0002() {
        String[] instr  = {
	        "Verify that the StockSymbol is created and placed", 
            "in the grey area below. It should display symbol, time, price,",
            "change and % change. The change should be",
            "rendered in red color."
            };

        String passCondition = "The StockSymbol should be displayed as described";
	    String qn = "Does it appear as described above?";
        String passMsg = "OKAY";
        String failMsg = "StockSymbol is not rendered as expected";
    
        // Add user information
        for(int i = 0; i < instr.length; i++) {
            addInfo(instr[i]);
        }
        addInfo("");
        addInfo(passCondition);
        addInfo("");

        Panel testPanel = new Panel();     //step Construct test panel 
        testPanel.setLayout(new FlowLayout());

        MyStockSymbol mySS= new MyStockSymbol("Test");
        mySS.setQuote( negativeQ);
      
        Component stock = mySS.getVisualComponent();    //step Get Component
        stock.setVisible( true);            //step make Component visible
        testPanel.add( stock);
        addTestPanel(testPanel);		    //step Add test panel to frame

        // Set question that is presented to user
        setQuestion(qn);
    
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);

        // Set title of test frame
        setFrameTitle("StockSymbol Test - StockSymbolTest0001");

        // Set size of test frame
        setFrameSize(600, 400);

	    return Status.passed(""); // will be ignored
    }

    public Status StockSymbolTest0003() {
        String[] instr  = {
	        "Verify that the StockSymbol is created and placed", 
            "in the grey area below. It should display the following message:",
            "SymbolName: data not available"
            };

        String passCondition = "The StockSymbol should be displayed as described";
	    String qn = "Does it appear as described above?";
        String passMsg = "OKAY";
        String failMsg = "StockSymbol is not rendered as expected";
    
        // Add user information
        for(int i = 0; i < instr.length; i++) {
            addInfo(instr[i]);
        }
        addInfo("");
        addInfo(passCondition);
        addInfo("");

        Panel testPanel = new Panel();     //step Construct test panel 
        testPanel.setLayout(new FlowLayout());

        MyStockSymbol mySS= new MyStockSymbol("SymbolName");
      
        Component stock = mySS.getVisualComponent();    //step Get Component
        stock.setVisible( true);            //step make Component visible
        testPanel.add( stock);
        addTestPanel(testPanel);		    //step Add test panel to frame

        // Set question that is presented to user
        setQuestion(qn);
    
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);

        // Set title of test frame
        setFrameTitle("StockSymbol Test - StockSymbolTest0001");

        // Set size of test frame
        setFrameSize(600, 400);

	    return Status.passed(""); // will be ignored
    }

    // standalone interface
    public static void main(String argv []) {
        StockSymbolTests test = new StockSymbolTests();
        Status status = test.run(argv, System.err, System.out);
        status.exit();
    }

}

/*
 * Utility class used for interactive tests only.
 * It extends StockSymbol and returns Quote previously installed
 * with setQuote() method.
 * If Quote is not specified with setQuote() method, getQoute()
 * throws GetQuoteException.
 */
class MyStockSymbol extends StockSymbol {
    protected Quote quote;
    public MyStockSymbol(String name) {
        super(name);
        quote = null;
    }

    public void setQuote(Quote quote) {
        this.quote = quote;
    }

    public Quote getQuote() throws GetQuoteException {
        if( quote == null ) {
            throw new GetQuoteException("ERROR", new NullPointerException());
        }
        return quote;
    }
}

