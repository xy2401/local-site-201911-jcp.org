/*
 * @(#)CtorTests.java	1.4  02/02/15 21:10:14 Alexei Semidetnov, Maxim N. Kurzenev
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * GetQuoteException constructor tests
 * Testing GetQuoteException creation; tests getNested method as well.
 */

package com.sun.tdk.sampletck.tests.api.GetQuoteException;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;


public class CtorTests extends MultiTest {

    /* standalone interface */
    public static void main(String argv[]) {
        CtorTests test = new CtorTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public GetQuoteException(String message, Exception nested),
     * Constructs a GetQuoteException with the specified detail message and nested exception..
     */
    public Status GetQuoteException2001() {
        // Step: setup variables
        String message = "The test message for GetQuoteException";
        Exception nested = new IllegalArgumentException();
    
        // Step: create an instance of GetQuoteException
        GetQuoteException c = new GetQuoteException( message, nested); 
    
        // Step: check creation correctness
        if (!( c != null                       // should not be null
                && c instanceof GetQuoteException  // should be an instance of GetQuoteException
                /* getters should return proper values */
                && c.getMessage().equals(message)  
                && c.getNested().equals(nested)   )) {
            // getting here indicates incorrect behavior
            return Status.failed("Failed to create an GetQuoteException object");
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Equivalence class partitioning
     * with input values orientation
     * for public GetQuoteException(String message, Exception nested),
     * <br><b>message</b>: null
     * <br><b>nested</b>: some valid exception.
     * <br><b>Expected results</b>: Will create an instance of GetQuoteException
     */
    public Status GetQuoteException0001() {
        // Step: setup variables
        Exception nested = new IllegalArgumentException();
    
        // Step: create an instance of GetQuoteException
        GetQuoteException c = new GetQuoteException(null, nested); 
    
        // Step: check creation correctness
        if (!( c != null                            // should not be null 
                && c instanceof GetQuoteException   // should be an instance of GetQuoteException 
                && c.getMessage() == null )) {      // getMessage should return null
            // getting here indicates incorrect behavior
            return Status.failed("Failed to create an GetQuoteException object");
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Boundary value analysis
     * with input values orientation
     * for public GetQuoteException(String message, Exception nested),
     * <br><b>message</b>: empty string, string of length 1
     * <br><b>nested</b>: some valid exception.
     * <br><b>Expected results</b>: Constructs an object with the specified message
     */
    public Status GetQuoteException1001() {
        // Step: setup variables
        String messages[] = {"", "q", "QQ"};                // short strings
        Exception nested = new IllegalArgumentException();
    
        for (int i = 0; i < messages.length; i++) {
            // Step: create an instance of GetQuoteException
            GetQuoteException c = new GetQuoteException(messages[i], nested); 
    
            // Step: check creation correctness
            if (!( c != null                                // should not be null 
                    && c instanceof GetQuoteException       // an instance of GetQuoteException ?
                    && c.getMessage().equals(messages[i]) )) {
                // getting here indicates incorrect behavior
                return Status.failed("Failed to create an GetQuoteException object");
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.Exception getNested(),
     * <br><b>return</b>:Nested exception or null if there is no nested exception..
     */
    public Status GetQuoteException2002() {
        // Step: setup variables
        String message = "The test message for GetQuoteException";
        
        // Step: create an instance of GetQuoteException
        GetQuoteException c = new GetQuoteException(message, null); 
    
        // Step: check creation correctness
        if (!( c != null                           // should not be null
                && c instanceof GetQuoteException  // should be an instance of GetQuoteException 
                && c.getNested() == null )) {      // getNested should return proper value
            // getting here indicates incorrect behavior
            return Status.failed("Failed to create an GetQuoteException object");
        }
        // everything is OK
        return Status.passed("OKAY");
    }
}
