/*
 * @(#)SetGetDefTests.java	1.9  02/02/15 21:19:12 Alexei Semidetnov, Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * public static void setDefault(StockInfoManager newDefault) method tests
 */

package com.sun.tdk.sampletck.tests.api.StockInfoManager;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.tdk.sampletck.lib.StockTest;
import com.sun.tdk.sampleapi.*;


public class SetGetDefTests extends StockTest {

    /* standalone interface */
    public static void main(String argv[]) {
        SetGetDefTests test = new SetGetDefTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public static StockInfoManager getDefault(),
     * <br><b>pre-conditions</b>: null StockInfoManager is set.,
     * returns null.
     */
    public Status StockInfoManager2005() {
        StockInfoManager first = new StockInfoManager();
    
        // Step: remember default StockInfoManager
        StockInfoManager second = StockInfoManager.getDefault();
        StockInfoManager third = new StockInfoManager();
    
        // Step: set new default StockInfoManager and check if it was set
        StockInfoManager.setDefault(first);
        StockInfoManager ret = StockInfoManager.getDefault();
    
        if (ret != first) {
            log.println("getDefault() returned: " + ret);
            log.println("expected: " + first);
            return Status.failed("Failed.");
        }
    
        // Step: set new default StockInfoManager and check if it was set
        StockInfoManager.setDefault(first);
        ret = StockInfoManager.getDefault();
    
        if (ret != first) {
            log.println("getDefault() returned: " + ret);
            log.println("expected: " + first);
            return Status.failed("Failed.");
        }
    
        // Step: set new default StockInfoManager and check if it was set
        StockInfoManager.setDefault(second);
        ret = StockInfoManager.getDefault();
    
        if (ret != second) {
            log.println("getDefault() returned: " + ret);
            log.println("expected: " + second);
            return Status.failed("Failed");
        }
    
        // Step: set new default StockInfoManager and check if it was set
        StockInfoManager.setDefault(third);
        ret = StockInfoManager.getDefault();
    
        if (ret != third) {
            log.println("getDefault() returned: " + ret);
            log.println("expected: " + third);
            return Status.failed("Failed");
        }
    
        // Step: restore default StockInfoManager
        StockInfoManager.setDefault(second);
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public static StockInfoManager getDefault(),
     * Gets the default StockInfoManager. This may be null..
     */
    public Status StockInfoManager2006() {
    
        // Step: remember default StockInfoManager
        StockInfoManager mgr = StockInfoManager.getDefault();
        StockInfoManager.setDefault(null);
    
        if (StockInfoManager.getDefault() != null) {
            return Status.failed("getDefault() returned non-null StockInfoManager");
        }
    
        // Step: restore default StockInfoManager
        StockInfoManager.setDefault(mgr);
        return Status.passed("OKAY");
    }
}
