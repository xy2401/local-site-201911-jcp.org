/*
 * @(#)Throwable.java	1.2  02/15/02 21:04:02 Alexei Semidetnov
 *
 * Portions Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Throwable specification of serialized form
 * Holds serial form specification for java.lang.Throwable.
 */

package serial.spec.java.lang;

import java.io.IOException;
import javasoft.sqe.serial.IllegalSerialFormException;
import javasoft.sqe.serial.SerialForm;
import javasoft.sqe.serial.StreamObject;
import javasoft.sqe.serial.StreamObjectClass;


public class Throwable extends StreamObjectClass implements SerialForm {
    private double ver;

    public Throwable(double version) {
        super("java.lang.Throwable", -3042686055658047285L);
        ver = version;
    }

    /**
     * This method defines all the serializable fields
     */
    public void define() {
        if (ver >= 1.1) {
            defineField("detailMessage", STRING);
        }
    }

    /**
     * This method checks for constraints under which the serialized fields
     * are valid
     */
    public void verify(StreamObject streamobj)
            throws IllegalSerialFormException {
        StreamObjectClass soc = streamobj.getStreamClass();

        /* 
         * Verify default serial form - try to retrive the field
         * from a serial stream 
         */
        if (ver >= 1.1) {
            StreamObject dmObj =
                    streamobj.getObjectField(soc.getField("detailMessage"));

            if (dmObj != null) {
                java.lang.String dmString = dmObj.getString();
            }
        }
    }
}
