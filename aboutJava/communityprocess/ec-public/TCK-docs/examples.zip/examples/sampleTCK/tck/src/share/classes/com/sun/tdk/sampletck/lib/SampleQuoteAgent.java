/*
 *
 * @(#)SampleQuoteAgent.java	1.6 02/02/13 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampletck.lib;


import java.util.Date;
import java.net.Socket;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.InputStream;
import java.io.OutputStream;

import com.sun.tdk.sampleapi.Quote;
import com.sun.tdk.sampleapi.QuoteAgent;
import com.sun.tdk.sampleapi.StockSymbol;
import com.sun.tdk.sampleapi.GetQuoteException;

/**
 * An implementation of QuoteAgent.
 * <P>
 * Distributed tests use this class to register it as 
 * an agent at StockInfoManager and later to retrieve stock 
 * information from a custom stock information source (SampleStockSource)
 * <P>
 * Call to <code>getStock()</code> method forces the SampleQuoteAgent to connect
 * to the server over the network, pass the request to the server, parse reply 
 * from the server and then return corresponding StockSymbol object.
 * <P> 
 * For testing purposes this class knows whether <code>getStock()</code>
 * method has been called on it or not. One can know it using 
 * <code>invoked()</code>.
 *
 */

public class SampleQuoteAgent implements QuoteAgent {

    /**
     * Creates a SampleQuoteAgent object to get stock information
     * from the server running on the host <code>host</code> and on the port
     * <code>port</code>. 
     * <P>
     * Sets it's inner state to not-invoked.
     * 
     * @param host hostname of machine where the remote server is running
     * @param port port number on which the remote server is running
     * @param log PrintWriter used to print all logging information
     */
    public SampleQuoteAgent(String host, int port, PrintWriter log) {
        this.host = host;
        this.port = port;
        this.log = log;
        invoked = false;
    }

    /**
     * Returns whether <code>getStock()</code> has been called since 
     * this object creation or since the last call to <code>reset()</code>.
     *
     * @return true if getStock() method has been called since this object
     * creation or since the last call to reset() method.
     */
    public boolean invoked() {
        return invoked;
    }

    /**
     * Resets inner state of this object to not-invoked.
     *
     */
    public void reset() {
        invoked = false;
    }

    /**
     * Actually do all work.
     * <P>
     * Using specified symbol name composes request in a form:
     * <code>"getStock:" + symbol</code>. Then opens socket 
     * connection to the remote server and passes the request 
     * followed by a couple of new line characters to server. Reads response
     * from the server until a new line character occurs in the stream
     * and closes socket connection.
     * <P>
     * The response is parsed assuming it is in the following format:
     * <P>
     * <code>&lt;symbol name&gt;|&lt;date&gt;|&lt;price&gt;|&lt;change&gt;|&lt;high&gt;|&lt;low&gt;|&lt;open&gt;|&lt;previous&gt;</code>
     * <P>
     * Returns StockSymbol object which <code>getQuote()</code> method returns
     * a Quote object created with values parsed from the response.
     *
     * @param symbol symbol of stock to get from the remote server
     *
     * @return StockSymbol object reflecting data got from the remote server
     *
     * @exception GetQuoteException if empty symbol name passed, 
     * IOException caught during network connection or other problem
     * occured during response parsing. 
     */
    public StockSymbol getStock(String symbol) throws GetQuoteException {
        invoked = true;
        if (symbol.length() > 5) {
            return null;
        }

        if (symbol.compareTo("") == 0) {
            throw new GetQuoteException("Trying to get a stock by empty symbol",
                    null);
        }
        String response = "";
        String request = "getStock:" + symbol;
        log.println("SampleQuoteAgent:  Open socket to " + host + " on port "
                + port);

        /* Open connection, pass request, read response 
         * and finally close the connection */
        try {
            synchronized (this) {
                soc = new Socket(host, port);
                is = soc.getInputStream();
                out = soc.getOutputStream();
                out.write(request.getBytes());
                out.write("\n\n".getBytes());
                log.println("SampleQuoteAgent:  request: " + request + " sent");
                int b = is.read();

                while (b != -1 && b != '\n') {
                    response += (char) b;
                    b = is.read();
                }
                log.println("SampleQuoteAgent:  response : " + response);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace(log);
            throw new GetQuoteException("Unexpected IOException", ioe);
        } finally {
            close();
        }

        // Parse response string
        String i_name = "";
        final Date time = new Date(System.currentTimeMillis());
        int i_price = 0, i_change = 0, i_high = 0, i_low = 0;
        int i_open = 0, i_prev = 0;
        int delimIndex = response.indexOf('|');
        int what, startFrom;
        String part = "";
        startFrom = what = 0;

        while (delimIndex != -1) {
            try {
                part = response.substring(startFrom, delimIndex);

                switch (what) {
                  case 0:
                    i_name = part;
                    break;
                  case 1:
                    {
                        int ind = part.indexOf(':');
                        int hour = Integer.parseInt(part.substring(0, ind));
                        ind++;
                        int min = Integer.parseInt(part.substring(ind));
                        time.setTime(time.getTime() - 86400000 + 3600000 * hour
                                +60000 * min);
                    }
                    break;
                  case 2:
                    i_price = Quote.makeInt(part);
                    break;
                  case 3:
                    i_change = Quote.makeInt(part);
                    break;
                  case 4:
                    i_high = Quote.makeInt(part);
                    break;
                  case 5:
                    i_low = Quote.makeInt(part);
                    break;
                  case 6:
                    i_open = Quote.makeInt(part);
                    break;
                  case 7:
                    i_prev = Quote.makeInt(part);
                    break;
                }
            } catch (IndexOutOfBoundsException ioobe) {
                ioobe.printStackTrace(log);
                throw new GetQuoteException(
                        "Unexpected IndexOutOfBoundsException", ioobe);
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace(log);
                throw new GetQuoteException("Unexpected NumberFormatException",
                        nfe);
            }
            startFrom = ++delimIndex;
            delimIndex = response.indexOf('|', startFrom);
            what++;
        }
        final String name = new String(i_name);
        final int price = i_price;
        final int change = i_change;
        final int high = i_high;
        final int low = i_low;
        final int open = i_open;
        final int prev = i_prev;

        return new StockSymbol(name) {

            public Quote getQuote() {
                return new Quote(name, time, price, change, high, low, open,
                        prev);
            }
        };
    }

    /**
     * Closes all network connections.
     *
     */
    public synchronized void close() {
        try {
            if (soc != null) {
                soc.close();
            }

            if (is != null) {
                is.close();
            }

            if (out != null) {
                out.close();
            }
        } catch (IOException ioe) {}
    }

    private String host;
    private int port;
    private PrintWriter log;
    private boolean invoked;
    private Socket soc;
    private InputStream is;
    private OutputStream out;
}
