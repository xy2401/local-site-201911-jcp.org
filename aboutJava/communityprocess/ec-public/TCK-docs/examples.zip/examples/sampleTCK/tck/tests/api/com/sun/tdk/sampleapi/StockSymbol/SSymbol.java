/*
 * @(#)SSymbol.java	1.4 02/02/12 Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 */
package com.sun.tdk.sampletck.tests.api.StockSymbol;

import com.sun.tdk.sampleapi.Quote;
import com.sun.tdk.sampleapi.StockSymbol;
import com.sun.tdk.sampleapi.GetQuoteException;


/**
 * SSymbol is an implementation of <code>com.sun.sampletck.StockSymbol</code>
 * used for testing purposes. It defines getQuote() method and a number of
 * utility methods used to control its behaviour and its state.
 */
class SSymbol extends StockSymbol {
    Quote q = null;
    boolean getQuoteCalled;
    String expectedName = null;
    boolean throwGetQuoteException = false;

    /**
     * Create a new SSymbol object with specified stock name
     * and call <code>reset()</code> on it. 
     * @param name  A name of the stock
     * @see #reset() reset()
     */
    public SSymbol(String name) {
        super(name);
        expectedName = name;
        reset();
    }

    /**
     * Reset the inner state of the object. Marks that getQuote() was not
     * called and forces the next call to getQuote() to throw an exception
     * if <code>throwGetQuoteException</code> set to true, or do not throw
     * otherwise.
     * @param throwGetQuoteException if true, following calls
     * of <code>getQuote()</code> method will cause <code>GetQuoteException</code>
     *  to be thrown.
     */
    void reset(boolean throwGetQuoteException) {
        getQuoteCalled = false;
        this.throwGetQuoteException = throwGetQuoteException;
    }

    /**
     * The synonim to <code>reset(false)</code>.
     * @see  #reset(boolean) reset(boolean)
     */
    void reset() {
        reset(false);
    }

    /**
     * Get the quote object that reflects this stock symbol.
     * It always returns valid <code>Quote</code> object except when
     * the <code>reset(true)</code> has been called previously.
     * <p>Call to this method always sets <code>getQuoteCalled</code> to true.
     * @throws <code>GetQuoteException</code> if <code>reset(true)</code>
     * has been called previously.
     * @see #reset(boolean) reset(boolean)
     */
    public Quote getQuote() throws GetQuoteException {
        getQuoteCalled = true;

        if (throwGetQuoteException) {
            throw new GetQuoteException("GQE is thrown by test request", null);
        }

        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        return new Quote(name, time, price, change, high, low, open, prev);
    }
}
