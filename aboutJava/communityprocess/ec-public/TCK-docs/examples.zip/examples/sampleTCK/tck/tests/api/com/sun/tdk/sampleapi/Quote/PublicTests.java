/*
 * @(#)PublicTests.java	1.3  02/02/15 21:10:40 Maxim Kurzenev
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Quote public methods tests
 */

package com.sun.tdk.sampletck.tests.api.Quote;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;


public class PublicTests extends MultiTest {

    // integer test values
    int ints[] = {-2147483648, -2147483647, -543,
                  -100, -1, 0, 1, 234, 2345, 1000000,
                  2147483646, 2147483647};

    // Strings corresponding to ints[]
    String strs[] = {"-214748.3648", "-214748.3647", "-0.0543",
                     "-0.01", "-0.0001", "0", "0.0001", "0.0234", "0.2345", "100",
                     "214748.3646", "214748.3647"};

    /* standalone interface */
    public static void main(String argv[]) {
        PublicTests test = new PublicTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringPrice(),
     * String representation of price with decimal placed back in the correct spot.
     */
    public Status Quote2002() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringPrice().equals(strs[i])) {
                // getting here indicates incorrect behavior
                return Status.failed("getStringPrice returns incorrect value: "
                        + q.getStringPrice() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringChange(),
     * String representation of change with decimal placed back in the correct spot.
     */
    public Status Quote2003() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringChange().equals(strs[i])) {
                // getting here indicates incorrect behavior
                return Status.failed("getStringChange returns incorrect value: "
                        + q.getStringChange() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringHigh(),
     * String representation of the 52-week high with decimal placed back in the correct spot.
     */
    public Status Quote2004() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringHigh().equals(strs[i])) {
                return Status.failed("getStringHigh returns incorrect value: "
                        + q.getStringHigh() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringLow(),
     * String representation of the 52-week low with decimal placed back in the correct spot.
     */
    public Status Quote2005() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringLow().equals(strs[i])) {
                // getting here indicates incorrect behavior
                return Status.failed("getStringLow returns incorrect value: "
                        + q.getStringLow() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringOpen(),
     * String representation of the opening price with decimal placed back in the correct spot.
     */
    public Status Quote2006() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringOpen().equals(strs[i])) {
                return Status.failed("getStringOpen returns incorrect value: "
                        + q.getStringOpen() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public java.lang.String getStringPrevious(),
     * String representation of previous with decimal placed back in the correct spot.
     */
    public Status Quote2007() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
    
        for (int i=0; i < ints.length; i++) {
            // Step: create an instance of Quote
            Quote q = new Quote(name, time, ints[i], ints[i], ints[i], ints[i], ints[i], ints[i]);
    
            // Step: check for correctness of return value
            if (!q.getStringPrevious().equals(strs[i])) {
                // getting here indicates incorrect behavior
                return Status.failed("getStringPrevious returns incorrect value: "
                        + q.getStringPrevious() + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public static java.lang.String convert(int intNum),
     * Convert an int into a String with the decimal placed back in..
     */
    public Status Quote2008() {
        for (int i=0; i < ints.length; i++) {
            // Step: call for static method, check result
            if (!Quote.convert(ints[i]).equals(strs[i])) {
                // getting here indicates incorrect behavior
                return Status.failed("convert returns incorrect value: "
                        + Quote.convert(ints[i]) + " while expected " + strs[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public static int makeInt(java.lang.String source),
     * Take a String representation of a floating point number and make an int out of it..
     */
    public Status Quote2009() {
        for (int i=0; i < ints.length; i++) {
            // Step: call for static method, check result
            if (Quote.makeInt(strs[i]) != ints[i]) {
                // getting here indicates incorrect behavior
                return Status.failed("makeInt returns incorrect value: "
                        + Quote.makeInt(strs[i]) + " while expected " + ints[i]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public static int makeInt(java.lang.String source),
     * Looking at a maximum of 4 fractional places (trim exceeding).
     */
    public Status Quote2010() {
        // Step: setup variables
        String ss[] = {"1.23456", "1.2345", "-1.23456", "-1.2345"}; // test strings
        int is[] = {12345, 12345, -12345, -12345};        // corresponding integers
    
        for (int j=0; j < is.length; j++) {
            // Step: call for static method, check result
            if (Quote.makeInt(ss[j]) != is[j]) {
                // getting here indicates incorrect behavior
                return Status.failed("makeInt returns incorrect value: "
                        + Quote.makeInt(ss[j]) + " while expected " + is[j]);
            }
        }
        // everything is OK
        return Status.passed("OKAY");
    }

    /**
     * Assertion testing
     * for public static int makeInt(java.lang.String source),
     * throws java.lang.NumberFormatException - if the source is null or after applying specified operations does not represent a valid int.
     */
    public Status Quote2011() {
        // Step: try to call for makeInt with null argument
        try {
            int i = Quote.makeInt(null);
        } catch (NumberFormatException e) {
            return Status.passed("OKAY"); // NFE caught as expected
        }
        // NFE have not been caught: wrong behavior
        return Status.failed("NumberFormatException has not been thrown for null source");
    }

    /**
     * Assertion testing
     * for public static int makeInt(java.lang.String source),
     * throws java.lang.NumberFormatException - if the source is null or after applying specified operations does not represent a valid int.
     */
    public Status Quote2012() {
        // Step: try to call for makeInt with too large argument
        try {
            int i = Quote.makeInt("1234567");
        } catch (NumberFormatException e) {
            return Status.passed("OKAY"); // NFE caught as expected
        }
        // NFE have not been caught: wrong behavior
        return Status.failed("NumberFormatException has not been thrown for source=1234567");
    }

    /**
     * Assertion testing
     * for public java.lang.String toString(),
     * String representation of this quote in the format getName()+" "+getStringPrice()+" at " +getTime()+" "+ getStringChange().
     */
    public Status Quote2013() {
        // Step: setup variables
        String name = "SUNW";
        long msec = 1000000000l;
        java.util.Date time = new java.util.Date(msec);
        int price = 100000;
        int change = 2500;
        int high = 105000;
        int low = 95000;
        int open = 97500;
        int prev = 98000;
        
        // Step: create an instance of Quote
        Quote q = new Quote(name, time, price, change, high, low, open, prev);
        
        // Step: check results
        // toString should return specified value
        if (!q.toString().equals(q.getName() + " " + q.getStringPrice() + " at " 
                + q.getTime() + " " + q.getStringChange())) {  
            // getting here indicates incorrect behavior
            return Status.failed("toString method works incorrectly");
        }
        // everything is OK
        return Status.passed("OKAY");
    }
}
