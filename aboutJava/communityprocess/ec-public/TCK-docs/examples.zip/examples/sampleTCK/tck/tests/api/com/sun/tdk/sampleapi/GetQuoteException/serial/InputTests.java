/*
 * @(#)InputTests.java	1.1  01/12/24 14:56:14 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * GetQuoteException InputTests tests
 * Testing deserialization process for a class GetQuoteException
 */

package com.sun.tdk.sampletck.tests.api.GetQuoteException.serial;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;
import com.sun.tdk.sampleapi.*;
import serial.spec.com.sun.tdk.sampleapi.GetQuoteException;

import javasoft.sqe.serial.StreamObject;
import javasoft.sqe.serial.StreamObjectClass;
import javasoft.sqe.serial.IllegalSerialFormException;
import javasoft.sqe.serial.util.Convert;

import java.io.PrintWriter;

public class InputTests extends MultiTest {

public boolean com(java.lang.Exception e1, java.lang.Exception e2) {
    if (e1 == null) {
        return (e2 == null);
    }
    boolean f = (e1 instanceof java.lang.Exception) &&  
            (e2 instanceof java.lang.Exception);
    if (e1.getMessage() == null) {
        return f && (e2.getMessage() == null);
    } else {
        try {
            return f && (e1.getMessage().compareTo(e2.getMessage()) == 0);
        } catch (java.lang.NullPointerException e) {
            return false;
        }
    }
}

    /* standalone interface */
    public static void main(String argv[]) {
        InputTests test = new InputTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Assertion testing
     * for InputTests,
     * Create a stream with correct values.
     * <br><b>Expected results</b>: Deserialized object must have appropriate values
     */
    public Status serial2013() {
        String testCaseID = "serial2013";
        com.sun.tdk.sampleapi.GetQuoteException obj;
    
        StreamObject so;
        StreamObjectClass soc;
    
        StreamObject so2;
        StreamObjectClass ssoc;
        StreamObjectClass soc2;
    
        boolean failed = false;
    
        double[] versionArray = new double[] {1};
    
        // Checking for all versions of Sample API
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            try {
    
                /* create StreamObject from spec */
                ref.println("Creating StreamObject from spec"); 
                soc = StreamObjectClass.lookup ("serial.spec", 
                                                "com.sun.tdk.sampleapi.GetQuoteException", v);
                so = new StreamObject(soc);
                    
                /* Prepairing fields values for a stream */
    
                
        java.lang.Exception cause = null;
    
    
                /* set value of serial field for the following
                             assertion test */
                ref.println("Setting the value of serial fields");
    
                /* Creating values for version 1.0 */
                if (v >= 1.0) {
    
                    if (cause == null) {
                        so2 = null;
                    } else {
                        so2 = Convert.objectToStreamObject(cause);
                    }
                    so.setObjectField(soc.getField("cause"), so2);
    
                    }
                    
                /* Use Convert class to get a GetQuoteException object */
                ref.println("Converting the StreamObject to Object");
                obj = (com.sun.tdk.sampleapi.GetQuoteException)Convert.
                        streamObjectToObject(so);
                    
                /* Assertion Test */
                ref.println("Assertion test");
    
                /* Checking for version 1.0 */
                if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("cause value of GetQuoteException"
                            + " failed assertion check.");
                    }
    
                }
    
            } catch (java.io.IOException e) {
                failed = true;
                ref.println("I/O error. Got exception:");
                e.printStackTrace(ref);
            } catch (ClassNotFoundException e) {
                failed = true;
                ref.println("Class not found. Got exception:");
                e.printStackTrace(ref);
            }   
        }
    
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2013

    /**
     * Assertion testing
     * for InputTests,
     * Create a stream with correct values.
     * <br><b>Expected results</b>: Deserialized object must have appropriate values
     */
    public Status serial2014() {
        String testCaseID = "serial2014";
        com.sun.tdk.sampleapi.GetQuoteException obj;
    
        StreamObject so;
        StreamObjectClass soc;
    
        StreamObject so2;
        StreamObjectClass ssoc;
        StreamObjectClass soc2;
    
        boolean failed = false;
    
        double[] versionArray = new double[] {1};
    
        // Checking for all versions of Sample API
        for (int i = 0; i < versionArray.length; i++) {
            double v = versionArray[i];
            ref.println("Checking for Sample API Version : " + v);
                
            try {
    
                /* create StreamObject from spec */
                ref.println("Creating StreamObject from spec"); 
                soc = StreamObjectClass.lookup ("serial.spec", 
                                                "com.sun.tdk.sampleapi.GetQuoteException", v);
                so = new StreamObject(soc);
                    
                /* Prepairing fields values for a stream */
    
                  
        java.lang.Exception cause = new java.lang.Exception();
    
    
                /* set value of serial field for the following
                             assertion test */
                ref.println("Setting the value of serial fields");
    
                /* Creating values for version 1.0 */
                if (v >= 1.0) {
    
                    if (cause == null) {
                        so2 = null;
                    } else {
                        so2 = Convert.objectToStreamObject(cause);
                    }
                    so.setObjectField(soc.getField("cause"), so2);
    
                    }
                    
                /* Use Convert class to get a GetQuoteException object */
                ref.println("Converting the StreamObject to Object");
                obj = (com.sun.tdk.sampleapi.GetQuoteException)Convert.
                        streamObjectToObject(so);
                    
                /* Assertion Test */
                ref.println("Assertion test");
    
                /* Checking for version 1.0 */
                if (v >= 1.0) {
    
                    if (!com(cause, obj.getNested())) {
                        failed = true;
                        ref.println("cause value of GetQuoteException"
                            + " failed assertion check.");
                    }
    
                }
    
            } catch (java.io.IOException e) {
                failed = true;
                ref.println("I/O error. Got exception:");
                e.printStackTrace(ref);
            } catch (ClassNotFoundException e) {
                failed = true;
                ref.println("Class not found. Got exception:");
                e.printStackTrace(ref);
            }   
        }
    
        if (failed) {
            ref.println(testCaseID + " failed.");
            return Status.failed("FAILED");
        } else {
            ref.println(testCaseID + " passed.");
            return Status.passed("OKAY");
        }  
    } //end method GetQuoteException.serial2014
}
