/*
 * @(#)DistributedTests.java	1.9  02/02/15 21:19:12 Alexei Semidetnov, Boris B. Kvartskhava
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * public StockSymbol getStock(java.lang.String symbol) distributed tests
 */

package com.sun.tdk.sampletck.tests.api.StockInfoManager;

import java.io.PrintWriter;
import com.sun.javatest.Status;
import com.sun.tdk.sampletck.lib.StockTest;
import com.sun.tdk.sampleapi.*;
import com.sun.tdk.sampletck.lib.SampleQuoteAgent;
import java.util.Enumeration;

public class DistributedTests extends StockTest {

    /* standalone interface */
    public static void main(String argv[]) {
        DistributedTests test = new DistributedTests();
        test.run(argv, System.err, System.out).exit();
    }

    /**
     * Equivalence class partitioning
     * with state, input and output values orientation
     * for public StockSymbol getStock(java.lang.String symbol),
     * <br><b>pre-conditions</b>: StockInfoManager lookup table contains QuoteAgents that might return requested StockSymbol instance,
     * <br><b>symbol</b>: some String
     * <br><b>output</b>: requested StockSymbol.
     * <br><b>Expected results</b>: Returns requested StockSymbol instance through the QuoteAgent installed
     */
    public Status StockInfoManager0001() {
        String testCaseID = "StockInfoManager0001";
        ref.println("====== " + testCaseID + " ======" + " public StockSymbol getStock(java.lang.String symbol)");
        // Step: create StockInfoManager and QuoteAgent objects
        StockInfoManager manager = new StockInfoManager();
        SampleQuoteAgent agent = new SampleQuoteAgent(host, port, log);
    
        // Step:  add QuoteAgent into the StockInfoManager lookup table.
        manager.addQuoteAgent(agent);
        String[] symbols = { "ANS", "KAI", "AYC" };
    
        for (int i = 0; i < symbols.length; i++) {
            // Step: attempt to obtain StockSymbol through StockInfoManager
            agent.reset();
            StockSymbol ss = manager.getStock(symbols[i]);
    
            // Step: check if 
            // 1. returned StockSymbol is not null
            // 2. A name of StockSymbols is equal to expected one.
            // 3. The method getStock(String) of class SampleQuoteAgent
            //    was called. 
            if (!(ss != null                            // could not be null
                    && ss.getName().equals(symbols[i])  // returned is requested stock
                    && agent.invoked() )) {             // returned from first added agent
                ref.print("Returned StockSymbol is null, has incorrect name or ");
                ref.println("retrieved not from the first added agent");
                return Status.failed("public StockSymbol getStock(java.lang.String symbol) Test Failed");
            }
        }
        return Status.passed("OKAY");
    }

    /**
     * Equivalence class partitioning
     * with state, input and output values orientation
     * for public StockSymbol getStock(java.lang.String symbol),
     * <br><b>pre-conditions</b>: StockInfoManager lookup table is empty,
     * <br><b>symbol</b>: some String
     * <br><b>output</b>: null.
     */
    public Status StockInfoManager0002() {
        String testCaseID = "StockInfoManager0002";
        ref.println("====== " + testCaseID + " ======" + " public StockSymbol getStock(java.lang.String symbol)");
        
        StockInfoManager manager = new StockInfoManager();
        
        // Step: create StockInfoManager and QuoteAgent objects.
        SampleQuoteAgent agent = new SampleQuoteAgent( host, port, log);
        manager.addQuoteAgent( agent);
    
        String[] symbols = {"ANS", "KAI", "AYC"};
    
        for(int i = 0; i < symbols.length; i++) {
            agent.reset();
            StockSymbol ss = manager.getStock( symbols[i]);
    
            // Step: check if 
            // 1. returned StockSymbol is not null
            // 2. A name of StockSymbols is equal to expected one.
            // 3. The method getStock(String) of class SampleQuoteAgent
            //    was called. 
            if(!( ss != null                             // could not be null
                    && ss.getName().equals( symbols[i])  // returned is requested stock
                    && agent.invoked() )) {              // returned from first added agent
                ref.print("Returned StockSymbol is null, has incorrect name or ");
                ref.println("retrieved not from the first added agent");
                return Status.failed("public StockSymbol getStock(java.lang.String symbol) Test Failed");
            }
        }
    
        ref.println("Stub QuoteAgent is installed and works correctly");
    
        // Step: remove QuoteAgent from StockInfoManager lookup table.
        manager.removeQuoteAgent( agent);
        for(int i = 0; i < symbols.length; i++) {
            agent.reset();
            StockSymbol ss = manager.getStock( symbols[i]);
        
            // Check if
            // 1. Returned StockSymbol is null
            // 2. The method getStock(String) of agent was not invoked.
            if( ss != null                  // should be null
                    && !agent.invoked()) {  // agent's method should not be called
                ref.print("Returned StockSymbol is not null ");
                ref.println("or already removed agent was invoked");
                return Status.failed("public StockSymbol getStock(java.lang.String symbol) Test Failed");
            }
        }
        return Status.passed("OKAY");
    }

    /**
     * Equivalence class partitioning
     * with state and input values orientation
     * for public StockSymbol getStock(java.lang.String symbol),
     * <br><b>pre-conditions</b>: StockInfoManager lookup table isn't empty,
     * <br><b>symbol</b>: null.
     * <br><b>Expected results</b>: NullPointerException
     */
    public Status StockInfoManager0003() {
        boolean passed = true;
        // Step: create StockInfoManager
        StockInfoManager manager = new StockInfoManager();
    
        try {
            // Step: invoke the method getStock(null) and wait for 
            // NullPointerException to be thrown
            manager.getStock(null);
            log.println("NullPointerException expected. "+
                        "Lookup table is empty");
    
            passed = false;
        } catch(NullPointerException e) {
        }
        
        // Step: add QuoteAgent into StockInfoManager lookup table.
        SampleQuoteAgent agent = new SampleQuoteAgent(host, port, log);
        manager.addQuoteAgent( agent);
    
        try {
            // Step: invoke the method getStock(null) and wait for 
            // NullPointerException to be thrown
            manager.getStock(null);
            log.println("NullPointerException expected. "+
                        "Lookup table is not empty");
    
            passed = false;
        } catch(NullPointerException e) {
        }
      
        return passed ? Status.passed("OKAY") : Status.failed("Failed");
    }

    /**
     * Assertion testing
     * for public StockSymbol getStock(java.lang.String symbol),
     * If a particular agent cannot retrieve the symbol due to a GetQuoteException, it is ignored..
     */
    public Status StockInfoManager2001() {
        // Step: create StockInfoManager
        StockInfoManager manager = new StockInfoManager();
    
        // Step: add QuoteAgent into StockInfoManager lookup table.
        SampleQuoteAgent agent1 = new SampleQuoteAgent(host, port, log);
        agent1.reset();
        manager.addQuoteAgent( agent1);
        // Step: add another QuoteAgent into StockInfoManager lookup table.
        StubQuoteAgent agent2 = new StubQuoteAgent();
        manager.addQuoteAgent( agent2);
    
        // Step: invoke the method getStock("")
        // agent1 throws an exception but it should be ignored
        // the value returned should be null as it should be returned from agent2
        StockSymbol ss = manager.getStock("");
        if( agent1.invoked()) {
            log.println("Exception from the first agent is ignored");
        }
        if( ss != null ) {
            log.println("The second QuoteAgent in the lookup table was not invoked");
            return Status.failed("public StockSymbol getStock(java.lang.String symbol) Test Failed");
        }
        return Status.passed("OKAY");
    }
}

/**
 * This class implements getStock() method to return null 
 * if passed in symbol is an empty string and to throw
 * GetQuoteException otherwise.
 *
 */
class StubQuoteAgent implements QuoteAgent {
    public StockSymbol getStock(String symbol) throws GetQuoteException {
        if( symbol.equals("") ) return null;
        throw new GetQuoteException("StubQuoteAgent", null);
    }
}
