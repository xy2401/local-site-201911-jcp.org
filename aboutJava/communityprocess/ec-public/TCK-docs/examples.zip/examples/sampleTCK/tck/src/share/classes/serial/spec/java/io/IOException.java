/*
 * @(#)IOException.java	1.2  02/15/02 21:02:01 Alexei Semidetnov
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * IOException specification of serialized form
 * Holds serial form specification for java.io.IOException.
 */

package serial.spec.java.io;

import javasoft.sqe.serial.IllegalSerialFormException;
import javasoft.sqe.serial.SerialForm;
import javasoft.sqe.serial.StreamObject;
import javasoft.sqe.serial.StreamObjectClass;


public class IOException extends StreamObjectClass implements SerialForm {
    private double ver;

    public IOException(double version) {
        super("java.io.IOException", 7818375828146090155L);
        ver = version;

        if (ver >= 1.1) {
            setSuperClass(lookup("serial.spec", "java.lang.Exception", ver));
        }
    }

    /* 
     * This method defines all the serializable fields 
     */
    public void define() {

        // no serial fields in IOException, nothing to define
    }

    /*
     * This method checks for constraints under which the serialized
     * fields are valid
     */
    public void verify(StreamObject streamobj)
            throws IllegalSerialFormException {

        // no serial fields for IOException, hence nothing to veify
    }
}
