/*
 * @(#)StockInfoManager.java	1.10 03/01/14
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampleapi;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.Date;
import java.util.Vector;
import java.util.Enumeration;
import java.text.DateFormat;

/**
 * StockInfoManager is an entry point to the Sample API.
 * <br>
 * Its <code>getStock</code> method is used to create a
 * <code>StockSymbol</code> object which in turn can be used to
 * retrieve a quote.
 * <br>
 * Stock information is retrieved using the quote agents.
 * Quote agents can be added to (<code>addQuoteAgent</code>), removed
 * (<code>removeQuoteAgent</code>) and retrieved
 * (<code>getQuoteAgents</code>) from the manager.
 * <br>
 * This class also contains pair of static methods to deal with
 * the default StockInfoManager (<code>setDefault</code>,
 * <code>getDefault</code>)
 */ 

public class StockInfoManager {

    /**
     * Default constructor. Does nothing.
     */
    public StockInfoManager() {
    }
    
    /** 
     * Gets the default StockInfoManager.
     *
     * @return A <code>StockInfoManager</code> object that represents the default
     * value (may be <code>null</code>)
     * @see com.sun.tdk.sampleapi.StockInfoManager#setDefault(StockInfoManager)
     */
    public static StockInfoManager getDefault() {
        return defaultManager;
    }

    /** 
     * Sets the default StockInfoManager. If <code>newDefault</code> is
     * <code>null</code> there is no default StockInfoManager.
     *
     * @param newDefault  A <code>StockInfoManager</code> object that specifies the
     * default value
     * @see com.sun.tdk.sampleapi.StockInfoManager#getDefault()
     */
    public static void setDefault(StockInfoManager newDefault) {
        defaultManager = newDefault;
        /* This is an intentionally introduced bug */
        newDefault.getQuoteAgents();   
    }

    /**
     * Adds a <code>QuoteAgent</code> to the StockInfoManager lookup table.
     * If the StockInfoManager lookup table contains a <code>QuoteAgent</code> passed (determined by the equals method), 
     * calling this method has no effect.
     *
     * @param agent  A <code>QuoteAgent</code> object
     * @exception NullPointerException if the specified agent is <code>null</code>
     */
    public void addQuoteAgent(QuoteAgent agent) {
        if (agent == null)
            throw new NullPointerException();

        if (!lookup_table.contains(agent)) {
            lookup_table.add(agent);
        }
    }

    /**
     * Removes a <code>QuoteAgent</code> from the StockInfoManager lookup table.
     * If the StockInfoManager lookup table does not contain <code>QuoteAgent</code>
     * passed (determined by the equals method), calling this method has no effect.
     *
     * @param agent  A <code>QuoteAgent</code> object
     * @exception NullPointerException if the specified agent is <code>null</code>
     */
    public void removeQuoteAgent(QuoteAgent agent) {
        if (agent == null)
            throw new NullPointerException();

        lookup_table.remove(agent);
    }

    /**
     * Gets an enumeration of all installed <code>QuoteAgent</code>s
     * in the same order they were added to the StockInfoManager.
     *
     * @return An Enumeration object with all installed
     * <code>QuoteAgent</code>s
     */
    public Enumeration getQuoteAgents() {
        return lookup_table.elements();
    }

    /**
     * Retrieves a StockSymbol object for the specified symbol.
     * Looks up the installed agents 
     * for the symbols (first added gets looked up first), calling QuoteAgent.getQuote(String) method. 
     * Returns the first matching symbol.
     * If a particular agent cannot retrieve the symbol due to a GetQuoteException, it is ignored.
     * If symbol cannot be retrieved (there is no installed agent whose 
     * <code>getStock(symbol)</code> method returns non-null <code>StockSymbol</code>), 
     * this method returns null.
     *
     * @param symbol  A <code>String</code>
     * @return Created StockSymbol object for the specified symbol, or
     * <code>null</code> if the symbol cannot be not found or no agents are installed
     * @exception NullPointerException if the specified agent is <code>null</code>
     */
    public StockSymbol getStock(String symbol) {
        if (symbol == null)
            throw new NullPointerException();

        if (lookup_table == null || lookup_table.size() == 0)
            return null;

        try {
            for (int i=0; i != lookup_table.size(); ++i) {
                StockSymbol ssymb =
                ((QuoteAgent)lookup_table.get(i)).getStock(symbol);
                if (ssymb != null) {
                    return ssymb;
                }
            }
        } catch (GetQuoteException e) {
        }
        return null;
    }

    private static StockInfoManager defaultManager = new StockInfoManager();

    static {
        defaultManager.addQuoteAgent(new DefaultQuoteAgent());
    }

    private Vector lookup_table = new Vector();
}

//----------- PRIVATE API -------------------

class DefaultQuoteAgent implements QuoteAgent {

    public StockSymbol getStock(String symbol) throws GetQuoteException {
        StockSymbol ss = new NetworkStock(symbol);       
        // We should return null if this symbol is unknown to ss 
        try {
            ss.getQuote();
        } catch (IllegalArgumentException e) {
            return null;
        }
        return ss;
    }

}

class RandomStock extends StockSymbol {

    public RandomStock(String symbol) {
        super(symbol);
    }

    public Quote getQuote() {
        return new Quote(symbol, new Date(), 100, 10, 1000, 50, 110, 120);
    }
}


class NetworkStock extends StockSymbol {


    public NetworkStock(String symbol) {
        super(symbol);
    }

    public Quote getQuote() throws GetQuoteException, IllegalArgumentException {
        return new NetworkQuote(symbol);
    }
}


class NetworkQuote extends Quote {

    /**
     * The server from which the quotes are downloaded
     *
     * NOTE: Currently, only the quote.yahoo.com server is supported
     */
    private static String quoteServerURL = "http://quote.yahoo.com/d/quotes.csv?s=";

    /**
     * The format parameter for the quote server to use when it retrieves stock data
     *
     * NOTE: Currently, only this format is supported
     */
    private static String quoteFormat = "&f=slc1wop";


    public static String getURL(String symbol) {
        return quoteServerURL + symbol + quoteFormat;
    }


    /**
     * <p>Takes a <code>String</code> from the quote server or database and
     * parses the <code>String</code> into each field.  We first have to split it into
     * small strings and then parse each <code>String</code> that should be a number.
     *
     * @param quoteString The <code>String</code> to parse into the fields
     *
     * @throws <code>GetQuoteException</code> is thrown if
     *            the data retrieved from the quote server cannot be parsed
     * @throws <code>IllegalArgumentException</code> is thrown if
     *            the specified symbol is unknown to this quote server. 
     */
     public NetworkQuote(String symbol) throws GetQuoteException,
                                        IllegalArgumentException  {
        super(symbol);

        try {

            String quoteString = getStockQuote(getURL(symbol));

            if (quoteString.indexOf('"') == -1 ||   // no occurences of "
                quoteString.indexOf("<b>0.00</b>") != -1) { // Last trade value
                throw new IllegalArgumentException();
            }
            
            // get our starting index
            int index = quoteString.indexOf('"');

            // split the string up into it's fields
            name    = quoteString.substring(++index,
			    	(index = quoteString.indexOf('"', index)));
            index += 3;

            try {
                time = DateFormat.getTimeInstance(DateFormat.SHORT).parse(
                        quoteString.substring(index,
			(index = quoteString.indexOf('-', index))-1));
            }
            catch (java.text.ParseException e) {
                time = new Date(0);
            }
            index += 5;
            /* Any value potentially can be N/A. 
               If so initialize them to default */
            String Sprice  = quoteString.substring(index,
				(index = quoteString.indexOf('<', index)));
            if( Sprice.equals("N/A") ) Sprice = "0.0";
            index += 6;
            String Schange = quoteString.substring(index,
			       (index = quoteString.indexOf(',', index)));
            if( Schange.equals("N/A") ) Schange = "0.0";
            index += 2;
            String Slow    = quoteString.substring(index,
				(index = quoteString.indexOf(' ', index)));
            if( Slow.equals("N/A") ) Slow = "0.0";
            index += 3;
            String Shigh   = quoteString.substring(index,
				(index = quoteString.indexOf('"', index)));
            if( Shigh.equals("N/A") ) Shigh = "0.0";
            index += 2;
            String Sopen   = quoteString.substring(index,
				(index = quoteString.indexOf(',', index)));
            if( Sopen.equals("N/A") ) Sopen = "0.0";
            ++index;
            String Sprev   = quoteString.substring(index, quoteString.length()-2);
            if( Sprev.equals("N/A") ) Sprev = "0.0";

            // Convert the strings that should be numbers into ints
            price = makeInt(Sprice);
            // remove the '+' sign if it exists
            Schange = (Schange.indexOf('+') == -1) ?
	    Schange : Schange.substring(1, Schange.length());
            change = makeInt(Schange);
            low    = makeInt(Slow);
    	    high   = makeInt(Shigh);
            open   = makeInt(Sopen);
            prev   = makeInt(Sprev);

        }
        catch (NumberFormatException e) {
            e.printStackTrace();
            throw new GetQuoteException("",e);
        }

        catch (StringIndexOutOfBoundsException e) {
            e.printStackTrace();
            throw new GetQuoteException("",e);
        }

        catch (IOException e) {
            e.printStackTrace();
            throw new GetQuoteException("",e);
        }
     }


    private String getStockQuote(String tkrSymbol)
	throws IOException, NumberFormatException {

        URL u =new URL(tkrSymbol);
        InputStream is = u.openStream();
        int ch;
        StringBuffer sb = new StringBuffer();
        while ((ch = is.read()) != -1) {
            sb.append((char)ch);
        }
	is.close();
        return sb.toString();
    }

}
