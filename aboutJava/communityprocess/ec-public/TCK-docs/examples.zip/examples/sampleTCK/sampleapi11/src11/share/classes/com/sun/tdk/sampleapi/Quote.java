/*
 * @(#)Quote.java	1.7 03/01/14
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampleapi;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;

/**
 * Represents (immutable) stock quote.
 *
 * @author  Mikhail Gorshenev
 * @since   1.0
 */

public class Quote {

    /**
     * Corresponds to the change in the stock in 1/10000 of a dollar.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>1</code> is set to <code>CHANGE</code>.</P> 
     * @see  #getString(int)
     */
    public static final int	CHANGE	= 1;

    /**
     * Corresponds to the 52-week high for the stock.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>2</code> is set to <code>HIGH</code>.</P> 
     * @see com.sun.tdk.sampleapi.Quote#getString(int)
     */
    public static final int HIGH = 2;

    /** 
     * Corresponds to the 52-week low for the stock.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>3</code> is set to <code>LOW</code>.</P> 
     * @see com.sun.tdk.sampleapi.Quote#getString(int)
     */
    public static final int LOW = 3;

    /** 
     * Corresponds to the opening price of the stock.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>4</code> is set to <code>OPEN</code>.</P> 
     * @see com.sun.tdk.sampleapi.Quote#getString(int)
     */
    public static final int OPEN = 4;

    /**
     * Corresponds to the previous high for the stock.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>5</code> is set to <code>PREVIOUS</code>.</P> 
     * @see com.sun.tdk.sampleapi.Quote#getString(int)
     */
    public static final int PREVIOUS = 5;

    /**
     * Corresponds to the price of the last trade of the stock.
     * May be passed as a parameter of the method getString(int index)
     * <P>Constant value <code>6</code> is set to <code>PRICE</code>.</P> 
     * @see com.sun.tdk.sampleapi.Quote#getString(int)
     */
    public static final int PRICE = 6;

    /** 
     * Returns stock change/high/low/openprevious/price.
     * Expected to be:<br>
     * <code>getString(CHANGE)</code> == <code>getStringChange()</code><br>
     * <code>getString(HIGH)</code> == <code>getStringHigh()</code><br>
     * <code>getString(LOW)</code> == <code>getStringLow()</code><br>
     * <code>getString(OPEN)</code> == <code>getStringOpen()</code><br>
     * <code>getString(PREVIOUS)</code> == <code>getStringPrevious()</code><br>
     * <code>getString(PRICE)</code> == <code>getStringPrice()</code><br>
     * @throws <code>IllegalArgumentException</code> if 
     * index is not one of CHANGE, HIGH, LOW, OPEN, PREVIOUS, or PRICE.
     * @see com.sun.tdk.sampleapi.Quote#getStringChange()
     * @see com.sun.tdk.sampleapi.Quote#getStringHigh()
     * @see com.sun.tdk.sampleapi.Quote#getStringLow()
     * @see com.sun.tdk.sampleapi.Quote#getStringOpen()
     * @see com.sun.tdk.sampleapi.Quote#getStringPrevious()
     * @see com.sun.tdk.sampleapi.Quote#getStringPrice()
     */

    public Object getString(int index) {
        switch(index) {
        case CHANGE: return getStringChange();
        case HIGH: return getStringHigh();
        case LOW: return getStringLow();
        case OPEN: return getStringOpen();
        case PREVIOUS: return getStringPrevious();
        case PRICE: return getStringPrice();
        default:
            throw new IllegalArgumentException("Invalid index");
        }
    }




    /**
     * Package private constructor. Used for delayed object creation
     * when the info is obtained via the network.
     */ 
    Quote(String name) {
        if (name == null) {
            throw new NullPointerException("Stock name cannot be null");
        }
        this.name = name;
    }

    /**
     * Creates a new Quote object.
     * Argument <code>time</code> can be <code>null</code>.
     *
     * @param name Name of the stock
     * @param time Time of the last trade, can be <code>null</code>
     * @param price Price of the stock
     * @param change Change in 1/10000 of a dollar
     * @param high 52-week high
     * @param low 52-week low
     * @param open Opening price on the day
     * @param prev Previous high
     *
     * @exception NullPointerException if the specified name is <code>null</code>
     */ 
    public Quote(String name, Date time, int price, int change, 
            int high, int low, int open, int prev) {
        this(name);
        this.time = time;
        this.price = price;
        this.change = change;
        this.high = high;
        this.low = low;
        this.open = open;
        this.prev = prev;
    }

    /**
     * Name of the Stock
     */
    String name;

    /**
     * Time of the last trade
     */
    Date time;

    /**
     * Price of the Stock
     */
    int price;

    /**
     * $ change
     */
    int change;

    /**
     * 52-week high
     */
    int high;

    /**
     * 52-week low
     */
    int low;

    /**
     * Opening price for the day
     */
    int open;

    /**
     * Previous high
     */
    int prev;


    /**
     * <p>Takes a <code>String</code> representation of a floating point number
     * and makes an <code>int</code> out of it.</p>
     * <p>Since there is no floating point support on some limited devices
     * (for example, pagers), we have to convert the decimal numbers into
     * <code>Integer</code>s. 
     * We do this by:</p>
     * <li> Looking at a maximum of 4 fractional places (trim exceeding)</li>
     * <li> Performing a "multiplication" by 10000 to a string representation
     *      of a floating point number by cutting out the decimal point and adding
     *      the appropriate number of zeroes if needed. The original number
     *      can then be restored using the  
     *      {@link com.sun.tdk.sampleapi.Quote#convert(int)} method.
     * <li> After doing this the string representation is converted to an <code>int
     *</code>
     *<pre>
     *      Example: 100     -> 1000000  (/10000 = 100)
     *      Example: 345.67  -> 3456700  (/10000 = 345.67)
     *      Example: 3.45678 -> 34567    (/10000 = 3.4567)
     *      Example: 1234567 -> 12345670000 (doesn't fit into <code>int</code>,
     *                results in NumberFormatException)
     *</pre></li>
     *
     * @return The <code>int</code> value of the string (trimmed to 4 fractional digits and
     *      multiplied by 10000)
     * @param source The <code>String</code> value to convert
     * to an <code>int</code>
     * @exception NumberFormatException If the source is
     * <code>null</code> or after applying specified operations the value does
     * not represent a valid <code>int</code>
     * @see com.sun.tdk.sampleapi.Quote#convert(int)
     */
    public static int makeInt(String source)
	throws NumberFormatException {

        if (source == null) {
            throw new NumberFormatException("null");
        }
        
        // If there is no decimal point add it to simplify further operations
        if (source.indexOf('.') == -1) {
            source += '.';
        }

        // Cut the string down to 4 digits within the fractional part
        while (source.length() - (source.indexOf('.') + 1) > 4) {
            source = source.substring(0, source.length()-1);
        }

        // Currently we have a string representation of a floating point
        // number with no more than 4 fractional digits.
        // Multiply by 10000 to get rid of the decimal point.
        String tmp;
        String zeroes[] = {"", "0", "00", "000", "0000"};
        String svalue = ((source.substring(0, source.indexOf('.')) +
	    (tmp = source.substring(source.indexOf('.')+1, source.length())) +
        zeroes[4 - tmp.length()]));
        
        // Convert to int; all that we didn't check including
        // a number too large for int will result in an exception here
        return Integer.valueOf(svalue).intValue();
   }

    /**
     * Returns the name of the stock.
     *
     * @return Name (ticker symbol) of the stock
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the time of the last trade.
     *
     * @return Time of the last trade of the stock
     */
    public Date getTime() {
        return time;
    }

    /**
     * Returns the price of the last trade of the stock.
     *
     * @return Price of the last trade of the stock
     */
    public int getPrice() {
        return price;
    }

    /**
     * Returns the change in the stock in 1/10000 of a dollar.
     *
     * @return Change in the stock today
     */
    public int getChange() {
        return change;
    }

    /**
     * Returns the 52-week high for the stock.
     *
     * @return The 52-week high for the stock
     */
    public int getHigh() {
        return high;
    }

    /**
     * Returns the 52-week low for the stock.
     *
     * @return The 52-week low for the stock
     */
    public int getLow() {
        return low;
    }

    /**
     * Returns the opening price of the stock.
     *
     * @return Opening price of the stock today
     */
    public int getOpen() {
        return open;
    }

    /**
     * Returns the previous high for the stock.
     *
     * @return Previous high for the stock
     */
    public int getPrevious() {
        return prev;
    }

    /**
     * Convert an <code>int</code> to a <code>String</code>
     * with the decimal placed back in (divide by 10000).
     *<pre>
     *      Example: -100    -> -0.01
     *      Example: 34567   -> 3.4567
     *</pre>
     * 
     * @return The <code>String</code> value of the <code>int</code>
     * @param intNum The <code>int</code> value to convert
     * to a <code>String</code>
     * @see com.sun.tdk.sampleapi.Quote#makeInt(String)
     */
    public static String convert(int intNum) {
        
        // Convert an int to a String and save the sign information
        String s = String.valueOf(intNum);
        String sign = "";
        if (intNum < 0) {
            sign = "-";
            s = s.substring(1);
        }

        // Extract the integer and fractional part separately
        String pre = "";
        String suf = "";
        if (s.length() <= 4) {
            pre = "0";
            suf = s;
            // Fill the fractional with the appropriate number of leading zeroes
            while (suf.length() < 4) {
                suf = "0" + suf;
            }
        } else {
            pre = s.substring(0, s.length()-4);
            suf = s.substring(s.length()-4);
        }

        // If the fractional is zero, return the integer part
        if (Integer.valueOf(suf).intValue() == 0) {
            return (sign + pre);
        }

        // Cut trailing zeroes
        while (suf.endsWith("0")) {
            suf = suf.substring(0, suf.length()-1);
        }
        return (sign + pre + "." + suf);
    }

    /**
     * Returns the string representation of the price with the decimal placed
     * back in the correct position.
     *
     * @return Current stock price
     */
    public String getStringPrice() {
        return convert(price);
    }

    /**
     * Returns the string representation of <code>change</code> with the decimal placed
     * back in the correct position.
     *
     * @return Change in stock price today
     */
    public String getStringChange() {
        return convert(change);
    }

    /**
     * Returns the <code>String</code> representation of the 52-week high with the decimal
     * placed back in the correct position.
     *
     * @return The 52-week high
     */
    public String getStringHigh() {
        return convert(high);
    }

    /**
     * Returns the <code>String</code> representation of the 52-week low with the decimal
     * placed back in the correct position.
     *
     * @return The 52-week low
     */
    public String getStringLow() {
        return convert(low);
    }

    /**
     * Returns the <code>String</code> representation of the opening price with
     * the decimal placed back in the correct position.
     *
     * @return Opening stock price
     */
    public String getStringOpen() {
        return convert(open);
    }

    /**
     * Returns the <code>String</code> representation of previous with the decimal
     * placed back in the correct position.
     *
     * @return Previous high for the stock
     */
    public String getStringPrevious() {
        return convert(prev);
    }
 
    /**
     * Returns the <code>String</code> representation of this quote in the format 
     * <code><pre>getName()+" "+getStringPrice()+" at "+getTime()+" "+ getStringChange()</pre></code>.
     */
    public String toString() {
        return getName() + " " + getStringPrice() + " at " + getTime() + " " + getStringChange();
    }



}

