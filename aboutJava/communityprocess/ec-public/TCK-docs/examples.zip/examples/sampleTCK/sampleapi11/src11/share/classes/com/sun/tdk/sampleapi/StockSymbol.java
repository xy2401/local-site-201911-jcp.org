/*
 * @(#)StockSymbol.java	1.9 03/01/20
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampleapi;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;

/**
 *
 * StockSymbol class represents a ticker symbol. Can be used to
 * retrieve the quote.
 *
 * @author  Mikhail Gorshenev
 */

public abstract class StockSymbol {

   /**
    * Package-private variable, holds the stock symbol.
    * Used by concrete <code>Stock</code> classes in this package.
    */
    String symbol;

    private java.awt.Panel component = new java.awt.Panel();

    /**
     * Creates a new <code>StockSymbol</code> object.
     *
     * @param symbol Name (ticker symbol) of the stock
     *
     * @exception NullPointerException if the specified symbol is <code>null</code>
     */
    public StockSymbol(String symbol) {
        if (symbol == null) {
            throw new NullPointerException("Stock name cannot be null");
        }
        this.symbol = symbol;
    }

    /**
     * Gets/updates a visual representation of the stock.
     * The default implementation displays the symbol, the time, the price, the change
     * and the % change. Positive and negative changes are visualized in 
     * green and red, respectively.
     *
     * The quote info is obtained using the <code>getQuote</code> method.
     * If the quote cannot be retrieved due to a <code>GetQuoteException</code>,
     * the container displays a <code>String</code> of the form: 
     * symbol + ": data not available"
     *
     * The component is initially invisible and is not added to 
     * any container.
     * The same component is returned for each repetitive call.
     *
     * Subclasses may override this method to include additional data
     * such as charts.
     *
     * @return A <code>Component</code> object representing the <code>Stock</code>
     */
    public Component getVisualComponent() {

        if (component.getComponentCount() == 0) {
            component.setVisible(false);
        }

        try {
            reinitComponent(getQuote());
        } catch (GetQuoteException e) {
            component.removeAll();
            component.add( new Label(symbol + ": data not available"));
        }

        return component;
    }

    /**
     * Updates Component content according to the previous getQuote() invocation.
     */

    void reinitComponent(Quote quote) {
        component.removeAll();
        component.setLayout(new GridLayout( 5, 2));
        component.setBackground(Color.white);
        component.setForeground(Color.black);
        component.add(new Label(" SYMBOL ", Label.RIGHT));
        component.add(new Label(quote.getName()));
    
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("EEE, MMM d, ''yy");
        component.add(new Label("time: ", Label.RIGHT));
        component.add(new Label( df.format( quote.getTime())));
        component.add(new Label("price: ", Label.RIGHT));
        component.add(new Label(quote.getStringPrice()));
        component.add(new Label("change: ", Label.RIGHT));
        java.awt.Label change = new java.awt.Label( quote.getStringChange());
        double percent = ( 100 * quote.getChange() ) / quote.getPrevious();
        java.awt.Label perChange = new java.awt.Label( percent + "%" );
        if( quote.getChange() >= 0 ) {
            change.setForeground(Color.green);
            perChange.setForeground(Color.green);
        } else {
            change.setForeground(Color.red);
            perChange.setForeground(Color.red);
        }
        component.add( change);
        component.add(new Label("% change: ", Label.RIGHT));
        component.add( perChange);
    }

    /**
     * Gets the current quote of the stock.
     * 
     * @exception GetQuoteException if an i/o exception occurs during
     *            stock retrieval
     * @return The <code>Quote</code> value
     */
    public abstract Quote getQuote() throws GetQuoteException;
 
    /**
     * Returns the name of the stock.
     *
     * @return name The ticker symbol of the stock
     */
    public String getName() {
        return symbol;
    }

    /**
    *  Timeout for Quote retrieval operation in milliseconds.
    *  waitQuote() returns Quote object, or should throw GetQuoteException
    *  after timeout milliseconds.
    *  Default value is 10000.
    *  @see com.sun.tdk.sampleapi.GetQuoteException
    */

    public static int timeout = 10000;

    /**
    * This method asynchroniously invokes getQuote() and waits
    * <code>timeout</code> milleseconds.
    * @throws GetQuoteException if i/o exception occured during
    * stock retrieval, or getQuote() does not return for <code>timout</code>
    * milliseconds
    * @see com.sun.tdk.sampleapi.StockSymbol#timeout
    * @see com.sun.tdk.sampleapi.StockSymbol#getQuote()
    */

    public Quote waitQoute() throws GetQuoteException {
         
        QuoteRetriever qr = new QuoteRetriever();
        Thread t = new Thread(qr);
        t.start();

        synchronized(qr) {
           try {
              wait(timeout);
           } catch(InterruptedException ie) {
           }
        }

        if (qr.quote == null)
            throw new GetQuoteException("Timeout: cannot get QuoteObject for ~" + (timeout / 1000) + "sec.", null);

        return qr.quote;
    }

    class QuoteRetriever implements Runnable {
        public Quote quote;

        public void run() {
            synchronized (this) {
                try {
                    quote = getQuote();
                } catch(GetQuoteException gqe) {
                    quote = null; 
                } finally {
                    notify();
                }
            }
        }
    }
}

