/*
 * @(#)GetQuoteException.java	1.6 03/01/14
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampleapi;

import java.io.IOException;


/**
 * This exception may be thrown by methods that have detected an
 * i/o exception while retrieving requested stock information.
 *
 * @author  Mikhail Gorshenev
 * @since   1.0
 */
public class GetQuoteException extends IOException {
    private Exception cause;

    /**
     * Constructs a <tt>GetQuoteException</tt> with the
     * specified detail message and nested exception.
     * Argument <code>message</code> can be <code>null</code> as can
     * <code>cause</code>.
     *
     * @param message The detail message pertaining to this exception.
     *                This value can be <code>null</code>.
     * @param cause An exception that triggered this exception.
     *                This value can be <code>null</code>.
     */
    public GetQuoteException(String message, Exception cause) {
        super(message);
        this.cause = cause;
    }

    /**
     * Gets the nested exception.
     *
     * @return Nested exception or <code>null</code> if there is no
     * nested exception
     */
    public Exception getNested() {
        return cause;
    }

   /**
    * This method prints super.toString() followed by String reprsentation 
    * of nested exception.
    * @see java.lang.Throwable#toString()
    */

    public String toString() {
        return getNested() + super.toString();
    }

}


