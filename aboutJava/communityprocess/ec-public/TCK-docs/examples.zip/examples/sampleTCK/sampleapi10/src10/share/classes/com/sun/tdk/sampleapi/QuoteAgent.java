/*
 * @(#)QuoteAgent.java	1.3 02/01/29
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.tdk.sampleapi;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;

/**
 * Quote agent interface. Represents an abstract agent requesting  
 * stock information from a particular source (such as NYSE or NASDAQ).
 *
 * @author  Mikhail Gorshenev
 * @since   1.0
 */
public interface QuoteAgent {
    /**
     * Gets a <code>StockSymbol</code> object for the specified symbol.
     * @param symbol A <code>String</code>
     * @return <code>null</code> if the symbol is unknown to this agent
     * @exception NullPointerException if the specified symbol is <code>null</code>
     * @exception GetQuoteException if the symbol cannot be retrieved
     */
    StockSymbol getStock(String symbol) throws GetQuoteException;
}

