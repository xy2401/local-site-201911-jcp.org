                                   README

                  JavaTM Daemon API Specification Request
                        Version 0.9, tk, 2000-11-22

Contents

   * Introduction
   * Release Note
   * Compatibility
   * License Terms
   * Daemon API JSR
   * Daemon API Sources, Library and Launcher
   * Daemon API HTML Documentation
   * Samples
   * References

Introduction

     This documenation supplies an introduction to the JSR for a Java
     daemon API.

     Java daemons are independently running Java applications
     implementing the daemon interface in order to be hosted via
     daemon containers. A daemon container can be a Java application
     or a native platform application.
     Runtime behaviour and implementation of Java daemons are
     independent of the platform and implementation of hosting
     containers.

     A daemon container manages the life cycle of a Java daemon using
     the daemon control SPI.
     In addition, it supplies resources for the daemon via the daemon
     context.

     The Java daemon API provides for implementing system level
     services on the Java platform.

     The daemon API framework consists of classes and interfaces for
     implementing daemons and daemon containers.
     In addition, it contains a simple command line deployment tool
     for supplying basic daemon container functionality for each JDK
     platform implementation in a uniform fashion.


Release Note

     This specification and other material included form a JSR in the
     sense of the Java Community Process.
     The documentation has prelimary status.

     Sources and JAR files are roughly tested. They have been
     developed for demonstration purposes, only.
     Using the samples are at the user's own risk.

     The enclosed material should serve as an introduction to Java
     daemons rather than supplying ready to use software.


Compatibility

     All the software inluded in this JSR is compatible with the
     JavaTM 2 Platform.
     The preliminary refererence container has been developed for a
     Windows NT 4.0 platform.
     Native containers for Unix platforms are not yet included.


License Terms

     All material included in this specification is subject to the
     Java daemon  JSR in the sense of the JCP.
     All terms of the JSPA and the JCP definition (cf.
     www://java.sun.com/jcp) apply to this package.


Daemon API JSR

     The details of the JSR are described in the Damon API
     Specification, which also supplies an overview of the entire
     project and the structure of the API.


Daemon API Sources, Library and Launcher

     The sources of the JAVA dameon API including those of the
     preliminary RI for an NT platform can be found in the source
     subdirectory. The JAR file can be unpacked with the JDK jar tool
     (cf. reference below). The JAR library containing the JAVA daemon
     class files is located in the library subdirectory and can be
     installed as an extension library, i.e. by copying it to the
     lib/ext subdirectory of your Java runtime environment. The Java
     daemon launcher and installer is contained in the binary
     subdirectory and can be called as described in the source
     documentation.


Daemon API HTML Documentation

     The HTML documentation of the JAVA daemon API can be accessed
     here.


Samples

     A few samples using the JAVA daemon API can be found in the
     samples subdirectory. Please, see the README text files for
     documentation.


References

     For additional information, refer to the following resources on
     the World Wide Web:

     http://java.sun.com/jcp
          for questions and resources concering the Java Community
          Process
     http://java.sun.com/products
          for the Java 2 Platform JDK in order to develop and run
          daemon samples
     http://www.w3.org/Jigsaw
          for additional resources to run the Jigsaw webserver sample
     mailto:Thomas.Kopp@Dialogika.de
             for contacting the author of this document

     -----------------------------------------------------------------
