Java Daemon API / Class and Interface Library 

The JAR file containing the Java daemon classes and interfaces 
can be installed as an extension library, i.e. by copying it to
the JRE lib/ext subdirectory.

The library is required for developing and running Java daemons
using the javad launcher and installer.

tk, 2000-11-26.
