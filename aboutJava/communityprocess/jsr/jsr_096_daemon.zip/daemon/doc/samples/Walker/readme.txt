Java Daemon API / Walker Sample

This small example shows a daemon with no useful functionality.

It just walks a little bit around the daemon API and tells
you to launch some control actions. The walker thread needs a 
break after 10 seconds walking if you do not decide to pause
before.


The example can be installed using the JAVAD launcher and 
installer with suitable classpath arguments set.

A sample command line for installing the daemon might look like this:

javad -i -cp .;\daemon\doc\samples\Walker;\daemon\lib\daemon.jar Walker

tk, 2000-11-26.
