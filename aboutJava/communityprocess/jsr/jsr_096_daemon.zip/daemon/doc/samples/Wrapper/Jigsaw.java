import jsr.daemon.*;

import org.w3c.jigsaw.*;
import org.w3c.jigsaw.admin.*;

import java.util.*;

/**
 * sample wrapper daemon for starting and stopping the Jigsaw web server (cf. http://jigsaw.w3.org)
 *
 * The implementation fashion for wrapping is similar to a Unix rc script style.
 * The chronological order feature of the Java daemon argument enumeration is used
 * for reconstructing the original command line during wrapping. Java daemons using a
 * <parameter>=<value> environment style would not need this feature anymore.
 *
 * @author   Thomas Kopp
 * @version  0.9, 2000-11-20
 */
 public class Jigsaw extends GenericDaemon {

    /*
     * number of trailing arguments for killing the service, 
     * i.e. "-u <user> -p <password> <admin service uri>"
     */
    private static final int KILLERARGS = 5;
    
    /*
     * command line of the main service
     */
    private String[] argv = null;

    /*
     * command line of the killer program
     */
    private String[] argk = null;
    
    /**
     * method for reading and separating the commandline arguments
     */
    private void readArgs() 
        throws DaemonException {
        
        // reconstructing the command line via chronological attribute order
        ArrayList args = new ArrayList();       
        Enumeration parameters = getAttributeNames();
        while (parameters.hasMoreElements()) {
            String key = (String)(parameters.nextElement());
            Object value = getAttribute(key);
            if (value != null) {
               key += "=";
               if (value instanceof String) key += (String)value;
               else key += value.toString();
            }
            args.add(key);
        }
        Object[] arg = args.toArray();
        
        // separating the trailing killer arguments
        int separator = arg.length - KILLERARGS;
        if (separator >= 0) {
            
            argv = new String[separator];
            System.arraycopy(arg, 0, argv, 0, separator);
            
            argk = new String[KILLERARGS];
            System.arraycopy(arg, separator, argk, 0, KILLERARGS);
        }
        else throw new DaemonException("some arguments missing");
    }
    
    /**
     * init method of this daemon
     */
    public void init() throws DaemonException {
        // read and separate arguments
        readArgs();
        
        // start the web server in a separate thread
        new Thread() { public void run() { Main.main(argv); }  }.start();
    }
    
    /**
     * destroy method of this daemon
     */
    public void destroy() {
        // start the killer program
        try {
              JigKill.main(argk);
        }
        catch (Exception ex) {
              log("killing failed", ex);
              down(ex);
        }
    }
}
