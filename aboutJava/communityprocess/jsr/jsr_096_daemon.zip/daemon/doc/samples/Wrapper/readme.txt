Java Daemon API / Wrapper Sample

This example demonstrates, how Java daemon-like applications can
be wrapped in order to be hosted as Java daemons.

The sample supplies a simple wrapper for the Jigsaw web server 
of the W3 consortium. Additional resources for running this example, i.e.
the Jigsaw web server itself, can be downloaded from http://jigsaw.w3.org.

The daemon destroy() method uses the JigKill class, which requires the
configured administrator credentials for shutting down the web server.
The credentials are supplied including the administration server URI 
as the rightmost 5 virtual command line parameters.

The virtual command line is constructed from the daemon environment 
attributes using the built-in chronological attribute order.


The example can be installed using the JAVAD launcher and 
installer with suitable classpath arguments set
after installing the Jigsaw web server.

A sample command line for installing the daemon might look like this:

javad -i -cp ".;\Jigsaw\classes;\Jigsaw\classes\jigsaw.jar;\Jigsaw\classes\jigadmin.jar;
      \daemon\doc\samples\Wrapper;\daemon\lib\daemon.jar" Jigsaw -root "\Jigsaw\Jigsaw" 
      -u admin -p admin http://localhost:8009/

Note: Jigsaw 2.0.5 including current patches was used for testing.
      The http server throws a NullPointerException during shutdown, which may be a 
      minor bug related to Jigsaw shutdown hooks. Nevertheless, the web server
      seems to stop properly.

tk, 2000-11-26.
