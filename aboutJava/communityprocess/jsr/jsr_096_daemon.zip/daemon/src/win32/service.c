// Java Daemon API JSR
// This module contains methods for managing the service structures
// tk, 2000-11-26

#include <windows.h>
#include <tchar.h>

#include "args.h"
#include "service.h"
#include "registry.h"
#include "javad.h"

#define SZFAILURE "Starting service control dispatcher failed."
#define SZSCMGRFAILURE "Service control manager failed."

#define SZPARAMPATH "SYSTEM\\CurrentControlSet\\Services\\"
#define SZPARAMKEY "\\Parameters"
#define SZAPPPARAMS "CommandLine"

#define SZNICENAME "nN"

SERVICE_STATUS ssStatus;       
SERVICE_STATUS_HANDLE sshStatusHandle;

BOOL bConsole = FALSE;

TCHAR szPath[_MAX_PATH];
TCHAR szErr[_MAX_PATH];
TCHAR szServiceName[_MAX_PATH];
TCHAR szParamKey[_MAX_PATH];


// export of the current service name
LPTSTR getServiceName() {
   return (LPTSTR)szServiceName;
}


// reading text for last error
LPTSTR getLastErrorText(LPTSTR lpszBuf, DWORD dwSize)
{
  DWORD dwRet;
  LPTSTR lpszTemp = NULL;

  dwRet = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | 
                        FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                        NULL, GetLastError(), LANG_NEUTRAL, (LPTSTR)&lpszTemp, 0, NULL);

  if (!dwRet || ((long)dwSize < (long)dwRet+14)) lpszBuf[0] = TEXT('\0');
  else {
         lpszTemp[lstrlen(lpszTemp)-2] = TEXT('\0');
         _stprintf(lpszBuf, TEXT("%s (0x%x)"), lpszTemp, GetLastError());
  }

  if (NULL != lpszTemp) GlobalFree(lpszTemp);

  return lpszBuf;
}


// service installation method
void installService(DWORD argc, LPTSTR *argv)
{
  TCHAR szServiceDisplayName[_MAX_PATH];

  SC_HANDLE   schSCManager;
  SC_HANDLE   schService;

  LPTSTR szAppParameters;
  LPTSTR *lpszServiceArgs;
  DWORD dwSLen;
  UINT i;

  dwSLen = 0;
  lpszServiceArgs = getServiceParameters(&dwSLen, argc - 2, argv + 2);

  szServiceDisplayName[0] = '\0';
  if (dwSLen > 0) {
     for (i=0; i<dwSLen; i++){
         if (NULL != strchr(SZNICENAME, *(lpszServiceArgs[i] + 2))) {
            strncpy(szServiceDisplayName,(lpszServiceArgs[i] + 3), _MAX_PATH);
         }
         GlobalFree(lpszServiceArgs[i]);
     }
  }
  if(NULL != lpszServiceArgs) GlobalFree(lpszServiceArgs);
  szServiceDisplayName[_MAX_PATH] = '\0';
  if (!(*szServiceDisplayName)) strcpy(szServiceDisplayName, szServiceName);

  schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
  if (schSCManager) {
      schService = CreateService(
            schSCManager,               // SCManager database
            TEXT(szServiceName),        // name of service
            TEXT(szServiceDisplayName), // name to display
            SERVICE_ALL_ACCESS,         // desired access
            SERVICE_WIN32_OWN_PROCESS,  // service type
            STARTTYPE,                  // start type
            SERVICE_ERROR_NORMAL,       // error control type
            szPath,                     // service binary path
            NULL,                       // load order
            NULL,                       // tag identifier
            TEXT(DEPENDENCIES),         // service dependencies
            NULL,                       // standard service account
            NULL);                      // service password

      if (schService) {
          _tprintf(TEXT("%s service installed.\n"), TEXT(szServiceName));

          CloseServiceHandle(schService);

          if (setKey(HKEY_LOCAL_MACHINE, szParamKey)) {
             szAppParameters = getServiceString(argc, argv);
             if (NULL == szAppParameters) {
                _tprintf(TEXT("Application parameter string construction failed.\n"));
             }
             else{
                   if (!(setString(szAppParameters, HKEY_LOCAL_MACHINE, 
                                      szParamKey, SZAPPPARAMS))) {
                       _tprintf(TEXT("Application parameter value setting failed.\n"));
                   }
                   GlobalFree(szAppParameters);
            }
          }
          else _tprintf(TEXT("Parameter subkey creation failed.\n"));
      }
      else {
            _tprintf(TEXT("Service creation failed: %s\n"), getLastErrorText(szErr, _MAX_PATH));
      }
      CloseServiceHandle(schSCManager);
  }
  else {
        _tprintf(TEXT(SZSCMGRFAILURE), getLastErrorText(szErr, _MAX_PATH));
  }
}


// service deinstallation method
void removeService(DWORD argc, LPTSTR *argv)
{
  SC_HANDLE schSCManager;
  SC_HANDLE schService;

  schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
  if (schSCManager) {
     schService = OpenService(schSCManager, TEXT(szServiceName), SERVICE_ALL_ACCESS);
     if (schService) {
        if (ControlService(schService, SERVICE_CONTROL_STOP, &ssStatus)) {
           _tprintf(TEXT("Stopping %s service."), TEXT(szServiceName));
           Sleep(SLEEPLIMIT);

           while (QueryServiceStatus (schService, &ssStatus)) {
                 if (ssStatus.dwCurrentState == SERVICE_STOP_PENDING) {
                     _tprintf(TEXT("."));
                     Sleep(SLEEPLIMIT);
                 }
                 else break;
           }

           if (ssStatus.dwCurrentState == SERVICE_STOPPED) {
               _tprintf(TEXT("\n%s service stopped.\n"), TEXT(szServiceName));
           }
           else {
                  _tprintf(TEXT("\n%s service stopping failed.\n"), TEXT(szServiceName));
           }
        }

        if (DeleteService(schService)) {
           _tprintf(TEXT("%s service removed.\n"), TEXT(szServiceName));
        }
        else {
               _tprintf(TEXT("Service deletion failed: %s\n"), getLastErrorText(szErr, _MAX_PATH));
        }
        CloseServiceHandle(schService);
     }
     else _tprintf(TEXT("Service access failed: %s\n"), getLastErrorText(szErr, _MAX_PATH));

     CloseServiceHandle(schSCManager);
  }
  else _tprintf(TEXT(SZSCMGRFAILURE), getLastErrorText(szErr, _MAX_PATH));
}


// text output method accessing log resource
VOID PrintMessage(LPTSTR lpszMsg, WORD type)
{
  TCHAR szMsg[_MAX_PATH];
  HANDLE hEventSource;
  LPTSTR lpszStrings[2];
  DWORD dwErr;

  static DWORD dwEvent = 0;

  if (bConsole) _tprintf(TEXT("%s\n"), lpszMsg);
  else {
         dwErr = GetLastError();
         hEventSource = RegisterEventSource(NULL, TEXT(szServiceName));
         if (hEventSource != NULL) {
            if ((type != EVENTLOG_INFORMATION_TYPE)&&(dwErr != 0)) {
               _stprintf(szMsg, TEXT("%s service error: %d"), TEXT(szServiceName), dwErr);
               lpszStrings[0] = szMsg;
               lpszStrings[1] = lpszMsg;
               ReportEvent(hEventSource, type, 0, dwEvent++, NULL, 2, 0, lpszStrings, NULL);                
            }
            else {
                   lpszStrings[0] = lpszMsg;
                   ReportEvent(hEventSource, type, 0, dwEvent++, NULL, 1, 0, lpszStrings, NULL);
            }
            DeregisterEventSource(hEventSource);
         }
  }
}


// error output method
VOID PrintError(LPTSTR lpszMsg)
{
  PrintMessage(lpszMsg, EVENTLOG_ERROR_TYPE);
}


// info output method
VOID PrintInfo(LPTSTR lpszMsg)
{
  PrintMessage(lpszMsg, EVENTLOG_INFORMATION_TYPE);
}


// status report of the service 
BOOL ReportStatus(DWORD dwCurrentState)
{
  static DWORD dwCheckPoint = 1;
  BOOL bResult = TRUE;

  if (!bConsole) {
     if ((dwCurrentState == SERVICE_START_PENDING)||
         (dwCurrentState == SERVICE_PAUSE_PENDING)||
         (dwCurrentState == SERVICE_CONTINUE_PENDING)||
         (dwCurrentState == SERVICE_STOP_PENDING)) {
        ssStatus.dwControlsAccepted = SERVICE_ACCEPT_SHUTDOWN;
     }
     else {
            ssStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
            if (Pausable()) ssStatus.dwControlsAccepted |= SERVICE_ACCEPT_PAUSE_CONTINUE;
     }

     ssStatus.dwCurrentState = dwCurrentState;
     ssStatus.dwWin32ExitCode = 0;
     ssStatus.dwWaitHint = ACTIONLIMIT;

     if ((dwCurrentState == SERVICE_RUNNING) ||
         (dwCurrentState == SERVICE_STOPPED) ||
         (dwCurrentState == SERVICE_PAUSED)) ssStatus.dwCheckPoint = 0;
     else ssStatus.dwCheckPoint = dwCheckPoint++;

     if (!(bResult = SetServiceStatus(sshStatusHandle, &ssStatus))) {
        PrintMessage(TEXT("Service status setting failed."), EVENTLOG_WARNING_TYPE);
     }
  }

  return bResult;
}


// service control handling method
VOID WINAPI controlHandler(DWORD dwCtrlCode)
{
  switch (dwCtrlCode) {
         case SERVICE_CONTROL_STOP:
              ReportStatus(SERVICE_STOP_PENDING);
              Destroy();              
              return;

         case SERVICE_CONTROL_PAUSE:
              ReportStatus(SERVICE_PAUSE_PENDING);
              Stop();
              break;

         case SERVICE_CONTROL_CONTINUE:
              ReportStatus(SERVICE_CONTINUE_PENDING);
              Start();
              break;

         case SERVICE_CONTROL_INTERROGATE:
              Probe();
              break;
       
         default: {
                    ReportStatus(SERVICE_STOP_PENDING);
                    return;
         }
  }
}


// service main method started for running the service
void WINAPI serviceMain(DWORD dwArgc, LPTSTR *lpszArgv)
{
  LPTSTR szAppParameters;
  LPTSTR *lpszNewArgv = NULL;
  DWORD dwNewArgc;
  UINT i;

  sshStatusHandle = RegisterServiceCtrlHandler(TEXT(szServiceName), controlHandler);

  if (sshStatusHandle) {

     ssStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
     ssStatus.dwServiceSpecificExitCode = 0;

     if (ReportStatus(SERVICE_START_PENDING)) {

        szAppParameters = getString(HKEY_LOCAL_MACHINE, szParamKey, SZAPPPARAMS);
        if (NULL == szAppParameters) {
           dwNewArgc = 0;
           lpszNewArgv = NULL;
        }   
        else {
               lpszNewArgv = getParameterArray(&dwNewArgc, szAppParameters);
               GlobalFree(szAppParameters);
        }

        Init(dwNewArgc, lpszNewArgv);
        for (i=0; i<dwNewArgc; i++) GlobalFree(lpszNewArgv[i]);
        if (NULL != lpszNewArgv) GlobalFree(lpszNewArgv);
     }
     ReportStatus(SERVICE_STOPPED);
  }
}


// launcher help method
void help(LPTSTR name)
{
  printf ("\nUsage:\n\n");
  printf ("%s <option> [-Sservice] [-(D|X)java ...] className [(-(D|X)java|app) ...]\n\n", name);
  printf("Options:\n");
  printf("-i  install service\n");
  printf("-r  remove service\n");
  printf("-c  run as a console application\n\n");
  printf("    className  name of the main application or daemon class\n");
  printf("    app        an application parameter\n");
  printf("    java       a Java VM parameter\n");
  printf("    service    a service parameter with the leftmost character indicating its name:\n");
  printf("               V  Java VM library type, i.e. \"hotspot\" or \"server\"\n");
  printf("               L  Java VM library path (ignores library type if applied)\n");
  printf("               N  service display name\n");
  printf("               W  working directory\n");
}


// construction of the service name
BOOL hasServiceName()
{
  UINT i;
  LPTSTR p;

  if (0 == GetModuleFileName(NULL, szPath, _MAX_PATH)) {
     PrintError(TEXT("Module filename reading failed."));
     return FALSE;
  }

  _splitpath(szPath, NULL, NULL, szServiceName, NULL);

  szParamKey[0] = '\0';
  p = szParamKey;
  strcpy(szParamKey, (LPTSTR)SZPARAMPATH); 
  i = strlen(p); p += i;
  strncpy(p, szServiceName, _MAX_PATH - i); 
  i = strlen(p); p += i;
  strncpy(p, (LPTSTR)SZPARAMKEY, _MAX_PATH - i); 
  szParamKey[_MAX_PATH] = '\0';

  return TRUE;
}


// main method calling the service main method if applicable
void _CRTAPI1 main(int argc, char **argv)
{
  CONSOLE_CURSOR_INFO info;
  LPTSTR szAppParameters, p, q;
  LPTSTR *lpszNewArgv;
  DWORD dwNewArgc;
  UINT i;

  SERVICE_TABLE_ENTRY serviceTable[] =
  {
    {NULL, (LPSERVICE_MAIN_FUNCTION)serviceMain},
    {NULL, NULL}
  };

  // determine console availability
  if (GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info)) {
     if (info.bVisible) bConsole = TRUE;
  }

  lpszNewArgv = NULL;
  dwNewArgc = 0;
  szAppParameters = getCommandString(argc, argv);
  lpszNewArgv = getParameterArray(&dwNewArgc, szAppParameters);
  if (NULL != szAppParameters) GlobalFree(szAppParameters);

  if (hasServiceName()) {
     if (bConsole) {
        if (dwNewArgc > 1) {
           if (!_stricmp(lpszNewArgv[1],"-i") || !_stricmp(lpszNewArgv[1],"/i")) {
              installService(dwNewArgc, lpszNewArgv);
           }
           else {
                  if (!_stricmp(lpszNewArgv[1],"-r") || !_stricmp(lpszNewArgv[1],"/r")) {
                     removeService(dwNewArgc, lpszNewArgv);
                  }
                  else {
                         if (!_stricmp(lpszNewArgv[1],"-c") || !_stricmp(lpszNewArgv[1],"/c")) {
                            Init(dwNewArgc - 2, lpszNewArgv + 2);
                         }
                         else help(szServiceName);
                  }
           }
        }
        else help(szServiceName);

        for (i=0; i<dwNewArgc; i++) GlobalFree(lpszNewArgv[i]);
        if (NULL != lpszNewArgv) GlobalFree(lpszNewArgv);
        exit(0);
     }
       
     serviceTable[0].lpServiceName = TEXT(szServiceName);
     if (!StartServiceCtrlDispatcher(serviceTable)){
        printf("\n%s\n", SZFAILURE);    
        PrintError(TEXT(SZFAILURE));
     }
  }
  else exit(1);
}
