#ifndef _REGISTRY_H_
#define _REGISTRY_H_

// Java Daemon API JSR
// This module contains methods for accessing the registry database
// tk, 2000-11-26

#ifdef __cplusplus
extern "C" {
#endif

LPTSTR getString(HKEY, LPCTSTR, LPTSTR);
BOOL setString(CONST LPTSTR, HKEY, LPCTSTR, LPCTSTR);
BOOL setKey(HKEY, LPCTSTR);

#ifdef __cplusplus
}
#endif

#endif
