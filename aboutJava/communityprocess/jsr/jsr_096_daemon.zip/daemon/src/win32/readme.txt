Java Daemon API / NT 4.0 Preliminary RI Sources

The sources can be compiled and linked under an NT 4.0 C development environment
by calling "nmake" from a console window in the source directory. NMAKE uses the 
makefile file of the source directory for compiling and linking the C sources.

The preliminary RI consists of the following modules:

- The vm.h and vm.c helper files contain sources for accessing the JNI invocation API.
  The sources are based on the Sun JDK launcher sources.

- The arg.h and arg.c helper files contain sources for parsing and converting parameters.
- The registry.h and registry.c helper files contain sources for accessing the NT registry.
- The service.h and service.c helper files contain sources for installing, removing and
  launching the deamon service container.
  The module structure is based on a tutorial of Bill Giel (bgiel@mail2.nai.net) after
  some important modifications having been made.

- The javad.h and javad.c files contain headers and sources for implementing a native Java
  daemon container.
  The implementation supplies a JNI based daemon container on behalf of the above-cited
  helper modules.

The preliminary RI supplies the JAVAD daemon launcher and installer, which requires the
Java daemon API classes and interfaces contained in the daemon.jar file. 

Thus, the daemon.jar file must be contained in the class path, e.g. by 
copying it to the Java runtime lib/ext directory for simplicity.


The JAVAD launcher and installer is a command line utility with the following syntax:

javad <option> [-Sservice] [-(D|X)java ...] className [(-(D|X)java|app) ...]

Options:
-i  install service
-r  remove service
-c  run as a console application

    className  name of the main application or daemon class
    app        an application parameter
    java       a Java VM parameter
    service    an optional service parameter with the leftmost character 
               indicating its name, i.e ...
               
               V  Java VM library type, e.g. "hotspot" or "server"
               L  Java VM library path (ignores library type if applied)
               N  service display name
               W  working directory

The -i option installes the daemon container for hosting the specified daemon class
as an NT 4.0 service. The native service accepts control events via the NT service
panel in accordance with the interface supplied, i.e. Daemon or Pausable.

The remaining command line parameters are stored as the service parameters.
Application parameters contained in the command line are supplied to the 
specified daemon class as the daemon attributes using the equal sign for
separating an attribute name from its corresponding attribute value.

Parameters, which are not of the "<name>=<value>" format are supplied as
attribute names, which map to the null value. The order of the parameters is
retainend from left to right for the daemon getAttributeNames() enumeration. 

Note: Duplicate parameters overwrite previous occurrences.
      The -cp Java VM option is supported and should normally be supplied to javad.

Example:
javad -i -cp .;\daemon\doc\samples\Walker;\daemon\lib\daemon.jar Walker max=2

installes the daemon container for launching the Walker daemon contained in the
samples directory of the Java daemon JSR. The Walker "max" attribute for specifying
the maximum number of walking cycles is set to 2.

The -r option removes an installed daemon container. 
No additional parameters are required.

Example:
javad -r

The -c option serves for testing purposed prior to installation
by launching the service from the command line.

Example:
javad -c -cp .;\daemon\doc\samples\Walker;\daemon\lib\daemon.jar Walker


Known Problems:

- The NT service control manager does not immediately reflect state updates signaled.
  Updates are not visible prior to closing and re-opening the NT service panel.
  This may be a problem of the RI or of NT and would have to be evaluated in detail.

- The daemon state is not changed after init() or start() when calling down() from
  inside these method calls. This is in accordance with the indended behaviour. 
  Exception parameters of the down() method, however, are not signaled in this case.
  This might not be a suitable behaviour and would have to be evaluated in detail.

tk, 2000-11-26.
