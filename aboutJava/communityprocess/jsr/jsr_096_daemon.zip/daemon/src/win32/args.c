// Java Daemon API JSR
// This module contains methods for parsing and converting parameter structures
// tk, 2000-11-26

#include <ansiapi.h>
#include <windows.h>

#include "args.h"

#define PREFIX "-/"
#define JAVATYPE "DX"
#define SERVICETYPE "S"

#define JAVAEXTRA1 "-cp "
#define JAVAEXTRA2 "-classpath "
#define JAVAREPLACE "-Djava.class.path="


// parsing generic parameter array
LPTSTR *getParameters(LPTSTR pJava, LPTSTR pService, PDWORD pLen, DWORD argc, LPTSTR *pArgv)
{
  int i, j, k;
  LPTSTR *pArgs;
  BOOL service = TRUE;

  *pLen = 0;
  if ((argc < 1)||(NULL == pArgv)) return NULL;

  for (i=0, k=0; i < argc; i++) {
      if (NULL == pJava) {
         if (service) {
            if (strlen(pArgv[i]) > 2) {
               if (strchr(PREFIX, *(pArgv[i]))&&
                   strchr(pService, *(pArgv[i] + 1))) k++;
               else service = FALSE;
            }
            else service = FALSE;
         }
         else break;
      }
      else {
             if (NULL == pService) {
                if (strlen(pArgv[i]) > 2) {
                   if (strchr(PREFIX, *(pArgv[i]))&&
                      strchr(pJava, *(pArgv[i] + 1))) {
                      k++;
                      service = FALSE;
                   }
                }
                else service = FALSE;
             }
             else {
                    if (strlen(pArgv[i]) > 2) {
                       if ((!(strchr(PREFIX, *(pArgv[i]))))||
                           ((!(strchr(pJava, *(pArgv[i] + 1))))&&
                            (!(service&&strchr(pService, *(pArgv[i] + 1)))))) {
                            k++;
                            service = FALSE;
                       }
                    }
                    else {
                           k++;
                           service = FALSE;
                    }
             }
      }
  }

  if (k < 1) return NULL;

  pArgs = (LPTSTR *)GlobalAlloc(GMEM_FIXED, k * sizeof(LPTSTR));
  *pLen = k;

  service = TRUE;
  for (i=0, j=0; i < argc; i++) {
      if (NULL == pJava) {
         if (service) {
            if (strlen(pArgv[i]) > 2) {
               if ((!(strchr(PREFIX, *(pArgv[i]))))||
                   (!(strchr(pService, *(pArgv[i] + 1))))) {
                  service = FALSE;
                  continue;
               }
            }
            else {
                   service = FALSE;
                   continue;
            }
         }
         else break;
      }
      else { 
             if (NULL == pService) {
                if (strlen(pArgv[i]) > 2) {
                   if ((!(strchr(PREFIX, *(pArgv[i]))))||
                       (!(strchr(pJava, *(pArgv[i] + 1))))) continue;
                   else service = FALSE;
                }
                else {
                       service = FALSE;
                       continue;
                }
             }
             else {
                    if (strlen(pArgv[i]) > 2) {
                       if (strchr(PREFIX, *(pArgv[i]))&&
                           (strchr(pJava, *(pArgv[i] + 1))||
                            (service&&strchr(pService, *(pArgv[i] + 1))))) continue;
                       else service = FALSE;
                    }
                    else service = FALSE;
             }
      }
     
      pArgs[j] = (LPTSTR)GlobalAlloc(GMEM_FIXED, (strlen(pArgv[i]) + 1) * sizeof(TCHAR));
      strcpy(pArgs[j], pArgv[i]);
      j++;
  }

  return pArgs;
}


// parsing service specific parameter array
LPTSTR *getServiceParameters(PDWORD pLen, DWORD argc, LPTSTR *pArgv)
{
  return getParameters(NULL, SERVICETYPE, pLen, argc, pArgv);
}


// parsing Java specific parameter array
LPTSTR *getJavaParameters(PDWORD pLen, DWORD argc, LPTSTR *pArgv)
{
  return getParameters(JAVATYPE, NULL, pLen, argc, pArgv);
}


// parsing daemon specific parameter array
LPTSTR *getDaemonParameters(PDWORD pLen, DWORD argc, LPTSTR *pArgv)
{
  return getParameters(JAVATYPE, SERVICETYPE, pLen, argc, pArgv);
}


// converting command string to parameter array
LPTSTR *getParameterArray(PDWORD pArgc, LPTSTR pCommandLine)
{
  int i, k, j;
  LPTSTR *pArgs;
  LPWSTR *lpszwArgs;
  LPWSTR lpszwArgstring;
  LPTSTR lpszArgnormal, p;

  *pArgc = 0;
  pArgs = NULL;

  if (NULL == pCommandLine) return NULL;

  i = strlen(pCommandLine);

  if (i < 1) return NULL;

  lpszArgnormal = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 15) * sizeof(TCHAR));

  p = strstr(pCommandLine, (LPTSTR)JAVAEXTRA1);
  if (NULL != p) {
     j = p - pCommandLine;
     strncpy(lpszArgnormal, pCommandLine, j);
     strcpy(lpszArgnormal + j, (LPTSTR)JAVAREPLACE);
     strcpy(lpszArgnormal + j + strlen((LPTSTR)JAVAREPLACE), p + strlen((LPTSTR)JAVAEXTRA1));
  }
  else {
         p = strstr(pCommandLine, (LPTSTR)JAVAEXTRA2);
         if (NULL != p) {
            j = p - pCommandLine;
            strncpy(lpszArgnormal, pCommandLine, j);
            strcpy(lpszArgnormal + j, (LPTSTR)JAVAREPLACE);
            strcpy(lpszArgnormal + j + strlen((LPTSTR)JAVAREPLACE), p + strlen((LPTSTR)JAVAEXTRA2));
         }
         else strcpy(lpszArgnormal, pCommandLine);
  }

  i = strlen(lpszArgnormal) + 1;
  lpszwArgstring = (LPWSTR)GlobalAlloc(GMEM_FIXED, i * sizeof(WCHAR));
  A2W(lpszArgnormal, lpszwArgstring, i);

  GlobalFree(lpszArgnormal);
  
  lpszwArgs = CommandLineToArgvW(lpszwArgstring, &k);

  GlobalFree(lpszwArgstring);

  if (NULL == lpszwArgs) return NULL;

  pArgs = (LPTSTR *)GlobalAlloc(GMEM_FIXED, k * sizeof(LPTSTR));
  *pArgc = k;

  for (i = 0; i < k; i++) {
      j = lstrlenW(lpszwArgs[i]) + 1;
      pArgs[i] = (LPTSTR)GlobalAlloc(GMEM_FIXED, j * sizeof(TCHAR));
      W2A(lpszwArgs[i], pArgs[i], j);
      GlobalFree(lpszwArgs[i]);
  }
  
  GlobalFree(lpszwArgs);

  return pArgs;
}


// converting array to generic parameter string
LPTSTR getParameterString(DWORD argc, LPTSTR *pArgv, DWORD start)
{
  int i, k;
  char *b;
  LPTSTR lpszTarget, p;

  if (start >= argc) return NULL;

  k = 0;
  for (i=start; i<argc; i++) k += (strlen(pArgv[i]) + 3);
  
  lpszTarget = (LPTSTR)GlobalAlloc(GMEM_FIXED, k * sizeof(TCHAR));

  p = lpszTarget;
  for (i=start; i<argc; i++) {
      if (i != start) strcpy(p++," ");
      b = strchr(pArgv[i], ' ');
      if (b) strcpy(p++, "\"");
      strcpy(p, pArgv[i]);
      p += strlen(pArgv[i]);
      if (b) strcat(p++, "\"");
  }

  return lpszTarget;
}


// converting parameter array to command string
LPTSTR getCommandString(DWORD argc, LPTSTR *pArgv)
{
  return getParameterString(argc, pArgv, 0);
}


// converting parameter array to service string
LPTSTR getServiceString(DWORD argc, LPTSTR *pArgv)
{
  return getParameterString(argc, pArgv, 2);
}
