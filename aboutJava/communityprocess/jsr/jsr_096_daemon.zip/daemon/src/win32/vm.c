// Java Daemon API JSR
// This module contains methods for accessing the JVM invocation API.
// tk, 2000-11-26

// These parts of the code are based on the Sun JDK standard launcher code java_md.c
// The sources have been slightly adapted for demonstration purposes, only.
// Some methods not required for java daemons have been removed.

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <jni.h>

#include "vm.h"

#define JAVA_DLL "java.dll"
#define JVM_DLL "jvm.dll"

static BOOL GetPublicJREHome(char *path, int pathsize);

BOOL GetJREPath(char *path, int pathsize)
{
    char javadll[_MAX_PATH];
    struct stat s;

    if (GetApplicationHome(path, pathsize)) {
	/* Is JRE co-located with the application? */
	sprintf(javadll, "%s\\bin\\" JAVA_DLL, path);
	if (stat(javadll, &s) == 0) {
	    goto found;
	}

	/* Does this app ship a private JRE in <apphome>\jre directory? */
	sprintf(javadll, "%s\\jre\\bin\\" JAVA_DLL, path);
	if (stat(javadll, &s) == 0) {
	    strcat(path, "\\jre");
	    goto found;
	}
    }

    /* Look for a public JRE on this machine. */
    if (GetPublicJREHome(path, pathsize)) {
	goto found;
    }

    PrintError(TEXT("Could not find Java DLL"));
    return FALSE;

 found:
    return TRUE;
}

BOOL GetJVMPath(const char *jrepath, const char *jvmtype, char *jvmpath, int jvmpathsize)
{
    struct stat s;
    sprintf(jvmpath, "%s\\bin\\%s\\" JVM_DLL, jrepath, jvmtype);
    if (stat(jvmpath, &s) == 0) {
	return TRUE;
    } else {
	return JNI_FALSE;
    }
}

/*
 * Load a jvm from "jvmpath" and intialize the invocation functions.
 */
BOOL LoadJavaVM(const char *jvmpath, InvocationFunctions *ifn)
{
    HINSTANCE handle;

    /* Load the Java VM DLL */
    if ((handle = LoadLibrary(jvmpath)) == 0) {
	PrintError(TEXT("Error loading VM"));
	return FALSE;
    }

    /* Now get the function addresses */
    ifn->CreateJavaVM =
	(void *)GetProcAddress(handle, "JNI_CreateJavaVM");
    ifn->GetDefaultJavaVMInitArgs =
	(void *)GetProcAddress(handle, "JNI_GetDefaultJavaVMInitArgs");
    if (ifn->CreateJavaVM == 0 || ifn->GetDefaultJavaVMInitArgs == 0) {
	PrintError(TEXT("Cannot find JNI interfaces in VM"));
	return FALSE;
    }

    return TRUE;
}


/*
 * If app is "c:\foo\bin\javac", then put "c:\foo" into buf.
 */
BOOL GetApplicationHome(char *buf, int bufsize)
{
    char *cp;
    GetModuleFileName(0, buf, bufsize);
    *strrchr(buf, '\\') = '\0'; /* remove .exe file name */
    if ((cp = strrchr(buf, '\\')) == 0) {
	/* This happens if the application is in a drive root, and
	 * there is no bin directory. */
	buf[0] = '\0';
	return FALSE;
    }
    *cp = '\0';  /* remove the bin\ part */
    return TRUE;
}


/*
 * Helpers to look in the registry for a public JRE.
 */
#define DOTRELEASE  "1.3" /* Same for 1.3.1, 1.3.2 etc. */
#define JRE_KEY	    "Software\\JavaSoft\\Java Runtime Environment"

static BOOL GetStringFromRegistry(HKEY key, const char *name, char *buf, int bufsize)
{
    DWORD type, size;

    if (RegQueryValueEx(key, name, 0, &type, 0, &size) == 0
	&& type == REG_SZ
	&& (size < (unsigned int)bufsize)) {
	if (RegQueryValueEx(key, name, 0, 0, buf, &size) == 0) {
	    return TRUE;
	}
    }
    return FALSE;
}

static BOOL GetPublicJREHome(char *buf, int bufsize)
{
    HKEY key, subkey;
    char version[_MAX_PATH];

    /* Find the current version of the JRE */
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, JRE_KEY, 0, KEY_READ, &key) != 0) {
	PrintError(TEXT("Error opening registry key for Java runtime"));
	return FALSE;
    }

    if (!GetStringFromRegistry(key, "CurrentVersion",
			       version, sizeof(version))) {
	PrintError(TEXT("Failed reading current version value of Java runtime"));
	RegCloseKey(key);
	return FALSE;
    }

    if (strcmp(version, DOTRELEASE) != 0) {
	PrintError(TEXT("Current VM does not implement the required Java version"));
	RegCloseKey(key);
	return FALSE;
    }

    /* Find directory where the current version is installed. */
    if (RegOpenKeyEx(key, version, 0, KEY_READ, &subkey) != 0) {
	PrintError(TEXT("Error opening registry key for Java runtime"));
	RegCloseKey(key);
	return FALSE;
    }

    if (!GetStringFromRegistry(subkey, "JavaHome", buf, bufsize)) {
	PrintError(TEXT("Failed reading value of registry key for Java runtime"));
	RegCloseKey(key);
	RegCloseKey(subkey);
	return FALSE;
    }

    RegCloseKey(key);
    RegCloseKey(subkey);
    return TRUE;
}

