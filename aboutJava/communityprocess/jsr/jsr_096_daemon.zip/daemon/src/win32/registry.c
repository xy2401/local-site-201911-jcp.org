// Java Daemon API JSR
// This module contains methods for accessing the registry database
// tk, 2000-11-26

#include <windows.h>

#include "registry.h"

// class for new keys
#define KEY_CLASS "LocalSystem"


// reading registered string
LPTSTR getString(HKEY hkRoot, LPCTSTR lpszPath, LPTSTR lpszValue)
{
  LONG result;
  HKEY hKey;
  DWORD dwType;
  DWORD cbLen;
  LPBYTE lpVal;

  result = RegOpenKeyEx(hkRoot, lpszPath, (DWORD)0, KEY_EXECUTE | KEY_QUERY_VALUE, (PHKEY)&hKey);
  if (result != ERROR_SUCCESS) return NULL;

  RegQueryValueEx(hKey, lpszValue, NULL, (LPDWORD)&dwType, NULL, &cbLen);
  if (cbLen < 1) {
     RegCloseKey(hKey);
     return NULL;
  }

  lpVal = (LPBYTE)GlobalAlloc(GMEM_FIXED, cbLen);
  if (NULL == lpVal) {
     RegCloseKey(hKey);
     return NULL;
  }

  result = RegQueryValueEx(hKey, lpszValue, NULL, (LPDWORD)&dwType, lpVal, &cbLen);    
  RegCloseKey(hKey);

  if ((result == ERROR_SUCCESS)&&((dwType == REG_SZ)||(dwType == REG_EXPAND_SZ))) {
     return (LPTSTR)lpVal;
  }
  else {
         GlobalFree((HGLOBAL)lpVal);
         return NULL;
  }
}


// registering specified string
BOOL setString(CONST LPTSTR lpVal, HKEY hkRoot, LPCTSTR lpszPath, LPCTSTR lpszValue)
{
  LONG result;
  HKEY hKey;

  result = RegOpenKeyEx(hkRoot, lpszPath, (DWORD)0, KEY_WRITE, (PHKEY)&hKey);
  if (result != ERROR_SUCCESS) return FALSE;
  result = RegSetValueEx(hKey, lpszValue, (DWORD)0, (DWORD)REG_SZ, lpVal, (strlen(lpVal) + 1));    
  RegCloseKey(hKey);
  return (result == ERROR_SUCCESS);
}


// registering specified key
BOOL setKey(HKEY hkRoot, LPCTSTR lpszPath)
{
  LPTSTR lpszClass = (LPTSTR)KEY_CLASS;
  LONG result;
  HKEY hKey;
  DWORD disposition;

  result = RegCreateKeyEx(hkRoot, lpszPath, (DWORD)0, lpszClass, REG_OPTION_NON_VOLATILE,
                          KEY_ALL_ACCESS, NULL, (PHKEY)&hKey, (LPDWORD)&disposition);

  if (result != ERROR_SUCCESS) return FALSE;
  RegCloseKey(hKey);
  return (result == ERROR_SUCCESS);
}
