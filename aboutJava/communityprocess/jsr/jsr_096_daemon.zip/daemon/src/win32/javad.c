// Java Daemon API JSR
// This module contains methods for controlling Java daemons
// tk, 2000-11-26

#include <windows.h>
#include <jni.h>

#include "vm.h"
#include "args.h"
#include "service.h"
#include "javad.h"

#define MAX_OPTIONS 20

// interval for informing the service control manager
#define PROBE_INTERVAL INFINITE

#define SZWRKDIR "wW"
#define SZLIBPATH "lL"
#define SZLIBTYPE "vV"

#define SZSEPARATOR "="

#define CLASS_GHOSTING "jsr/daemon/Daemon"
#define CLASS_DAEMON "jsr/daemon/GenericDaemon"
#define CLASS_CONTEXT "jsr/daemon/DaemonContext"
#define CLASS_CONTROL "jsr/daemon/DaemonControl"
#define CLASS_LISTENING "jsr/daemon/DaemonListener"
#define CLASS_LISTENER "jsr/daemon/jni/NativeDaemonAdapter"

#define CLASS_PAUSING "jsr/daemon/pausable/Pausable"
#define CLASS_PAUSABLE "jsr/daemon/pausable/PausableDaemon"
#define CLASS_EXTENDED "jsr/daemon/pausable/PausableDaemonControl"
#define CLASS_DETAILED "jsr/daemon/pausable/jni/NativePausableAdapter"

#define CLASS_LOGGING "jsr/daemon/logging/Logging"
#define CLASS_LOGGER "jsr/daemon/logging/jni/NativeLogger"


// entry points of system interface
HANDLE  hServiceEvent = NULL;
LPTSTR *lpszServiceArgs=NULL, *lpszJavaArgs=NULL, *lpszAppArgs=NULL;
DWORD dwSLen=0, dwJLen=0, dwALen=0;

// configuration flags
BOOL ghosting = FALSE;
BOOL pausable = FALSE;

// runtime flags
BOOL created = FALSE;
BOOL running = FALSE;
BOOL pausing = FALSE;
BOOL restarting = FALSE;

// entry points of invocation interface
JNIEnv *env;
JavaVM *vm;

// entry points of daemon interface
jclass clsMain = 0, clsContext = 0, clsControl = 0, clsLogger = 0, clsListener = 0;
jobject objMain = 0, objContext = 0, objControl = 0, objLogger = 0, objListener = 0;


// console event handler routine
BOOL WINAPI logoffHandler(DWORD dwCtrlType)
{
  switch (dwCtrlType){
 	   case CTRL_C_EVENT:
         case CTRL_CLOSE_EVENT:
         case CTRL_SHUTDOWN_EVENT:
	 		 Destroy();
			 return TRUE;

 	   case CTRL_LOGOFF_EVENT:
	             return TRUE;
  }
  return FALSE;
}


// native log method being linked to the native logger
void log(JNIEnv *env, jobject obj, jstring s) {
     const char *str = (*env)->GetStringUTFChars(env, s, 0);

     PrintInfo((LPTSTR)str);

     (*env)->ReleaseStringUTFChars(env, s, str);
}


// method for dumping errors
void Dump(jthrowable throwable) {
     jclass clsThrowable;
     jmethodID mid;
     jstring s;
 
     if (0 != throwable) {
        clsThrowable = (*env)->FindClass(env, "java/lang/Throwable");
        if (0 != clsThrowable) {
           mid = (*env)->GetMethodID(env, clsThrowable, "getMessage", "()Ljava/lang/String;");
           if (0 != mid) {
              s = (*env)->CallObjectMethod(env, throwable, mid);
              if (0 != s) {
                 const char *str = (*env)->GetStringUTFChars(env, s, 0);

                 PrintError((LPTSTR)str);

                 (*env)->ReleaseStringUTFChars(env, s, str);
              }
              else PrintError(TEXT("Throwable message access failed.")); 
           }
           else PrintError(TEXT("Throwable message access failed.")); 
        }
        else PrintError(TEXT("Throwable class not available.")); 
     }
}


// native listening method being linked to daemon listener
void active(JNIEnv *env, jobject obj, jobject daemon, jboolean active, jthrowable throwable) {
     Dump(throwable);
     Probe();
}


// native listening method being linked to pausable listener
void paused(JNIEnv *env, jobject obj, jobject pausable, jboolean paused, jthrowable throwable) {
     Dump(throwable);
     Probe();
}


// daemon indication method
BOOL Ghosting()
{
  return ghosting;
}


// pausability indication method
BOOL Pausable()
{
  return pausable;
}


// jvm invocation method
void InvokeJVM()
{
  jint res;
  jclass clsd, clsp;    
  jmethodID mid;
  jstring jstr, jkey;
  jobjectArray args;
  jthrowable exception;
  JavaVMInitArgs vm_args;
  JavaVMOption options[MAX_OPTIONS];
  JNINativeMethod native[2];
  InvocationFunctions ifn;
  
  LPTSTR jrepath[_MAX_PATH], jvmpath[_MAX_PATH];
  LPTSTR wrkdir, libpath, jvmtype;
  LPTSTR szKey, szValue, p;
  UINT i;

  if (dwALen < 1) {
     PrintError(TEXT("No main class supplied."));
     return;
  }

  if (dwJLen > MAX_OPTIONS){
     PrintError(TEXT("Maximum number of Java parameters exceeded."));
     return;
  }

  libpath = NULL;
  jvmtype = SZJVMTYPE;
  if (dwSLen > 0) {
     wrkdir = NULL;
     for (i=0; i<dwSLen; i++){
         if (NULL != strchr((LPTSTR)SZWRKDIR, *(lpszServiceArgs[i] + 2))) {
            wrkdir = (lpszServiceArgs[i] + 3);
         }
         else {
                if (NULL != strchr((LPTSTR)SZLIBPATH, *(lpszServiceArgs[i] + 2))) {
                   libpath = (lpszServiceArgs[i] + 3);
                }
                else {
                       if (NULL != strchr((LPTSTR)SZLIBTYPE, *(lpszServiceArgs[i] + 2))) {
                          jvmtype = (lpszServiceArgs[i] + 3);
                       }
                }
         }
     }

     if (NULL != wrkdir) {
        if (strlen(wrkdir) > 0) {
           if (0 != _chdir(wrkdir)) PrintError(TEXT("Changing working directory failed."));
        }
     }
  }

  if (NULL == libpath) {
     jrepath[0] = '\0';
     if (!GetJREPath((LPTSTR)jrepath, sizeof(jrepath))) {
        PrintError(TEXT("JRE path location failed."));
        return;
     }

     jvmpath[0] = '\0';
     if (!GetJVMPath((LPTSTR)jrepath, jvmtype, (LPTSTR)jvmpath, sizeof(jvmpath))) {
        PrintError(TEXT("VM path location failed."));
        return;
     }

     libpath = (LPTSTR)jvmpath;     
  }

  if (NULL == libpath) {
     PrintError(TEXT("VM library location failed."));
     return;
  }

  ifn.CreateJavaVM = 0; ifn.GetDefaultJavaVMInitArgs = 0;
  if (!LoadJavaVM(libpath, &ifn)) {
     PrintError(TEXT("VM loading failed."));
     return;
  }

  for (i=0; i<dwJLen; i++){
      options[i].optionString = lpszJavaArgs[i];
  }

  vm_args.version = JNI_VERSION_1_2;
  vm_args.options = options;
  vm_args.nOptions = dwJLen;
  vm_args.ignoreUnrecognized = TRUE;

  res = ifn.CreateJavaVM(&vm, (void **)&env, &vm_args);

  if (res < 0) {
     PrintError(TEXT("VM creation failed."));
     return;
  }

  created = TRUE;
  clsMain = (*env)->FindClass(env, lpszAppArgs[0]);
  if (0 == clsMain) {
     PrintError(TEXT("Main class not available."));
     return;
  }

  // checking main class for daemon or even pausable interface
  clsd = (*env)->FindClass(env, CLASS_DAEMON);
  if (0 != clsd) {
     if ((*env)->IsAssignableFrom(env, clsMain, clsd)) {
        ghosting = TRUE;
        clsp = (*env)->FindClass(env, CLASS_PAUSABLE);
        if (0 != clsp) {
           if ((*env)->IsAssignableFrom(env, clsMain, clsp)) {
              pausable = TRUE;
           }
        }
     }
  }

  if (ghosting) {

     // looking up for context class
     clsContext = (*env)->FindClass(env, CLASS_CONTEXT);
     if (0 == clsContext) {
        PrintError(TEXT("Context class not available."));
        return;
     }

     // looking up for (extended) control class
     if (pausable) clsControl = (*env)->FindClass(env, CLASS_EXTENDED);
     else clsControl = (*env)->FindClass(env, CLASS_CONTROL);
     if (0 == clsControl) {
        PrintError(TEXT("Control class not available."));
        return;
     }

     // looking up for listener class
     if (pausable) clsListener = (*env)->FindClass(env, CLASS_DETAILED);
     else clsListener = (*env)->FindClass(env, CLASS_LISTENER);
     if (0 == clsListener) {
        PrintError(TEXT("Listener class not available."));
        return;
     }

     // looking up for logger class
     clsLogger = (*env)->FindClass(env, CLASS_LOGGER);
     if (0 == clsLogger) {
        PrintError(TEXT("Logger class not available."));
        return;
     }

     mid = (*env)->GetMethodID(env, clsLogger, "<init>", "()V");
     if (0 == mid) {
        PrintError(TEXT("Logger default constructor not available."));
        return;
     }

     objLogger = (*env)->NewGlobalRef(env, (*env)->NewObject(env, clsLogger, mid));
     if (0 == objLogger) {
        PrintError(TEXT("Logger object creation failed."));
        return;
     }

     // linking native log method to its logger
     native[0].name = "log";
     native[0].signature = "(Ljava/lang/String;)V";
     native[0].fnPtr = log;
     if (0 != (*env)->RegisterNatives(env, clsLogger, (JNINativeMethod *)(&native), (jint)1)) {
        PrintError(TEXT("Native log method registration failed."));
        return;
     }

     mid = (*env)->GetMethodID(env, clsListener, "<init>", "()V");
     if (0 == mid) {
        PrintError(TEXT("Listener default constructor not available."));
        return;
     }

     objListener = (*env)->NewGlobalRef(env, (*env)->NewObject(env, clsListener, mid));
     if (0 == objListener) {
        PrintError(TEXT("Listener object creation failed."));
        return;
     }

     i = strlen((LPTSTR)CLASS_GHOSTING);
     szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 28) * sizeof(TCHAR));
     strcpy(szKey, "(L"); p = szKey + 2;
     strcpy(p, (LPTSTR)CLASS_GHOSTING); p += i;
     strcpy(p, ";ZLjava/lang/Throwable;)V");

     // linking native active method to its listener
     native[0].name = "active";
     native[0].signature = szKey;
     native[0].fnPtr = active;
     if (pausable) {

        i = strlen((LPTSTR)CLASS_PAUSING);
        szValue = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 28) * sizeof(TCHAR));
        strcpy(szValue, "(L"); p = szValue + 2;
        strcpy(p, (LPTSTR)CLASS_PAUSING); p += i;
        strcpy(p, ";ZLjava/lang/Throwable;)V");

        // linking native pause method to its listener
        native[1].name = "paused";
        native[1].signature = szValue;
        native[1].fnPtr = paused;

        if (0 != (*env)->RegisterNatives(env, clsListener, (JNINativeMethod *)(&native), (jint)2)) {
           GlobalFree(szValue);
           GlobalFree(szKey);
           PrintError(TEXT("Native pause method registration failed."));
           return;
        }
   
        GlobalFree(szValue);
     }     
     else {
            if (0 != (*env)->RegisterNatives(env, clsListener, (JNINativeMethod *)(&native), (jint)1)) {
               GlobalFree(szKey);
               PrintError(TEXT("Native active method registration failed."));
               return;
            }
     }
     GlobalFree(szKey);

     mid = (*env)->GetMethodID(env, clsMain, "<init>", "()V");
     if (0 == mid) {
        PrintError(TEXT("Daemon default constructor not available."));
        return;
     }

     objMain = (*env)->NewGlobalRef(env, (*env)->NewObject(env, clsMain, mid));
     if (0 == objMain) {
        PrintError(TEXT("Daemon object construction failed."));
        return;
     }

     i = strlen((LPTSTR)CLASS_LISTENING);
     szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 6) * sizeof(TCHAR));
     strcpy(szKey, "(L"); p = szKey + 2;
     strcpy(p, (LPTSTR)CLASS_LISTENING); p += i;
     strcpy(p, ";)V");

     mid = (*env)->GetMethodID(env, clsMain, "addListener", szKey);
     GlobalFree(szKey);

     if (0 == mid) {
        PrintError(TEXT("Listener adjunction method not available."));
        return;
     }

     // linking listener 
     (*env)->CallVoidMethod(env, objMain, mid, objListener);

     i = strlen((LPTSTR)CLASS_CONTEXT);
     szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 5) * sizeof(TCHAR));
     strcpy(szKey, "()L"); p = szKey + 3;
     strcpy(p, (LPTSTR)CLASS_CONTEXT); p += i;
     strcpy(p, ";");
    
     mid = (*env)->GetMethodID(env, clsMain, "getDaemonContext", szKey);
     GlobalFree(szKey);

     if (0 == mid) {
        PrintError(TEXT("Daemon context hook not available."));
        return;
     }

     objContext = (*env)->NewGlobalRef(env, (*env)->CallObjectMethod(env, objMain, mid));
     if (0 == objContext) {
        PrintError(TEXT("Daemon context object construction failed."));
        return;
     }

     i = strlen((LPTSTR)CLASS_LOGGING);
     szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 6) * sizeof(TCHAR));
     strcpy(szKey, "(L"); p = szKey + 2;
     strcpy(p, (LPTSTR)CLASS_LOGGING); p += i;
     strcpy(p, ";)V");

     // setting native daemon logger
     mid = (*env)->GetMethodID(env, clsContext, "setLogger", szKey);
     GlobalFree(szKey);

     if (0 == mid) {
        PrintError(TEXT("Daemon logger setting not available."));
        return;
     }

     // linking logger 
     (*env)->CallVoidMethod(env, objContext, mid, objLogger);


     // setting daemon name
     mid = (*env)->GetMethodID(env, clsContext, "setName", "(Ljava/lang/String;)V");
     if (0 == mid) {
        PrintError(TEXT("Daemon name setting not available."));
        return;
     }
     
     jstr = (*env)->NewStringUTF(env, getServiceName());
     if (0 == jstr) {
        PrintError(TEXT("Daemon name allocation failed."));
        return;
     }

     // linking context
     (*env)->CallVoidMethod(env, objContext, mid, jstr);
     

     // setting daemon environment capacity
     mid = (*env)->GetMethodID(env, clsContext, "setCapacity", "(I)V");
     if (0 == mid) {
        PrintError(TEXT("Daemon environment capacity setting not available."));
        return;
     }
     
     if (dwALen > 0) res = dwALen - 1;
     else res = 0;
     (*env)->CallVoidMethod(env, objContext, mid, res);

     if (dwALen > 1) {

        // setting daemon parameters
        mid = (*env)->GetMethodID(env, clsContext, "setAttribute",
                                   "(Ljava/lang/String;Ljava/lang/Object;)V");
        if (0 == mid) {
           PrintError(TEXT("Daemon attribute setting not available."));
           return;
        }

        for (i=0; i<dwALen - 1; i++){
            szKey = lpszAppArgs[i + 1];
            if (NULL != szKey) {
               szValue = strstr(szKey, (LPTSTR)SZSEPARATOR);
               if (NULL != szValue) {
                  *szValue = '\0';
                  szValue++;
                  jstr = (*env)->NewStringUTF(env, szValue);
                  if (0 == jstr) {
                     PrintError(TEXT("Daemon attribute value allocation failed."));
                     return;
                  }
               }
               else jstr = 0;
               jkey = (*env)->NewStringUTF(env, szKey);
               if (0 == jkey) {
                  PrintError(TEXT("Daemon attribute key allocation failed."));
                  return;
               }
            }
            else {
                   jkey = 0;
                   jstr = 0;
            }
            (*env)->CallVoidMethod(env, objContext, mid, jkey, jstr);
        }
     }

     // switching to life cycle methods
     i = strlen((LPTSTR)CLASS_CONTROL);
     szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 5) * sizeof(TCHAR));
     strcpy(szKey, "()L"); p = szKey + 3;
     strcpy(p, (LPTSTR)CLASS_CONTROL); p += i;
     strcpy(p, ";");
    
     mid = (*env)->GetMethodID(env, clsMain, "getDaemonControl", szKey);
     GlobalFree(szKey);

     if (0 == mid) {
        PrintError(TEXT("Daemon control hook not available."));
        return;
     }

     objControl = (*env)->NewGlobalRef(env, (*env)->CallObjectMethod(env, objMain, mid));
     if (0 == objControl) {
        PrintError(TEXT("Daemon control object construction failed."));
        return;
     }

     // calling control init method
     mid = (*env)->GetMethodID(env, clsControl, "init", "()V");
     if (0 == mid) {
        PrintError(TEXT("Control init method not available."));
        return;
     }
     
     (*env)->CallVoidMethod(env, objControl, mid);

     // checking for exceptions
     exception = (*env)->ExceptionOccurred(env);
     if (NULL != exception) {
        (*env)->ExceptionDescribe(env);
        (*env)->ExceptionClear(env);
        PrintError(TEXT("Exception during daemon init occurred."));
        return;
     }
  }
  else {
         // wrapping ordinary launcher applications with shutdown via System.exit()
         mid = (*env)->GetStaticMethodID(env, clsMain, "main", "([Ljava/lang/String;)V");
         if (0 == mid) {
            PrintError(TEXT("Application class main method not available."));
            return;
         }

         if (dwALen > 1){
            args = (*env)->NewObjectArray(env, dwALen - 1,
                                          (*env)->FindClass(env, "java/lang/String"), NULL);
           if (0 == args) {
              PrintError(TEXT("Application parameter array allocation failed."));
              return;
           }

           for (i=0; i<dwALen - 1; i++){
               jstr = (*env)->NewStringUTF(env, lpszAppArgs[i + 1]);
               if (0 == jstr) {
                  PrintError(TEXT("Application parameter string allocation failed."));
                  return;
               }
               (*env)->SetObjectArrayElement(env, args, i, jstr); 
           }
         }
         else {
                args = (*env)->NewObjectArray(env, 0,
                                             (*env)->FindClass(env, "java/lang/String"), NULL);
         }

         // calling main method
         (*env)->CallStaticVoidMethod(env, clsMain, mid, args);
  }

  SetConsoleCtrlHandler(logoffHandler, TRUE);
  
  // checking initialization state
  if (ghosting) {
     running = TRUE;
     if (!Probed()) {
        running = FALSE;
     }
  }
  else {
         if (ReportStatus(SERVICE_RUNNING)) running = TRUE;
  }
}


// termination event signal setting
VOID ServiceControl(BOOL hangon)
{
  running = hangon;
  if (hServiceEvent) SetEvent(hServiceEvent);
}


// service probing laucher
VOID Probe()
{
  ServiceControl(TRUE);
}


// service probing method
BOOL Probed()
{
  jmethodID mid;
  jthrowable exception;
  BOOL ok = TRUE;

  if (ghosting) {  

     mid = (*env)->GetMethodID(env, clsMain, "isActive", "()Z");
     if (0 == mid) {
        PrintError(TEXT("Daemon activity state method not available."));
        ok = FALSE;
     }
     else {
            if ((*env)->CallBooleanMethod(env, objMain, mid)) {
               ReportStatus(SERVICE_RUNNING);
            }
            else {
                   if (pausable) {
                      mid = (*env)->GetMethodID(env, clsMain, "isPaused", "()Z");
                      if (0 == mid) {
                         PrintError(TEXT("Daemon pause state method not available."));
                         ok = FALSE;
                      }
                      else {
                             if ((*env)->CallBooleanMethod(env, objMain, mid)) {
                                ReportStatus(SERVICE_PAUSED);
                             }
                             else {
                                    ReportStatus(SERVICE_STOPPED);
                                    running = FALSE;
                             }
                      }
                   }
                   else {
                          ReportStatus(SERVICE_STOPPED);
                          running = FALSE;
                   }
            }
     }
  }

  return ok;
}


// service start launcher method
VOID Start()
{
  restarting = TRUE;
  ServiceControl(TRUE);
}


// service start method
BOOL Started()
{
  jmethodID mid;
  jthrowable exception;
  BOOL ok = TRUE;

  restarting = FALSE;

  if (pausable) {  
  
     // calling control start method
     mid = (*env)->GetMethodID(env, clsControl, "start", "()V");
     if (0 == mid) {
        PrintError(TEXT("Control start method not available."));
        ok = FALSE;
     }
     else (*env)->CallVoidMethod(env, objControl, mid);

     // checking for exceptions
     exception = (*env)->ExceptionOccurred(env);
     if (NULL != exception) {
           (*env)->ExceptionDescribe(env);
           (*env)->ExceptionClear(env);
           PrintError(TEXT("Exception during daemon start occurred."));
           ok = FALSE;
     }
     else ok = Probed();
  }
  else {
         PrintError(TEXT("Start method restricted to pausable daemons."));
         ok = FALSE;
  }

  return ok;
}


// service stop launcher method
VOID Stop()
{
  pausing = TRUE;
  ServiceControl(TRUE);
}


// service stop method
BOOL Stopped()
{
  jmethodID mid;
  BOOL ok = TRUE;

  pausing = FALSE;

  if (pausable) {  

     // calling control stop method
     mid = (*env)->GetMethodID(env, clsControl, "stop", "()V");
     if (0 == mid) {
        PrintError(TEXT("Control stop method not available."));
        ok = FALSE;
     }
     else (*env)->CallVoidMethod(env, objControl, mid);
     ReportStatus(SERVICE_PAUSED);
  }
  else {
         PrintError(TEXT("Stop method restricted to pausable daemons."));
         ok = FALSE;
  }

  return ok;
}


// service destroy launcher method
VOID Destroy()
{
  ServiceControl(FALSE);
}


// service destroy method
BOOL Destroyed()
{
  jmethodID mid;
  BOOL ok = TRUE;
  
  // calling control destroy method
  mid = (*env)->GetMethodID(env, clsControl, "destroy", "()V");
  if (0 == mid) {
     PrintError(TEXT("Control destroy method not available."));
     ok = FALSE;
  }
  else (*env)->CallVoidMethod(env, objControl, mid);

  return ok;
}


// system exit method
VOID Exit()
{
  int exitcode = (jint)0;

  jmethodID mid;
  jclass cls;

  (*vm)->AttachCurrentThread(vm,(void **)&env, NULL);

  cls = (*env)->FindClass(env, "java/lang/System");
  mid = (*env)->GetStaticMethodID(env, cls, "exit", "(I)V");
  if (mid == 0) {
     PrintError(TEXT("System exit method not available."));
     return; 
  }

  __try {
         (*env)->CallStaticVoidMethod(env, cls, mid, exitcode);
   
	   (*vm)->DetachCurrentThread(vm);
  }
  __except (EXCEPTION_EXECUTE_HANDLER) {
           (*env)->ExceptionClear(env);
  } 

}


// service handling method
VOID ServiceWait() 
{
  jmethodID mid;

  LPTSTR szKey, p;
  UINT i;

  BOOL healthy = running;

  // waiting for termination event with interruptions for control actions
  while (healthy&&running) {
        
        WaitForSingleObject(hServiceEvent, PROBE_INTERVAL);

        if (running) {
        
           if (pausing) healthy = Stopped();
           else {
                  if (restarting) healthy = Started();
                  else healthy = Probed();
           }
           ResetEvent(hServiceEvent);
        }
  }

  if (ghosting) {
     if (!Destroyed()) Exit();
  }
  else Exit();
    
  (*vm)->DestroyJavaVM(vm);
  created = FALSE;

  if (created) {

     // releasing global object resources
     if (ghosting) {  

        i = strlen((LPTSTR)CLASS_LISTENING);
        szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 6) * sizeof(TCHAR));
        strcpy(szKey, "(L"); p = szKey + 2;
        strcpy(p, (LPTSTR)CLASS_LISTENING); p += i;
        strcpy(p, ";)V");

        mid = (*env)->GetMethodID(env, clsMain, "removeListener", szKey);
        GlobalFree(szKey);
    
        if (0 == mid) {
           PrintError(TEXT("Listener detach method not available."));
           return;
        }

        // unlinking listener 
        (*env)->CallVoidMethod(env, objMain, mid, objListener);

        (*env)->UnregisterNatives(env, clsListener); 
        (*env)->DeleteGlobalRef(env, objListener); 


        i = strlen((LPTSTR)CLASS_LOGGING);
        szKey = (LPTSTR)GlobalAlloc(GMEM_FIXED, (i + 6) * sizeof(TCHAR));
        strcpy(szKey, "(L"); p = szKey + 2;
        strcpy(p, (LPTSTR)CLASS_LOGGING); p += i;
        strcpy(p, ";)V");

        // unsetting native daemon logger
        mid = (*env)->GetMethodID(env, clsContext, "setLogger", szKey);
        GlobalFree(szKey);

        if (0 == mid) {
           PrintError(TEXT("Daemon logger setting not available."));
           return;
        }

        (*env)->CallVoidMethod(env, objContext, mid, (jobject)0);
        
        (*env)->UnregisterNatives(env, clsLogger); 
        (*env)->DeleteGlobalRef(env, objLogger); 


        (*env)->DeleteGlobalRef(env, objControl); 
        (*env)->DeleteGlobalRef(env, objContext); 
     }

     (*env)->DeleteGlobalRef(env, objMain); 
  }

  for (i=0; i<dwALen; i++){
      GlobalFree(lpszAppArgs[i]);
  }
  if (NULL != lpszAppArgs) GlobalFree(lpszAppArgs);

  for (i=0; i<dwJLen; i++){
      GlobalFree(lpszJavaArgs[i]);
  }
  if (NULL != lpszJavaArgs) GlobalFree(lpszJavaArgs);

  for (i=0; i<dwSLen; i++){
      GlobalFree(lpszServiceArgs[i]);
  }
  if (NULL != lpszServiceArgs) GlobalFree(lpszServiceArgs);

  ReportStatus(SERVICE_STOPPED);

  if (NULL != hServiceEvent) CloseHandle(hServiceEvent);
}

    
// service init method
VOID Init(DWORD argc, LPTSTR *argv)
{
  if (!ReportStatus(SERVICE_START_PENDING)) return;

  // termination event generation
  hServiceEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

  if (NULL != hServiceEvent) {
     lpszServiceArgs = getServiceParameters(&dwSLen, argc, argv);
     lpszJavaArgs = getJavaParameters(&dwJLen, argc, argv);
     lpszAppArgs = getDaemonParameters(&dwALen, argc, argv);

     InvokeJVM();
  }

  ServiceWait();
}
