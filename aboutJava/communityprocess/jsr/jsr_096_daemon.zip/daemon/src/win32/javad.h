#ifndef _JAVAD_H_
#define _JAVAD_H_

// Java Daemon API JSR
// This module contains methods for controlling Java daemons
// tk, 2000-11-26

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

BOOL Ghosting();
BOOL Pausable();

VOID Init(DWORD, LPTSTR *);
VOID Start();
VOID Probe();
VOID Stop();
VOID Destroy();

#ifdef __cplusplus
}
#endif

#endif