#ifndef _SERVICE_H_
#define _SERVICE_H_

// Java Daemon API JSR
// This module contains methods for managing the service structures
// tk, 2000-11-26

#ifdef __cplusplus
extern "C" {
#endif

// list of service dependencies - "dep1\0dep2\0\0"
#define DEPENDENCIES "Tcpip\0\0"

// service default start type
#define STARTTYPE SERVICE_AUTO_START 

// maximum response time in milliseconds for an action launching
#define ACTIONLIMIT 60000

// sleeping time in milliseconds during service stopping
#define SLEEPLIMIT 1000

LPTSTR getServiceName();
BOOL ReportStatus(DWORD);
void PrintInfo(LPTSTR);
void PrintError(LPTSTR);

#ifdef __cplusplus
}
#endif

#endif
