#ifndef _VM_H_
#define _VM_H_

// Java Daemon API JSR
// This module contains methods for accessing the JVM invocation API.
// tk, 2000-11-26

#include <stdio.h>
#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

// hotspot server is the default VM type
#define SZJVMTYPE "server"

typedef jint (JNICALL *CreateJavaVM_t)(JavaVM **pvm, void **env, void *args);
typedef jint (JNICALL *GetDefaultJavaVMInitArgs_t)(void *args);

typedef struct {
    CreateJavaVM_t CreateJavaVM;
    GetDefaultJavaVMInitArgs_t GetDefaultJavaVMInitArgs;
} InvocationFunctions;

BOOL GetJREPath(char *, int);
BOOL GetJVMPath(const char *, const char *, char *, int);
BOOL LoadJavaVM(const char *, InvocationFunctions *);

#ifdef __cplusplus
}
#endif

#endif
