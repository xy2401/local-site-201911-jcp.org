#ifndef _ARGS_H_
#define _ARGS_H_

// Java Daemon API JSR
// This module contains methods for parsing and converting parameter structures
// tk, 2000-11-26

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

LPTSTR *getServiceParameters(PDWORD, DWORD, LPTSTR *);
LPTSTR *getJavaParameters(PDWORD, DWORD, LPTSTR *);
LPTSTR *getDaemonParameters(PDWORD, DWORD, LPTSTR *);

LPTSTR *getParameterArray(PDWORD, LPTSTR);
LPTSTR getCommandString(DWORD, LPTSTR *);
LPTSTR getServiceString(DWORD, LPTSTR *);

#ifdef __cplusplus
}
#endif

#endif
