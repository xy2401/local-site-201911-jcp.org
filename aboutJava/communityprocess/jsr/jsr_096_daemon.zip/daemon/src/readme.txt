Java Daemon API / Sources

The src.jar file contains the Java daemon API Java sources including some helper classes
for implementing JNI based native platform containers. JNI helper classes are not
part of the Java daemon API. (The src.jar file can be unpacked using the JDK jar tool,
i.e. "jar -xvf src.jar").

The win32 subdirectory contains the sources for a preliminary RI for an NT 4.0 platform.
The sources can be compiled under an NT 4.0 C development environment by calling "nmake"
from a console window in the source directory. NMAKE uses the makefile file of the 
source directory for compiling and linking the C sources.

A Windows 95/98 RI would be supplied by implementing rudimentary functionality based on
some Windows registry keys for automatic startup, which would still have to be evaluated 
in detail.

A Unix plaform RI is not yet included. Unix RIs would be supplied by mapping the
Java daemon API to init rc scripts, i.e. the javad daemon launcher and installer
for Unix platforms would create rc scripts with entry points for starting, stopping 
and probing daemons. The entry points again would call the javad launcher at runtime 
using a specific signal parameter to be dispatched to a running native daemon 
process for daemon controlling actions.

tk, 2000-11-26.
